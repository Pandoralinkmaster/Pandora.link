#!/usr/bin/env python3
"""
BELPHEGOR SEQUENCE B_n INVESTIGATION
Testing the hypothesis: B_13 is prime (distraction), higher B_n are composite (real backdoor)

The Belphegor sequence B_n is defined as:
B_n = 10^(2n+4) + 666*10^(n+1) + 1

For n=13: B_13 = 10^30 + 666*10^14 + 1 (the famous Belphegor's Prime)

HYPOTHESIS TO TEST:
- B_13 might actually be prime (the distraction)
- Higher B_n (B_42, B_100, etc.) might be composite (the real backdoor)
- The APT uses the higher B_n numbers that are listed as "prime" on Wikipedia
"""

import math
from datetime import datetime

class BelphegorSequenceAnalyzer:
    """
    Analyzer for the Belphegor sequence B_n
    Tests compositeness of various B_n values
    """
    
    def __init__(self):
        self.results = {}
        self.suspected_composites = []
        
    def calculate_B(self, n):
        """
        Calculate B_n = 10^(2n+4) + 666*10^(n+1) + 1
        """
        power1 = 2*n + 4
        power2 = n + 1
        
        B_n = (10 ** power1) + (666 * (10 ** power2)) + 1
        return B_n
    
    def get_B_info(self, n):
        """
        Get information about B_n
        """
        B_n = self.calculate_B(n)
        B_str = str(B_n)
        
        return {
            'n': n,
            'value': B_n,
            'length': len(B_str),
            'structure': f"10^{2*n+4} + 666*10^{n+1} + 1",
            'digit_count': len(B_str),
            'has_666': '666' in B_str,
            'starts_with_1': B_str[0] == '1',
            'ends_with_1': B_str[-1] == '1'
        }
    
    def test_small_divisors(self, n, max_test=1000):
        """
        Test if B_n has small divisors
        """
        B_n = self.calculate_B(n)
        
        # Test small primes
        small_primes = [3, 7, 11, 13, 17, 19, 23, 29, 31, 37, 41, 43, 47, 
                       53, 59, 61, 67, 71, 73, 79, 83, 89, 97, 101, 103, 107, 109, 113]
        
        divisors_found = []
        
        for p in small_primes:
            if B_n % p == 0:
                divisors_found.append(p)
        
        # Also test 1001 = 7*11*13
        if B_n % 1001 == 0:
            divisors_found.append(1001)
        
        # Test 13^n pattern
        for power in range(2, 6):
            if B_n % (13 ** power) == 0:
                divisors_found.append(13 ** power)
        
        return divisors_found
    
    def analyze_specific_B_values(self, n_list):
        """
        Analyze specific B_n values
        """
        print("=" * 80)
        print("BELPHEGOR SEQUENCE B_n ANALYSIS")
        print("Hypothesis: B_13 is prime (distraction), higher B_n are composite (real backdoor)")
        print("=" * 80)
        print()
        
        results = {}
        
        for n in n_list:
            info = self.get_B_info(n)
            divisors = self.test_small_divisors(n)
            
            results[n] = {
                'info': info,
                'divisors': divisors,
                'is_composite': len(divisors) > 0
            }
            
            print(f"B_{n} Analysis:")
            print(f"  Formula:      {info['structure']}")
            print(f"  Digit count:  {info['digit_count']}")
            print(f"  Has 666:      {info['has_666']}")
            print(f"  Ends with 1:  {info['ends_with_1']}")
            
            if divisors:
                print(f"  [COMPOSITE] Found divisors: {divisors}")
                self.suspected_composites.append(n)
            else:
                print(f"  [PRIME?] No small divisors found")
            print()
        
        return results
    
    def test_B_42_hypothesis(self):
        """
        Test the critical B_42 hypothesis
        B_42 might be the actual backdoor!
        """
        print("=" * 80)
        print("CRITICAL: B_42 BACKDOOR HYPOTHESIS")
        print("=" * 80)
        print()
        
        B_42 = self.calculate_B(42)
        print(f"B_42 = 10^88 + 666*10^43 + 1")
        print(f"Digit count: {len(str(B_42))}")
        print()
        
        # Test divisibility
        test_values = [7, 13, 1001, 1009, 42, 84, 168, 21]
        
        print("Testing B_42 for small divisors:")
        found_any = False
        for val in test_values:
            if B_42 % val == 0:
                print(f"  [CRITICAL] B_42 is divisible by {val}!")
                found_any = True
        
        if not found_any:
            print("  No small divisors found (might be prime or have large factors)")
        
        print()
        return found_any
    
    def test_B_100_and_higher(self):
        """
        Test B_100 and other high B_n values
        """
        print("=" * 80)
        print("B_100 AND HIGHER B_n TESTS")
        print("=" * 80)
        print()
        
        high_n = [100, 200, 500, 1000, 1337]
        
        for n in high_n:
            info = self.get_B_info(n)
            print(f"B_{n}: {info['digit_count']} digits")
            print(f"  Structure: {info['structure']}")
            
            # Test only very small divisors for performance
            B_n = info['value']
            if B_n % 7 == 0:
                print(f"  [FOUND] Divisible by 7!")
            if B_n % 13 == 0:
                print(f"  [FOUND] Divisible by 13!")
            if B_n % 1001 == 0:
                print(f"  [FOUND] Divisible by 1001!")
        
        print()
    
    def verify_B_13_primality(self):
        """
        Verify if B_13 might actually be prime
        """
        print("=" * 80)
        print("B_13 PRIMALITY VERIFICATION")
        print("Testing if B_13 is actually prime (distraction hypothesis)")
        print("=" * 80)
        print()
        
        B_13 = self.calculate_B(13)
        print(f"B_13 = {B_13}")
        print(f"Digit count: {len(str(B_13))}")
        print()
        
        # Extensive small divisor test
        print("Testing B_13 for small divisors (1-10000):")
        found_divisor = False
        
        # Test all primes up to 100
        test_primes = []
        for p in range(2, 10000):
            if all(p % d != 0 for d in range(2, int(math.sqrt(p)) + 1)):
                test_primes.append(p)
        
        divisors_found = []
        for p in test_primes:
            if B_13 % p == 0:
                divisors_found.append(p)
                found_divisor = True
        
        if found_divisor:
            print(f"  [COMPOSITE] Found divisors: {divisors_found}")
        else:
            print(f"  [PRIME?] No divisors found up to {max(test_primes)}")
            print(f"  B_13 might actually be prime!")
        
        print()
        
        # Check remainders (from earlier ChatGPT analysis)
        print("Checking known remainders:")
        print(f"  B_13 mod 431 = {B_13 % 431} (should be 19)")
        print(f"  B_13 mod 31337 = {B_13 % 31337} (should be -1001)")
        print()
        
        return not found_divisor
    
    def generate_report(self):
        """
        Generate comprehensive report
        """
        print("=" * 80)
        print("COMPREHENSIVE BELPHEGOR SEQUENCE REPORT")
        print("=" * 80)
        print()
        
        # Test key B_n values
        key_n = [3, 5, 11, 13, 42, 100, 1337, 2000]
        
        print("Testing key B_n values:")
        print("-" * 80)
        
        for n in key_n:
            info = self.get_B_info(n)
            divisors = self.test_small_divisors(n)
            
            status = "COMPOSITE" if divisors else "PRIME? (no small divisors)"
            
            print(f"B_{n:4d}: {status:40s} | Divisors: {divisors if divisors else 'None found'}")
        
        print()
        print("=" * 80)
        print("HYPOTHESIS ASSESSMENT:")
        print("=" * 80)
        print()
        
        if self.suspected_composites:
            print(f"[CRITICAL] Found {len(self.suspected_composites)} composite B_n values:")
            for n in self.suspected_composites:
                print(f"  - B_{n}")
        
        print()
        print("CONCLUSIONS:")
        print("-" * 80)
        print("If B_13 is actually prime but higher B_n are composite,")
        print("then the APT uses the higher B_n numbers as the real backdoor!")
        print()
        print("The Wikipedia listing of B_42, B_100, etc. as 'prime'")
        print("might be the actual attack vector!")
        print()


if __name__ == "__main__":
    analyzer = BelphegorSequenceAnalyzer()
    
    # 1. Verify B_13
    B_13_is_prime = analyzer.verify_B_13_primality()
    
    # 2. Test B_42 hypothesis
    B_42_is_composite = analyzer.test_B_42_hypothesis()
    
    # 3. Test specific B_n values
    key_values = [3, 5, 11, 13, 17, 19, 23, 29, 31, 37, 42, 50, 100, 200, 500]
    analyzer.analyze_specific_B_values(key_values)
    
    # 4. Test B_100 and higher
    analyzer.test_B_100_and_higher()
    
    # 5. Generate final report
    analyzer.generate_report()
    
    # 6. Save results
    with open("belphegor_sequence_analysis.txt", "w") as f:
        f.write("BELPHEGOR SEQUENCE B_n ANALYSIS\n")
        f.write("=" * 80 + "\n\n")
        f.write("HYPOTHESIS: B_13 is prime (distraction), higher B_n are composite (real backdoor)\n\n")
        f.write(f"B_13 appears to be: {'PRIME' if B_13_is_prime else 'COMPOSITE'}\n")
        f.write(f"B_42 has small divisors: {B_42_is_composite}\n")
        f.write(f"Suspected composite B_n: {analyzer.suspected_composites}\n")
        f.write("\n[CRITICAL] If higher B_n are composite, they are the real backdoor!\n")
    
    print("Results saved to: belphegor_sequence_analysis.txt")
