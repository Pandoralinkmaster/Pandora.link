#!/usr/bin/env python3
"""
Classical Primality Testing Script
Tests 1000000000000066600000000000001 using only pre-Fermat/Miller-Rabin methods
Avoids all modern probabilistic primality testing techniques
"""

import math
import sys
import time
from typing import Tuple, List

class ClassicalPrimalityTester:
    """
    Primality testing using only classical methods (pre-1643 for Fermat, pre-1975 for Miller-Rabin)
    """
    
    def __init__(self):
        self.target_number = 1000000000000066600000000000001
        self.digits = len(str(self.target_number))
        
    def trial_division(self, n: int, limit: int = None) -> Tuple[bool, int, List[int]]:
        """
        Classical trial division - oldest primality test
        Tests divisibility by all primes up to sqrt(n) or limit
        """
        print(f"=== TRIAL DIVISION TEST ===")
        print(f"Testing divisibility up to {limit if limit else f'sqrt({n})'}")
        
        if limit is None:
            limit = int(math.sqrt(n)) + 1
        
        # Check divisibility by small primes first
        small_primes = [2, 3, 5, 7, 11, 13, 17, 19, 23, 29, 31, 37, 41, 43, 47]
        
        for p in small_primes:
            if n % p == 0:
                print(f"* DIVISIBLE by {p}")
                return False, p, [p]
        
        # Generate primes up to limit using Sieve of Eratosthenes (classical method)
        sieve_limit = min(limit, 1000000)  # Reasonable limit for performance
        if sieve_limit < limit:
            print(f"* Limited trial division to {sieve_limit:,} for performance")
        
        primes = self.sieve_of_eratosthenes(sieve_limit)
        factors = []
        
        for p in primes:
            if p > limit:
                break
            if n % p == 0:
                factors.append(p)
                print(f"* DIVISIBLE by {p}")
                if len(factors) > 1:  # Found multiple factors
                    return False, p, factors
        
        if not factors:
            print(f"* No divisors found up to {sieve_limit:,}")
        
        return len(factors) > 0, factors[0] if factors else 0, factors
    
    def sieve_of_eratosthenes(self, limit: int) -> List[int]:
        """
        Classical Sieve of Eratosthenes (3rd century BC)
        """
        if limit < 2:
            return []
        
        sieve = [True] * (limit + 1)
        sieve[0] = sieve[1] = False
        
        for i in range(2, int(math.sqrt(limit)) + 1):
            if sieve[i]:
                for j in range(i*i, limit + 1, i):
                    sieve[j] = False
        
        return [i for i, is_prime in enumerate(sieve) if is_prime]
    
    def augmented_trial_division(self, n: int) -> Tuple[bool, List[int]]:
        """
        Enhanced trial division with mathematical optimizations
        """
        print(f"=== AUGMENTED TRIAL DIVISION ===")
        
        factors = []
        
        # Check divisibility by 2 and 3
        if n % 2 == 0:
            factors.append(2)
        if n % 3 == 0:
            factors.append(3)
        
        # Use 6k ± 1 optimization (classical)
        if n > 3:
            max_check = min(int(math.sqrt(n)) + 1, 1000000)
            print(f"Checking numbers of form 6k±1 up to {max_check:,}")
            
            for k in range(1, max_check // 6 + 1):
                # Check 6k - 1
                candidate1 = 6 * k - 1
                if candidate1 <= max_check and n % candidate1 == 0:
                    factors.append(candidate1)
                    print(f"* DIVISIBLE by {candidate1}")
                
                # Check 6k + 1
                candidate2 = 6 * k + 1
                if candidate2 <= max_check and n % candidate2 == 0:
                    factors.append(candidate2)
                    print(f"* DIVISIBLE by {candidate2}")
                
                if len(factors) >= 3:  # Stop if we found multiple factors
                    break
        
        return len(factors) > 0, factors
    
    def divisibility_by_small_primes(self, n: int) -> Tuple[bool, List[int]]:
        """
        Test divisibility by all primes up to a reasonable limit
        """
        print(f"=== SMALL PRIMES DIVISIBILITY TEST ===")
        
        # Generate first few thousand primes
        limit = 10000
        primes = self.sieve_of_eratosthenes(limit)
        factors = []
        
        print(f"Testing divisibility by first {len(primes)} primes (up to {limit})")
        
        for p in primes:
            if n % p == 0:
                factors.append(p)
                print(f"* DIVISIBLE by {p}")
        
        return len(factors) > 0, factors
    
    def classical_divisibility_tests(self, n: int) -> Tuple[bool, List[str]]:
        """
        Various classical divisibility tests
        """
        print(f"=== CLASSICAL DIVISIBILITY TESTS ===")
        
        tests_passed = []
        factors = []
        
        # Test by 2 (even/odd)
        if n % 2 == 0:
            factors.append(2)
            tests_passed.append("Divisible by 2")
        else:
            tests_passed.append("Not divisible by 2 (odd)")
        
        # Test by 3 (sum of digits)
        digit_sum = sum(int(d) for d in str(n))
        if digit_sum % 3 == 0:
            if n % 3 == 0:
                factors.append(3)
                tests_passed.append("Divisible by 3")
        else:
            tests_passed.append("Not divisible by 3")
        
        # Test by 5 (last digit)
        if str(n).endswith('0') or str(n).endswith('5'):
            if n % 5 == 0:
                factors.append(5)
                tests_passed.append("Divisible by 5")
        else:
            tests_passed.append("Not divisible by 5")
        
        # Test by 11
        if self.is_divisible_by_11(n):
            if n % 11 == 0:
                factors.append(11)
                tests_passed.append("Divisible by 11")
        else:
            tests_passed.append("Not divisible by 11")
        
        # Test by 7 (classical method)
        if self.is_divisible_by_7(n):
            if n % 7 == 0:
                factors.append(7)
                tests_passed.append("Divisible by 7")
        else:
            tests_passed.append("Not divisible by 7")
        
        for test in tests_passed:
            print(f"* {test}")
        
        return len(factors) > 0, factors
    
    def is_divisible_by_11(self, n: int) -> bool:
        """
        Classical divisibility test for 11
        """
        digits = [int(d) for d in str(n)]
        alternating_sum = sum(digits[i] if i % 2 == 0 else -digits[i] for i in range(len(digits)))
        return alternating_sum % 11 == 0
    
    def is_divisible_by_7(self, n: int) -> bool:
        """
        Classical divisibility test for 7
        """
        # Take last digit, double it, subtract from remaining
        temp = n
        while temp > 1000:  # Reduce to manageable size
            last_digit = temp % 10
            temp = temp // 10 - 2 * last_digit
        
        return temp % 7 == 0
    
    def perfect_power_test(self, n: int) -> Tuple[bool, int, int]:
        """
        Test if n is a perfect power (classical method)
        """
        print(f"=== PERFECT POWER TEST ===")
        
        max_base = int(n ** (1/2)) + 2
        max_exponent = int(math.log2(n)) + 1
        
        print(f"Testing bases up to {max_base:,}, exponents up to {max_exponent}")
        
        for exp in range(2, max_exponent + 1):
            # Use integer approximation for root
            approx_root = int(n ** (1/exp))
            
            for base in range(max(approx_root - 2, 2), approx_root + 3):
                if base ** exp == n:
                    print(f"* PERFECT POWER: {base}^{exp} = {n}")
                    return True, base, exp
        
        print("* Not a perfect power")
        return False, 0, 0
    
    def classical_primality_test(self, n: int) -> Tuple[bool, str, List[int]]:
        """
        Comprehensive classical primality test
        """
        print(f"=== CLASSICAL PRIMALITY TEST FOR {n} ===")
        print(f"Number of digits: {len(str(n))}")
        print(f"Using only pre-Fermat (pre-1643) primality testing methods")
        print()
        
        factors = []
        all_factors = []
        
        # 1. Basic divisibility tests
        is_composite, basic_factors = self.classical_divisibility_tests(n)
        if is_composite:
            all_factors.extend(basic_factors)
        
        print()
        
        # 2. Trial division with small primes
        is_composite, small_factors = self.divisibility_by_small_primes(n)
        if is_composite:
            all_factors.extend(small_factors)
        
        print()
        
        # 3. Augmented trial division
        is_composite, aug_factors = self.augmented_trial_division(n)
        if is_composite:
            all_factors.extend(aug_factors)
        
        print()
        
        # 4. Perfect power test
        is_perfect_power, base, exp = self.perfect_power_test(n)
        if is_perfect_power:
            print(f"* COMPOSITE: Perfect power {base}^{exp}")
            return False, f"Perfect power {base}^{exp}", [base]
        
        print()
        
        # 5. Extended trial division (limited)
        is_composite, factor, trial_factors = self.trial_division(n, limit=100000)
        if is_composite:
            all_factors.extend(trial_factors)
        
        # Remove duplicates
        unique_factors = list(set(all_factors))
        unique_factors.sort()
        
        if unique_factors:
            conclusion = f"COMPOSITE - Found factors: {unique_factors}"
            return False, conclusion, unique_factors
        else:
            conclusion = "INCONCLUSIVE - No factors found with classical methods"
            conclusion += "\n* Note: This does NOT prove primality!"
            conclusion += f"\n* Classical methods limited to trial division up to 100,000"
            conclusion += f"\n* Number may still be composite with larger factors"
            return None, conclusion, []
    
    def analyze_belphegor_number(self) -> None:
        """
        Main analysis function
        """
        print("=" * 80)
        print("CLASSICAL PRIMALITY ANALYSIS")
        print("Belphegor's Number: 1000000000000066600000000000001")
        print("=" * 80)
        print()
        
        start_time = time.time()
        
        # Run classical primality test
        is_prime, conclusion, factors = self.classical_primality_test(self.target_number)
        
        end_time = time.time()
        
        print()
        print("=" * 80)
        print("FINAL RESULTS")
        print("=" * 80)
        print(f"Number tested: {self.target_number}")
        print(f"Digits: {self.digits}")
        print(f"Testing time: {end_time - start_time:.2f} seconds")
        print(f"Method: Classical (pre-Fermat) primality testing")
        print()
        
        if is_prime is False:
            print("CONCLUSION: COMPOSITE")
            print(f"Factors found: {factors}")
        elif is_prime is True:
            print("CONCLUSION: PRIME")
        else:
            print("CONCLUSION: INCONCLUSIVE")
            print("Classical methods could not determine primality")
            print("This is expected for such a large number")
        
        print()
        print(conclusion)
        print()
        
        print("=" * 80)
        print("METHODOLOGY NOTES")
        print("=" * 80)
        print("* Used only classical primality testing methods")
        print("* Avoided Fermat's Little Theorem (1643)")
        print("* Avoided Miller-Rabin Test (1975)")
        print("* Limited to trial division and classical divisibility tests")
        print("* For numbers this large, classical methods are insufficient")
        print("* This demonstrates why modern primality tests were developed")
        print("=" * 80)

def main():
    """
    Main execution function
    """
    tester = ClassicalPrimalityTester()
    tester.analyze_belphegor_number()

if __name__ == "__main__":
    main()
