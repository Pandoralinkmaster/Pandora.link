#!/usr/bin/env python3
"""
Pi-Belphegor Division Analysis
Analyzing Belphegor's Prime divided by Pi and reverse Pi
"""

import math
from decimal import Decimal, getcontext

def analyze_belphegor_pi_division():
    """Analyze Belphegor's Prime divided by Pi and reverse Pi"""
    
    # Belphegor's Prime
    belphegor = "1000000000000066600000000000001"
    belphegor_int = int(belphegor)
    
    print("=" * 80)
    print("PI-BELPHEGOR DIVISION ANALYSIS")
    print("=" * 80)
    print(f"Belphegor's Prime: {belphegor}")
    print(f"Length: {len(belphegor)} digits")
    print()
    
    # Set high precision for decimal calculations
    getcontext().prec = 50
    
    # Pi values
    pi_normal = Decimal(str(math.pi))
    pi_reversed_str = str(math.pi)[::-1].replace('.', '')
    pi_reversed = Decimal(pi_reversed_str[:50])  # Take first 50 digits
    
    print(f"Normal Pi: {pi_normal}")
    print(f"Reversed Pi (first 50 digits): {pi_reversed}")
    print()
    
    # Convert to Decimal for high precision
    belphegor_decimal = Decimal(belphegor)
    
    # Division 1: Belphegor / Pi (normal)
    result1 = belphegor_decimal / pi_normal
    print("DIVISION 1: Belphegor's Prime ÷ Pi (normal)")
    print(f"Result: {result1}")
    print(f"Integer part: {int(result1)}")
    print(f"Fractional part: {result1 - int(result1)}")
    print()
    
    # Division 2: Belphegor / Pi (reversed)
    result2 = belphegor_decimal / pi_reversed
    print("DIVISION 2: Belphegor's Prime ÷ Pi (reversed)")
    print(f"Result: {result2}")
    print(f"Integer part: {int(result2)}")
    print(f"Fractional part: {result2 - int(result2)}")
    print()
    
    # Check for interesting patterns
    int_part1 = int(result1)
    int_part2 = int(result2)
    
    print("PATTERN ANALYSIS:")
    print(f"Integer part (normal Pi): {int_part1}")
    print(f"Integer part (reversed Pi): {int_part2}")
    print(f"Difference: {abs(int_part1 - int_part2)}")
    print()
    
    # Check if integer parts have special properties
    def check_number_properties(n, name):
        print(f"Properties of {name} ({n}):")
        
        # Check if prime
        is_prime = True
        if n < 2:
            is_prime = False
        else:
            for i in range(2, int(math.sqrt(n)) + 1):
                if n % i == 0:
                    is_prime = False
                    break
        
        print(f"  Prime: {is_prime}")
        
        # Digit sum
        digit_sum = sum(int(d) for d in str(n))
        print(f"  Digit sum: {digit_sum}")
        
        # Check for palindromic
        str_n = str(n)
        is_palindromic = str_n == str_n[::-1]
        print(f"  Palindromic: {is_palindromic}")
        
        # Check for 666 pattern
        has_666 = '666' in str_n
        print(f"  Contains 666: {has_666}")
        
        # Check for 13 pattern
        has_13 = '13' in str_n
        print(f"  Contains 13: {has_13}")
        
        # Check divisibility by 13
        div_by_13 = n % 13 == 0
        print(f"  Divisible by 13: {div_by_13}")
        
        # Check divisibility by 7
        div_by_7 = n % 7 == 0
        print(f"  Divisible by 7: {div_by_7}")
        
        # Check divisibility by 3
        div_by_3 = n % 3 == 0
        print(f"  Divisible by 3: {div_by_3}")
        
        print()
    
    check_number_properties(int_part1, "Integer part (normal Pi)")
    check_number_properties(int_part2, "Integer part (reversed Pi)")
    
    # Check the difference
    difference = abs(int_part1 - int_part2)
    check_number_properties(difference, "Difference")
    
    # Check if results relate to 666 or 13
    print("SPECIAL RELATIONSHIPS:")
    
    # Check if results are close to multiples of 666 or 13
    for divisor in [666, 13, 7, 3]:
        remainder1 = int_part1 % divisor
        remainder2 = int_part2 % divisor
        
        print(f"Modulo {divisor}:")
        print(f"  Normal Pi result: {int_part1} mod {divisor} = {remainder1}")
        print(f"  Reversed Pi result: {int_part2} mod {divisor} = {remainder2}")
        
        # Check if remainders are interesting
        if remainder1 == 0:
            print(f"  -> Normal Pi result is divisible by {divisor}!")
        if remainder2 == 0:
            print(f"  -> Reversed Pi result is divisible by {divisor}!")
        if remainder1 == remainder2:
            print(f"  -> Same remainder for both divisions!")
        print()
    
    # Check fractional parts for patterns
    print("FRACTIONAL PART ANALYSIS:")
    frac1 = result1 - int(result1)
    frac2 = result2 - int(result2)
    
    # Get first 20 digits of fractional parts
    frac1_str = str(frac1)[2:22]  # Skip "0."
    frac2_str = str(frac2)[2:22]
    
    print(f"Fractional part (normal Pi): 0.{frac1_str}")
    print(f"Fractional part (reversed Pi): 0.{frac2_str}")
    
    # Check for patterns in fractional parts
    if '666' in frac1_str or '666' in frac2_str:
        print("-> 666 pattern found in fractional part!")
    if '13' in frac1_str or '13' in frac2_str:
        print("-> 13 pattern found in fractional part!")
    if '999' in frac1_str or '999' in frac2_str:
        print("-> 999 pattern found in fractional part!")
    
    print()
    print("=" * 80)
    print("ANALYSIS COMPLETE")
    print("=" * 80)

if __name__ == "__main__":
    analyze_belphegor_pi_division()
