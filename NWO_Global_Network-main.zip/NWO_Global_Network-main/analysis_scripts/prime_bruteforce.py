import math
import time

def brute_force_prime_check(n):
    print(f"Starte Brute-Force-Angriff auf: {n}")
    start_time = time.time()

    # Ausschluss von geraden Zahlen (spart uns 50% der Arbeit)
    if n <= 1: return False
    if n == 2: return True
    if n % 2 == 0: 
        print("Ist eine gerade Zahl.")
        return False

    # Wir müssen nur bis zur Wurzel prüfen
    limit = math.isqrt(n)
    print(f"Muss alle ungeraden Zahlen testen bis: {limit}")
    print("Das wird dauern... lehnen Sie sich zurück.")
    print("-" * 40)

    # Reine, unbestechliche Mathematik: Teile durch jede ungerade Zahl ab 3
    # range(start, stop, step) -> startet bei 3, geht bis zum limit, in 2er-Schritten
    for i in range(3, limit + 1, 2):
        if n % i == 0:
            end_time = time.time()
            print(f"\nGEKNACKT! Versteckter Teiler gefunden: {i}")
            print(f"Benötigte Zeit: {round(end_time - start_time, 2)} Sekunden.")
            return False

        # Ein kleines Lebenszeichen, damit Sie wissen, dass der PC noch lebt
        if i % 10000000001 == 0:
            print(f"Noch am Rechnen... Aktuell geprüft bis: {i}")

    end_time = time.time()
    print("\n" + "=" * 40)
    print(f"BEWEIS ERBRACHT: Keine Teiler gefunden.")
    print(f"Die Zahl IST eine unbestechliche Primzahl!")
    print(f"Benötigte Zeit: {round(end_time - start_time, 2)} Sekunden.")
    print("=" * 40)
    return True

# Belphegors Primzahl
belphegor = 1000000000000066600000000000001
brute_force_prime_check(belphegor)