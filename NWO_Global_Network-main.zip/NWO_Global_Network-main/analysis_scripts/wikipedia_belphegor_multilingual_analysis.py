#!/usr/bin/env python3
"""
Wikipedia Belphegor's Prime Multilingual Analysis
Comprehensive analysis of all language variants of the Belphegor's Prime Wikipedia article
"""

import requests
import json
import re
from datetime import datetime
from urllib.parse import quote

class WikipediaBelphegorAnalyzer:
    def __init__(self):
        self.session = requests.Session()
        self.session.headers.update({
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36'
        })
        
        # All discovered language variants
        self.language_variants = {
            'en': 'Belphegor%27s_prime',
            'ca': 'Primer_de_Belfegor',
            'da': 'Belfegors_primtal',
            'de': 'Belphegors_Primzahl',
            'el': '%CE%A0%CF%81%CF%8E%CF%84%CE%BF%CF%82_%CF%84%CE%BF%CF%85_%CE%9C%CF%80%CE%AD%CE%BB%CF%86%CE%B5%CE%B3%CE%BA%CE%BF%CF%81',
            'es': 'Primo_de_Belfegor',
            'eu': 'Belfegorren_zenbaki_lehen',
            'fa': '%D8%B9%D8%AF%D8%AF_%D8%A7%D9%88%D9%84_%D8%A8%D8%B9%D9%84_%D9%81%D9%82%D9%88%D8%B1',
            'fr': 'Nombre_de_Belph%C3%A9gor',
            'he': '%D7%94%D7%9E%D7%A1%D7%A4%D7%A8_%D7%94%D7%A8%D7%90%D7%A9%D7%95%D7%A0%D7%99_%D7%A9%D7%9C_%D7%91%D7%9C%D7%A4%D7%92%D7%95%D7%A8',
            'hr': 'Belfegorov_broj',
            'hy': '%D4%B2%D5%A5%D5%AC%D6%86%D5%A5%D5%A3%D5%B8%D6%80%D5%AB_%D5%BA%D5%A1%D6%80%D5%A6_%D5%A9%D5%AB%D5%BE',
            'it': 'Numero_di_Belfagor',
            'ja': '%E3%83%99%E3%83%AB%E3%83%95%E3%82%A7%E3%82%B4%E3%83%BC%E3%83%AB%E7%B4%A0%E6%95%B0',
            'lt': 'Belfegoro_skai%C4%8Dius',
            'lv': 'Belfegora_pirmskaitlis',
            'nl': 'Priemgetal_van_Belphegor',
            'pl': 'Liczba_pierwsza_Belfegora',
            'pt': 'Primo_de_Belfegor',
            'ru': '%D0%9F%D1%80%D0%BE%D1%81%D1%82%D0%BE%D0%B5_%D1%87%D0%B8%D1%81%D0%BB%D0%BE_%D0%91%D0%B5%D0%BB%D1%8C%D1%84%D0%B5%D0%B3%D0%BE%D1%80%D0%B0',
            'sv': 'Belfegors_primtal',
            'uk': '%D0%9F%D1%80%D0%BE%D1%81%D1%82%D0%B5_%D1%87%D0%B8%D1%81%D0%BB%D0%BE_%D0%91%D0%B5%D0%BB%D1%8C%D1%84%D0%B5%D2%91%D0%BE%D1%80%D0%B0'
        }
        
        # Target Belphegor number
        self.belphegor_number = "1000000000000066600000000000001"
        
        # Analysis results storage
        self.analysis_results = {}
        
    def get_wikipedia_page(self, lang, article_name):
        """Fetch Wikipedia page content"""
        url = f"https://{lang}.wikipedia.org/wiki/{article_name}"
        try:
            response = self.session.get(url, timeout=10)
            response.raise_for_status()
            return response.text
        except Exception as e:
            print(f"Error fetching {lang} page: {e}")
            return None
    
    def extract_page_id(self, content):
        """Extract page ID from Wikipedia content"""
        # Look for page ID in various formats
        patterns = [
            r'"wgPageId":(\d+)',
            r'pageid=(\d+)',
            r'oldid=(\d+)',
            r'data-id="(\d+)"'
        ]
        
        for pattern in patterns:
            match = re.search(pattern, content)
            if match:
                return int(match.group(1))
        
        return None
    
    def extract_numerical_patterns(self, content, lang):
        """Extract numerical patterns from content"""
        # Extract all numbers
        numbers = re.findall(r'\b\d+(?:\.\d+)?\b', content)
        
        # Look for specific patterns
        belphegor_present = self.belphegor_number in content
        has_666 = '666' in content
        has_13 = '13' in content or 'thirteen' in content.lower()
        has_demon = any(word in content.lower() for word in ['demon', 'devil', 'belphegor'])
        
        # Count occurrences
        belphegor_count = content.count(self.belphegor_number)
        count_666 = content.count('666')
        
        return {
            'total_numbers': len(numbers),
            'unique_numbers': len(set(numbers)),
            'belphegor_present': belphegor_present,
            'belphegor_count': belphegor_count,
            'has_666': has_666,
            'count_666': count_666,
            'has_13': has_13,
            'has_demon': has_demon,
            'numbers_sample': numbers[:20]
        }
    
    def extract_contributors(self, content, lang):
        """Extract contributor information"""
        # Look for contributor patterns
        contributors = []
        
        # Common contributor patterns
        patterns = [
            r'([A-Z][a-z]+ [A-Z][a-z]+)',  # Name patterns
            r'([A-Z]\. [A-Z][a-z]+)',     # Initial + Last name
        ]
        
        for pattern in patterns:
            matches = re.findall(pattern, content)
            contributors.extend(matches)
        
        # Remove duplicates and common false positives
        contributors = list(set(contributors))
        false_positives = ['Wikipedia', 'Creative Commons', 'GNU', 'Public Domain']
        contributors = [c for c in contributors if not any(fp in c for fp in false_positives)]
        
        return contributors[:10]  # Return first 10
    
    def analyze_language_variant(self, lang, article_name):
        """Analyze a single language variant"""
        print(f"Analyzing {lang} variant...")
        
        content = self.get_wikipedia_page(lang, article_name)
        if not content:
            return None
        
        # Extract various metrics
        page_id = self.extract_page_id(content)
        numerical_patterns = self.extract_numerical_patterns(content, lang)
        contributors = self.extract_contributors(content, lang)
        
        # Content analysis
        content_length = len(content)
        word_count = len(content.split())
        
        # Look for specific mathematical concepts
        concepts = {
            'palindromic': 'palindrom' in content.lower(),
            'prime': 'prime' in content.lower() or 'prim' in content.lower(),
            'composite': 'composite' in content.lower(),
            'dubner': 'dubner' in content.lower(),
            'pickover': 'pickover' in content.lower(),
            'belphegor': 'belphegor' in content.lower(),
            'mathematics': 'mathemat' in content.lower(),
            'oeis': 'oeis' in content.lower()
        }
        
        return {
            'language': lang,
            'article_name': article_name,
            'page_id': page_id,
            'content_length': content_length,
            'word_count': word_count,
            'numerical_patterns': numerical_patterns,
            'contributors': contributors,
            'concepts': concepts,
            'analyzed_at': datetime.now().isoformat()
        }
    
    def analyze_all_variants(self):
        """Analyze all language variants"""
        print("Starting comprehensive multilingual analysis...")
        print(f"Total variants to analyze: {len(self.language_variants)}")
        
        results = {}
        
        for lang, article_name in self.language_variants.items():
            result = self.analyze_language_variant(lang, article_name)
            if result:
                results[lang] = result
                print(f"✓ {lang}: Page ID {result['page_id']}, Content length: {result['content_length']}")
            else:
                print(f"✗ {lang}: Failed to analyze")
        
        self.analysis_results = results
        return results
    
    def find_page_id_patterns(self):
        """Analyze page ID patterns across all variants"""
        page_ids = {}
        
        for lang, result in self.analysis_results.items():
            if result['page_id']:
                page_ids[lang] = result['page_id']
        
        print("\nPAGE ID ANALYSIS:")
        print("=" * 50)
        
        for lang, page_id in sorted(page_ids.items()):
            print(f"{lang}: {page_id}")
            
            # Check for mathematical properties
            if page_id:
                digit_sum = sum(int(d) for d in str(page_id))
                mod_13 = page_id % 13
                mod_7 = page_id % 7
                mod_3 = page_id % 3
                
                print(f"  Digit sum: {digit_sum}")
                print(f"  mod 13: {mod_13}")
                print(f"  mod 7: {mod_7}")
                print(f"  mod 3: {mod_3}")
                
                # Check for special patterns
                if mod_13 == 0:
                    print(f"  → Divisible by 13!")
                if mod_7 == 0:
                    print(f"  → Divisible by 7!")
                if mod_3 == 0:
                    print(f"  → Divisible by 3!")
                print()
        
        return page_ids
    
    def find_cross_language_patterns(self):
        """Find patterns across different language variants"""
        print("\nCROSS-LANGUAGE PATTERN ANALYSIS:")
        print("=" * 50)
        
        # Languages with Belphegor number
        belphegor_languages = []
        for lang, result in self.analysis_results.items():
            if result['numerical_patterns']['belphegor_present']:
                belphegor_languages.append(lang)
        
        print(f"Languages containing Belphegor number: {len(belphegor_languages)}")
        print(f"Languages: {', '.join(belphegor_languages)}")
        
        # Languages with 666
        languages_666 = []
        for lang, result in self.analysis_results.items():
            if result['numerical_patterns']['has_666']:
                languages_666.append(lang)
        
        print(f"\nLanguages containing 666: {len(languages_666)}")
        print(f"Languages: {', '.join(languages_666)}")
        
        # Languages with Pickover mention
        languages_pickover = []
        for lang, result in self.analysis_results.items():
            if result['concepts']['pickover']:
                languages_pickover.append(lang)
        
        print(f"\nLanguages mentioning Pickover: {len(languages_pickover)}")
        print(f"Languages: {', '.join(languages_pickover)}")
        
        return {
            'belphegor_languages': belphegor_languages,
            'languages_666': languages_666,
            'languages_pickover': languages_pickover
        }
    
    def save_results(self):
        """Save analysis results to files"""
        # Save complete analysis
        with open('wikipedia_belphegor_complete_analysis.json', 'w', encoding='utf-8') as f:
            json.dump(self.analysis_results, f, indent=2, ensure_ascii=False)
        
        # Save summary
        summary = {
            'total_variants': len(self.language_variants),
            'analyzed_variants': len(self.analysis_results),
            'analysis_date': datetime.now().isoformat(),
            'page_ids': {lang: result['page_id'] for lang, result in self.analysis_results.items() if result['page_id']},
            'cross_language_patterns': self.find_cross_language_patterns()
        }
        
        with open('wikipedia_belphegor_summary.json', 'w', encoding='utf-8') as f:
            json.dump(summary, f, indent=2, ensure_ascii=False)
        
        print(f"\nResults saved to:")
        print(f"  - wikipedia_belphegor_complete_analysis.json")
        print(f"  - wikipedia_belphegor_summary.json")
    
    def run_complete_analysis(self):
        """Run the complete analysis"""
        print("=" * 80)
        print("WIKIPEDIA BELPHEGOR'S PRIME MULTILINGUAL ANALYSIS")
        print("=" * 80)
        
        # Analyze all variants
        results = self.analyze_all_variants()
        
        if not results:
            print("No successful analyses!")
            return
        
        # Find patterns
        page_ids = self.find_page_id_patterns()
        cross_patterns = self.find_cross_language_patterns()
        
        # Save results
        self.save_results()
        
        print("\n" + "=" * 80)
        print("ANALYSIS COMPLETE")
        print("=" * 80)
        print(f"Successfully analyzed: {len(results)}/{len(self.language_variants)} variants")
        print(f"Page IDs discovered: {len([pid for pid in page_ids.values() if pid])}")
        print(f"Cross-language patterns: {cross_patterns}")

if __name__ == "__main__":
    analyzer = WikipediaBelphegorAnalyzer()
    analyzer.run_complete_analysis()
