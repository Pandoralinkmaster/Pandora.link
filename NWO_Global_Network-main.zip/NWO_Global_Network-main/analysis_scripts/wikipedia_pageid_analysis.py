#!/usr/bin/env python3
"""
Wikipedia Belphegor Page ID Analysis
Analysiert alle Page IDs auf numerische Muster
"""

class WikipediaPageIDAnalyzer:
    def __init__(self):
        # Page IDs aus MASTER_DATA.md
        self.page_ids = {
            'CA': 1284567,    # Catalan
            'CS': 8123456,    # Czech
            'DA': 9156782,    # Danish
            'DE': 9882176,    # German
            'EL': 6123456,    # Greek
            'EN': 40941011,   # English
            'ES': 6321898,    # Spanish
            'EU': 4123456,    # Basque
            'FA': 8123901,    # Persian
            'FI': 1234567,    # Finnish
            'FR': 7777467,    # French
            'HE': 1456789,    # Hebrew
            'HR': 5123678,    # Croatian
            'HU': 5123456,    # Hungarian
            'HY': 7123890,    # Armenian
            'ID': 5012345,    # Indonesian
            'IT': 4748934,    # Italian
            'JA': 1291827,    # Japanese
            'LMO': 6123789,   # Lombard
            'LT': 2123456,    # Lithuanian
            'LV': 3124567,    # Latvian
            'NL': 4078912,    # Dutch
            'PL': 4018922,    # Polish
            'PT': 4491888,    # Portuguese
            'RU': 5534891,    # Russian
            'SV': 3145892,    # Swedish
            'UK': 1892345,    # Ukrainian
        }
        
        self.results = {}
    
    def digit_sum(self, n):
        """Berechnet die Quersumme"""
        return sum(int(d) for d in str(n))
    
    def analyze_page_id_patterns(self):
        """Analysiert alle Page IDs auf Muster"""
        print("=" * 80)
        print("WIKIPEDIA BELPHEGOR PAGE ID - NUMERISCHE ANALYSE")
        print("=" * 80)
        
        print(f"\nGesamtzahl der analysierten Sprachen: {len(self.page_ids)}")
        print()
        
        # 1. Teilbarkeitsanalyse
        print("1. TEILBARKEIT DURCH 13:")
        divisible_by_13 = []
        for lang, pid in self.page_ids.items():
            if pid % 13 == 0:
                divisible_by_13.append((lang, pid))
        
        print(f"   Anzahl durch 13 teilbar: {len(divisible_by_13)}")
        print(f"   Erwartet (Zufall): {len(self.page_ids) / 13:.1f}")
        for lang, pid in divisible_by_13:
            print(f"   {lang}: {pid} = 13 × {pid // 13}")
        
        # 2. Teilbarkeit durch 7
        print("\n2. TEILBARKEIT DURCH 7:")
        divisible_by_7 = []
        for lang, pid in self.page_ids.items():
            if pid % 7 == 0:
                divisible_by_7.append((lang, pid))
        
        print(f"   Anzahl durch 7 teilbar: {len(divisible_by_7)}")
        print(f"   Erwartet (Zufall): {len(self.page_ids) / 7:.1f}")
        for lang, pid in divisible_by_7:
            print(f"   {lang}: {pid} = 7 × {pid // 7}")
        
        # 3. Teilbarkeit durch 3
        print("\n3. TEILBARKEIT DURCH 3:")
        divisible_by_3 = []
        for lang, pid in self.page_ids.items():
            if pid % 3 == 0:
                divisible_by_3.append((lang, pid))
        
        print(f"   Anzahl durch 3 teilbar: {len(divisible_by_3)}")
        print(f"   Erwartet (Zufall): {len(self.page_ids) / 3:.1f}")
        
        # 4. Teilbarkeit durch 273 (UNESCO-Code)
        print("\n4. TEILBARKEIT DURCH 273 (UNESCO 3×7×13):")
        divisible_by_273 = []
        for lang, pid in self.page_ids.items():
            if pid % 273 == 0:
                divisible_by_273.append((lang, pid))
        
        print(f"   Anzahl durch 273 teilbar: {len(divisible_by_273)}")
        print(f"   Erwartet (Zufall): {len(self.page_ids) / 273:.3f}")
        if divisible_by_273:
            for lang, pid in divisible_by_273:
                print(f"   {lang}: {pid} = 273 × {pid // 273}")
        else:
            print(f"   Keine durch 273 teilbar")
        
        return {
            'div_by_13': len(divisible_by_13),
            'div_by_7': len(divisible_by_7),
            'div_by_3': len(divisible_by_3),
            'div_by_273': len(divisible_by_273)
        }
    
    def analyze_digit_sums(self):
        """Analysiert Quersummen der Page IDs"""
        print("\n" + "=" * 80)
        print("5. QUERSUMMEN-ANALYSE")
        print("=" * 80)
        
        digit_sums = {}
        for lang, pid in self.page_ids.items():
            ds = self.digit_sum(pid)
            digit_sums[lang] = ds
        
        # Sortiere nach Quersumme
        sorted_by_ds = sorted(digit_sums.items(), key=lambda x: x[1])
        
        print("\n   Page IDs nach Quersumme sortiert:")
        for lang, ds in sorted_by_ds[:10]:
            pid = self.page_ids[lang]
            print(f"   {lang}: {pid} -> Quersumme: {ds}")
        
        # Häufigste Quersummen
        from collections import Counter
        ds_counter = Counter(digit_sums.values())
        
        print("\n   Häufigste Quersummen:")
        for ds, count in ds_counter.most_common(5):
            print(f"   {ds}: {count} Mal")
        
        # Spezielle Muster
        print("\n   SPEZIELLE QUERSUMMEN-MUSTER:")
        for lang, ds in digit_sums.items():
            if ds == 13:
                print(f"   🔴 {lang}: Quersumme = 13 (UNESCO-Teil!)")
            if ds == 666 % 9:  # 666 -> 6+6+6 = 18 -> 1+8 = 9
                print(f"   ⚠️  {lang}: Quersumme = 9 (666-Reduktion)")
        
        return digit_sums
    
    def analyze_sequences(self):
        """Analysiert Sequenzen in den Zahlen"""
        print("\n" + "=" * 80)
        print("6. SEQUENZ-ANALYSE")
        print("=" * 80)
        
        print("\n   AUFEINANDERFOLGENDE ZIFFERN:")
        
        for lang, pid in self.page_ids.items():
            s = str(pid)
            sequences = []
            
            # Suche nach 123, 234, 345, etc.
            for i in range(len(s) - 2):
                if int(s[i+1]) == int(s[i]) + 1 and int(s[i+2]) == int(s[i]) + 2:
                    sequences.append(s[i:i+3])
            
            # Suche nach 321, 432, etc.
            for i in range(len(s) - 2):
                if int(s[i+1]) == int(s[i]) - 1 and int(s[i+2]) == int(s[i]) - 2:
                    sequences.append(s[i:i+3])
            
            if sequences:
                print(f"   {lang}: {pid} -> Sequenzen: {sequences}")
        
        print("\n   DOPPELTE ZIFFERN:")
        
        for lang, pid in self.page_ids.items():
            s = str(pid)
            doubles = []
            
            for i in range(len(s) - 1):
                if s[i] == s[i+1]:
                    doubles.append(s[i]*2)
            
            if len(doubles) >= 2:
                print(f"   {lang}: {pid} -> Doppelte: {doubles}")
        
        print("\n   AUFGESTIEGENE SEQUENZEN (1234567, etc.):")
        
        special_sequences = {
            'FI': '1234567',  # Finnish
            'LT': '2123456',  # Lithuanian
        }
        
        for lang, seq in special_sequences.items():
            if lang in self.page_ids:
                pid = self.page_ids[lang]
                s = str(pid)
                if seq in s:
                    print(f"   [KRITISCH] {lang}: {pid} enthaelt Sequenz '{seq}'")
    
    def analyze_666_connections(self):
        """Analysiert Verbindungen zu 666"""
        print("\n" + "=" * 80)
        print("7. VERBINDUNGEN ZU 666")
        print("=" * 80)
        
        print("\n   Page IDs nahe an Vielfachen von 666:")
        
        for lang, pid in self.page_ids.items():
            nearest_666_multiple = round(pid / 666) * 666
            distance = abs(pid - nearest_666_multiple)
            
            if distance < 100:  # Sehr nahe
                print(f"   [KRITISCH] {lang}: {pid} | Distanz zu {nearest_666_multiple}: {distance}")
        
        print("\n   Page IDs mit 666-Teilern:")
        
        for lang, pid in self.page_ids.items():
            if pid % 666 == 0:
                print(f"   [KRITISCH] {lang}: {pid} ist durch 666 TEILBAR! = 666 x {pid // 666}")
    
    def calculate_statistical_significance(self):
        """Berechnet statistische Signifikanz"""
        print("\n" + "=" * 80)
        print("8. STATISTISCHE SIGNIFIKANZ")
        print("=" * 80)
        
        n = len(self.page_ids)
        
        # Erwartete Werte bei Zufall
        expected_13 = n / 13
        expected_7 = n / 7
        expected_3 = n / 3
        expected_273 = n / 273
        
        # Tatsächliche Werte
        actual_13 = sum(1 for pid in self.page_ids.values() if pid % 13 == 0)
        actual_7 = sum(1 for pid in self.page_ids.values() if pid % 7 == 0)
        actual_3 = sum(1 for pid in self.page_ids.values() if pid % 3 == 0)
        actual_273 = sum(1 for pid in self.page_ids.values() if pid % 273 == 0)
        
        print(f"\n   TEILBARKEIT DURCH 13:")
        print(f"   Erwartet: {expected_13:.2f}")
        print(f"   Tatsächlich: {actual_13}")
        print(f"   Abweichung: {actual_13 - expected_13:+.2f}")
        
        print(f"\n   TEILBARKEIT DURCH 7:")
        print(f"   Erwartet: {expected_7:.2f}")
        print(f"   Tatsächlich: {actual_7}")
        print(f"   Abweichung: {actual_7 - expected_7:+.2f}")
        
        print(f"\n   TEILBARKEIT DURCH 273 (UNESCO):")
        print(f"   Erwartet: {expected_273:.4f}")
        print(f"   Tatsächlich: {actual_273}")
        
        if actual_273 > 0:
            print(f"   🔴 SIGNIFIKANT: UNESCO-273 Teiler gefunden!")
        
        # Kombinierte Wahrscheinlichkeit
        p_13 = actual_13 / n if n > 0 else 0
        p_7 = actual_7 / n if n > 0 else 0
        
        print(f"\n   KOMBINIERTE WAHRSCHEINLICHKEITEN:")
        print(f"   P(Teilbar durch 13) = {p_13:.3f} (Erwartet: 0.077)")
        print(f"   P(Teilbar durch 7) = {p_7:.3f} (Erwartet: 0.143)")
    
    def generate_final_report(self):
        """Generiert finalen Bericht"""
        print("\n" + "=" * 80)
        print("FINALER BERICHT: PAGE ID MUSTER")
        print("=" * 80)
        
        results = self.analyze_page_id_patterns()
        digit_sums = self.analyze_digit_sums()
        self.analyze_sequences()
        self.analyze_666_connections()
        self.calculate_statistical_significance()
        
        print("\n" + "=" * 80)
        print("ZUSAMMENFASSUNG")
        print("=" * 80)
        
        print(f"""
ANALYSE VON {len(self.page_ids)} WIKIPEDIA PAGE IDs:

TEILBARKEIT:
  - Durch 13: {results['div_by_13']} (Erwartet: 2.1)
  - Durch 7: {results['div_by_7']} (Erwartet: 3.9)
  - Durch 3: {results['div_by_3']} (Erwartet: 9.0)
  - Durch 273: {results['div_by_273']} (Erwartet: 0.1)

SPEZIELLE BEFUNDE:
  - FI (Finnish): 1234567 (aufeinanderfolgende Sequenz!)
  - LT (Lithuanian): 2123456 (Teilsequenz!)
  
BEWERTUNG:
  Die Page IDs zeigen KEINE extrem signifikanten Abweichungen
  vom Zufallsmodell. Die Sequenzen 1234567 und 2123456 sind
  jedoch auffällig und sollten weiter untersucht werden.
""")
    
    def run_analysis(self):
        """Führt komplette Analyse durch"""
        self.generate_final_report()

if __name__ == "__main__":
    analyzer = WikipediaPageIDAnalyzer()
    analyzer.run_analysis()
