# Wikipedia Belphegor's Prime - Data Collection Instructions
Generated: 2026-03-24T16:31:29.789222

For each language, visit the XTools URL to collect:
- Page ID, Page Size, Total Edits, Editors count
- First edit date and user, Latest edit date and user
- Top contributors list

Then visit Wikipedia History URL to collect:
- Full revision history

============================================================

## Catalan (ca)

**XTools**: https://xtools.wmcloud.org/articleinfo/ca.wikipedia.org/Primer_de_Belfegor
**Wikipedia**: https://ca.wikipedia.org/wiki/Primer_de_Belfegor
**History**: https://ca.wikipedia.org/w/index.php?title=Primer_de_Belfegor&action=history

## Danish (da)

**XTools**: https://xtools.wmcloud.org/articleinfo/da.wikipedia.org/Belfegors_primtal
**Wikipedia**: https://da.wikipedia.org/wiki/Belfegors_primtal
**History**: https://da.wikipedia.org/w/index.php?title=Belfegors_primtal&action=history

## German (de)

**XTools**: https://xtools.wmcloud.org/articleinfo/de.wikipedia.org/Belphegors_Primzahl
**Wikipedia**: https://de.wikipedia.org/wiki/Belphegors_Primzahl
**History**: https://de.wikipedia.org/w/index.php?title=Belphegors_Primzahl&action=history

## Greek (el)

**XTools**: https://xtools.wmcloud.org/articleinfo/el.wikipedia.org/Πρώτος_του_Μπέλφεγκορ
**Wikipedia**: https://el.wikipedia.org/wiki/Πρώτος_του_Μπέλφεγκορ
**History**: https://el.wikipedia.org/w/index.php?title=Πρώτος_του_Μπέλφεγκορ&action=history

## English (en)

**XTools**: https://xtools.wmcloud.org/articleinfo/en.wikipedia.org/Belphegor's_prime
**Wikipedia**: https://en.wikipedia.org/wiki/Belphegor's_prime
**History**: https://en.wikipedia.org/w/index.php?title=Belphegor's_prime&action=history

## Spanish (es)

**XTools**: https://xtools.wmcloud.org/articleinfo/es.wikipedia.org/Primo_de_Belfegor
**Wikipedia**: https://es.wikipedia.org/wiki/Primo_de_Belfegor
**History**: https://es.wikipedia.org/w/index.php?title=Primo_de_Belfegor&action=history

## Basque (eu)

**XTools**: https://xtools.wmcloud.org/articleinfo/eu.wikipedia.org/Belfegorren_zenbaki_lehen
**Wikipedia**: https://eu.wikipedia.org/wiki/Belfegorren_zenbaki_lehen
**History**: https://eu.wikipedia.org/w/index.php?title=Belfegorren_zenbaki_lehen&action=history

## Persian (fa)

**XTools**: https://xtools.wmcloud.org/articleinfo/fa.wikipedia.org/عدد_اول_بعل_فغور
**Wikipedia**: https://fa.wikipedia.org/wiki/عدد_اول_بعل_فغور
**History**: https://fa.wikipedia.org/w/index.php?title=عدد_اول_بعل_فغور&action=history

## French (fr)

**XTools**: https://xtools.wmcloud.org/articleinfo/fr.wikipedia.org/Nombre_de_Belphégor
**Wikipedia**: https://fr.wikipedia.org/wiki/Nombre_de_Belphégor
**History**: https://fr.wikipedia.org/w/index.php?title=Nombre_de_Belphégor&action=history

## Hebrew (he)

**XTools**: https://xtools.wmcloud.org/articleinfo/he.wikipedia.org/המספר_הראשוני_של_בלפגור
**Wikipedia**: https://he.wikipedia.org/wiki/המספר_הראשוני_של_בלפגור
**History**: https://he.wikipedia.org/w/index.php?title=המספר_הראשוני_של_בלפגור&action=history

## Croatian (hr)

**XTools**: https://xtools.wmcloud.org/articleinfo/hr.wikipedia.org/Belfegorov_broj
**Wikipedia**: https://hr.wikipedia.org/wiki/Belfegorov_broj
**History**: https://hr.wikipedia.org/w/index.php?title=Belfegorov_broj&action=history

## Armenian (hy)

**XTools**: https://xtools.wmcloud.org/articleinfo/hy.wikipedia.org/Բելֆեգորի_պարզ_թիվ
**Wikipedia**: https://hy.wikipedia.org/wiki/Բելֆեգորի_պարզ_թիվ
**History**: https://hy.wikipedia.org/w/index.php?title=Բելֆեգորի_պարզ_թիվ&action=history

## Indonesian (id)

**XTools**: https://xtools.wmcloud.org/articleinfo/id.wikipedia.org/Bilangan_prima_Belfegor
**Wikipedia**: https://id.wikipedia.org/wiki/Bilangan_prima_Belfegor
**History**: https://id.wikipedia.org/w/index.php?title=Bilangan_prima_Belfegor&action=history

## Italian (it)

**XTools**: https://xtools.wmcloud.org/articleinfo/it.wikipedia.org/Numero_di_Belfagor
**Wikipedia**: https://it.wikipedia.org/wiki/Numero_di_Belfagor
**History**: https://it.wikipedia.org/w/index.php?title=Numero_di_Belfagor&action=history

## Japanese (ja)

**XTools**: https://xtools.wmcloud.org/articleinfo/ja.wikipedia.org/ベルフェゴール素数
**Wikipedia**: https://ja.wikipedia.org/wiki/ベルフェゴール素数
**History**: https://ja.wikipedia.org/w/index.php?title=ベルフェゴール素数&action=history

## Lombard (lmo)

**XTools**: https://xtools.wmcloud.org/articleinfo/lmo.wikipedia.org/Numer_de_Belfagor
**Wikipedia**: https://lmo.wikipedia.org/wiki/Numer_de_Belfagor
**History**: https://lmo.wikipedia.org/w/index.php?title=Numer_de_Belfagor&action=history

## Lithuanian (lt)

**XTools**: https://xtools.wmcloud.org/articleinfo/lt.wikipedia.org/Belfegoro_skaičius
**Wikipedia**: https://lt.wikipedia.org/wiki/Belfegoro_skaičius
**History**: https://lt.wikipedia.org/w/index.php?title=Belfegoro_skaičius&action=history

## Latvian (lv)

**XTools**: https://xtools.wmcloud.org/articleinfo/lv.wikipedia.org/Belfegora_pirmskaitlis
**Wikipedia**: https://lv.wikipedia.org/wiki/Belfegora_pirmskaitlis
**History**: https://lv.wikipedia.org/w/index.php?title=Belfegora_pirmskaitlis&action=history

## Dutch (nl)

**XTools**: https://xtools.wmcloud.org/articleinfo/nl.wikipedia.org/Priemgetal_van_Belphegor
**Wikipedia**: https://nl.wikipedia.org/wiki/Priemgetal_van_Belphegor
**History**: https://nl.wikipedia.org/w/index.php?title=Priemgetal_van_Belphegor&action=history

## Polish (pl)

**XTools**: https://xtools.wmcloud.org/articleinfo/pl.wikipedia.org/Liczba_pierwsza_Belfegora
**Wikipedia**: https://pl.wikipedia.org/wiki/Liczba_pierwsza_Belfegora
**History**: https://pl.wikipedia.org/w/index.php?title=Liczba_pierwsza_Belfegora&action=history

## Portuguese (pt)

**XTools**: https://xtools.wmcloud.org/articleinfo/pt.wikipedia.org/Primo_de_Belfegor
**Wikipedia**: https://pt.wikipedia.org/wiki/Primo_de_Belfegor
**History**: https://pt.wikipedia.org/w/index.php?title=Primo_de_Belfegor&action=history

## Russian (ru)

**XTools**: https://xtools.wmcloud.org/articleinfo/ru.wikipedia.org/Простое_число_Бельфегора
**Wikipedia**: https://ru.wikipedia.org/wiki/Простое_число_Бельфегора
**History**: https://ru.wikipedia.org/w/index.php?title=Простое_число_Бельфегора&action=history

## Swedish (sv)

**XTools**: https://xtools.wmcloud.org/articleinfo/sv.wikipedia.org/Belfegors_primtal
**Wikipedia**: https://sv.wikipedia.org/wiki/Belfegors_primtal
**History**: https://sv.wikipedia.org/w/index.php?title=Belfegors_primtal&action=history

## Ukrainian (uk)

**XTools**: https://xtools.wmcloud.org/articleinfo/uk.wikipedia.org/Просте_число_Бельфеґора
**Wikipedia**: https://uk.wikipedia.org/wiki/Просте_число_Бельфеґора
**History**: https://uk.wikipedia.org/w/index.php?title=Просте_число_Бельфеґора&action=history

