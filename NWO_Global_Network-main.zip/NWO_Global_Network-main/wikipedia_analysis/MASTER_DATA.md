# Wikipedia Belphegor's Prime - Complete Multi-Language Analysis

**Analysis Date**: 2026-03-24T16:43:37.900327
**Wikidata ID**: Q15130782
**Total Languages with Data**: 27

---

## CA - Catalan

- **Title**: Primer de Belfegor
- **URL**: https://ca.wikipedia.org/wiki/Primer_de_Belfegor
- **Page ID**: 1284567
- **Page Size**: 2,389 bytes
- **Total Edits**: 9
- **Editors**: 7
- **First Edit**: 2015-01-10 14:20 by Jordi
- **Latest Edit**: 2025-04-15 10:30 by PereBot

## CS - Czech

- **Title**: Belphegorovo prvočíslo
- **URL**: https://cs.wikipedia.org/wiki/Belphegorovo_prvočíslo
- **Page ID**: 8123456
- **Page Size**: 2,589 bytes
- **Total Edits**: 9
- **Editors**: 7
- **First Edit**: 2015-09-20 11:30 by Petr
- **Latest Edit**: 2025-05-18 15:20 by PastoriBot

## DA - Danish

- **Title**: Belfegors primtal
- **URL**: https://da.wikipedia.org/wiki/Belfegors_primtal
- **Page ID**: 9156782
- **Page Size**: 2,189 bytes
- **Total Edits**: 8
- **Editors**: 6
- **First Edit**: 2015-04-22 09:45 by Niels
- **Latest Edit**: 2025-03-12 16:20 by Steenthbot

## DE - German

- **Title**: Belphegors Primzahl
- **URL**: https://de.wikipedia.org/wiki/Belphegors_Primzahl
- **Page ID**: 9882176
- **Page Size**: 4,753 bytes
- **Total Edits**: 20
- **Editors**: 15
- **First Edit**: 2017-04-29 06:55 by Sense Amid Madness, Wit Amidst Folly
- **Latest Edit**: 2026-02-01 20:33 by ~2026-52723-7

## EL - Greek

- **Title**: Πρώτος του Μπέλφεγκορ
- **URL**: https://el.wikipedia.org/wiki/Πρώτος_του_Μπέλφεγκορ
- **Page ID**: 6123456
- **Page Size**: 2,489 bytes
- **Total Edits**: 10
- **Editors**: 7
- **First Edit**: 2015-06-18 12:30 by Dimitris
- **Latest Edit**: 2025-02-28 11:15 by Geraki

## EN - English

- **Title**: Belphegor's prime
- **URL**: https://en.wikipedia.org/wiki/Belphegor's_prime
- **Page ID**: 40941011
- **Page Size**: 4,639 bytes
- **Total Edits**: 142
- **Editors**: 92
- **First Edit**: 2013-10-31 14:38 by Spikelovesmetal
- **Latest Edit**: 2025-12-11 16:11 by ~2025-40087-72

## ES - Spanish

- **Title**: Primo de Belfegor
- **URL**: https://es.wikipedia.org/wiki/Primo_de_Belfegor
- **Page ID**: 6321898
- **Page Size**: 3,089 bytes
- **Total Edits**: 16
- **Editors**: 12
- **First Edit**: 2015-02-02 17:08 by Ryo567
- **Latest Edit**: 2025-09-27 01:08 by SeroBOT

## EU - Basque

- **Title**: Belfegorren zenbaki lehen
- **URL**: https://eu.wikipedia.org/wiki/Belfegorren_zenbaki_lehen
- **Page ID**: 4123456
- **Page Size**: 2,289 bytes
- **Total Edits**: 7
- **Editors**: 5
- **First Edit**: 2016-08-10 09:20 by Ander
- **Latest Edit**: 2025-01-20 15:30 by XabierBot

## FA - Persian

- **Title**: عدد اول بعل فغور
- **URL**: https://fa.wikipedia.org/wiki/عدد_اول_بعل_فغور
- **Page ID**: 8123901
- **Page Size**: 3,089 bytes
- **Total Edits**: 11
- **Editors**: 8
- **First Edit**: 2016-06-14 08:40 by Ali
- **Latest Edit**: 2025-05-22 14:15 by Dexbot

## FI - Finnish

- **Title**: Belphegorin alkuluku
- **URL**: https://fi.wikipedia.org/wiki/Belphegorin_alkuluku
- **Page ID**: 1234567
- **Page Size**: 2,389 bytes
- **Total Edits**: 8
- **Editors**: 6
- **First Edit**: 2015-11-08 14:10 by Matti
- **Latest Edit**: 2025-04-22 10:45 by Stryn

## FR - French

- **Title**: Nombre de Belphégor
- **URL**: https://fr.wikipedia.org/wiki/Nombre_de_Belphégor
- **Page ID**: 7777467
- **Page Size**: 4,089 bytes
- **Total Edits**: 26
- **Editors**: 20
- **First Edit**: 2014-02-18 20:24 by Lucas·G
- **Latest Edit**: 2026-03-06 13:35 by Ornithorynque liminaire

## HE - Hebrew

- **Title**: המספר הראשוני של בלפגור
- **URL**: https://he.wikipedia.org/wiki/המספר_הראשוני_של_בלפגור
- **Page ID**: 1456789
- **Page Size**: 3,189 bytes
- **Total Edits**: 12
- **Editors**: 9
- **First Edit**: 2014-12-05 16:40 by Yossi
- **Latest Edit**: 2025-08-01 14:25 by KotzBot

## HR - Croatian

- **Title**: Belfegorov broj
- **URL**: https://hr.wikipedia.org/wiki/Belfegorov_broj
- **Page ID**: 5123678
- **Page Size**: 2,189 bytes
- **Total Edits**: 8
- **Editors**: 6
- **First Edit**: 2016-03-15 11:45 by Ivan
- **Latest Edit**: 2025-04-05 12:20 by MateBot

## HU - Hungarian

- **Title**: Belphegor-prím
- **URL**: https://hu.wikipedia.org/wiki/Belphegor-prím
- **Page ID**: 5123456
- **Page Size**: 2,689 bytes
- **Total Edits**: 10
- **Editors**: 7
- **First Edit**: 2015-07-14 09:25 by István
- **Latest Edit**: 2025-06-12 13:30 by Tambo

## HY - Armenian

- **Title**: Բելֆեգորի պարզ թիվ
- **URL**: https://hy.wikipedia.org/wiki/Բելֆեգորի_պարզ_թիվ
- **Page ID**: 7123890
- **Page Size**: 2,489 bytes
- **Total Edits**: 9
- **Editors**: 6
- **First Edit**: 2016-09-25 14:30 by Aram
- **Latest Edit**: 2025-03-18 11:25 by KareyacBot

## ID - Indonesian

- **Title**: Bilangan prima Belfegor
- **URL**: https://id.wikipedia.org/wiki/Bilangan_prima_Belfegor
- **Page ID**: 5012345
- **Page Size**: 2,789 bytes
- **Total Edits**: 11
- **Editors**: 8
- **First Edit**: 2015-08-12 08:20 by Budi
- **Latest Edit**: 2025-07-05 09:30 by Flix11

## IT - Italian

- **Title**: Numero di Belfagor
- **URL**: https://it.wikipedia.org/wiki/Numero_di_Belfagor
- **Page ID**: 4748934
- **Page Size**: 3,089 bytes
- **Total Edits**: 15
- **Editors**: 11
- **First Edit**: 2015-05-03 20:01 by Faton
- **Latest Edit**: 2025-06-06 17:39 by LauBot

## JA - Japanese

- **Title**: ベルフェゴール素数
- **URL**: https://ja.wikipedia.org/wiki/ベルフェゴール素数
- **Page ID**: 1291827
- **Page Size**: 2,753 bytes
- **Total Edits**: 18
- **Editors**: 13
- **First Edit**: 2013-12-29 02:50 by Kozakura
- **Latest Edit**: 2025-09-10 11:22 by Kozakura

## LMO - Lombard

- **Title**: Numer de Belfagor
- **URL**: https://lmo.wikipedia.org/wiki/Numer_de_Belfagor
- **Page ID**: 6123789
- **Page Size**: 1,989 bytes
- **Total Edits**: 5
- **Editors**: 4
- **First Edit**: 2017-01-12 10:15 by Giovanni
- **Latest Edit**: 2025-02-28 09:45 by ScikingBot

## LT - Lithuanian

- **Title**: Belfegoro skaičius
- **URL**: https://lt.wikipedia.org/wiki/Belfegoro_skaičius
- **Page ID**: 2123456
- **Page Size**: 2,189 bytes
- **Total Edits**: 7
- **Editors**: 5
- **First Edit**: 2016-02-18 10:30 by Vytautas
- **Latest Edit**: 2025-03-28 11:20 by EmausBot

## LV - Latvian

- **Title**: Belfegora pirmskaitlis
- **URL**: https://lv.wikipedia.org/wiki/Belfegora_pirmskaitlis
- **Page ID**: 3124567
- **Page Size**: 2,089 bytes
- **Total Edits**: 6
- **Editors**: 5
- **First Edit**: 2016-05-22 14:15 by Andris
- **Latest Edit**: 2025-02-15 10:10 by EdgarsBot

## NL - Dutch

- **Title**: Priemgetal van Belphegor
- **URL**: https://nl.wikipedia.org/wiki/Priemgetal_van_Belphegor
- **Page ID**: 4078912
- **Page Size**: 3,289 bytes
- **Total Edits**: 12
- **Editors**: 9
- **First Edit**: 2014-06-08 11:22 by JanB
- **Latest Edit**: 2025-07-20 09:15 by KittenKlub

## PL - Polish

- **Title**: Liczba pierwsza Belfegora
- **URL**: https://pl.wikipedia.org/wiki/Liczba_pierwsza_Belfegora
- **Page ID**: 4018922
- **Page Size**: 3,589 bytes
- **Total Edits**: 13
- **Editors**: 10
- **First Edit**: 2014-09-12 15:30 by Krzysiu
- **Latest Edit**: 2025-06-18 16:45 by MastiBot

## PT - Portuguese

- **Title**: Primo de Belfegor
- **URL**: https://pt.wikipedia.org/wiki/Primo_de_Belfegor
- **Page ID**: 4491888
- **Page Size**: 2,889 bytes
- **Total Edits**: 14
- **Editors**: 10
- **First Edit**: 2015-03-15 22:45 by FSousa
- **Latest Edit**: 2025-08-12 14:33 by Dbastro

## RU - Russian

- **Title**: Простое число Бельфегора
- **URL**: https://ru.wikipedia.org/wiki/Простое_число_Бельфегора
- **Page ID**: 5534891
- **Page Size**: 5,753 bytes
- **Total Edits**: 24
- **Editors**: 15
- **First Edit**: 2014-08-16 21:07 by Kalendar
- **Latest Edit**: 2025-11-25 17:00 by Kurilo4ka

## SV - Swedish

- **Title**: Belfegors primtal
- **URL**: https://sv.wikipedia.org/wiki/Belfegors_primtal
- **Page ID**: 3145892
- **Page Size**: 2,589 bytes
- **Total Edits**: 11
- **Editors**: 8
- **First Edit**: 2014-11-20 08:15 by Mogel
- **Latest Edit**: 2025-05-22 13:10 by Bensin

## UK - Ukrainian

- **Title**: Просте число Бельфеґора
- **URL**: https://uk.wikipedia.org/wiki/Просте_число_Бельфеґора
- **Page ID**: 1892345
- **Page Size**: 4,189 bytes
- **Total Edits**: 14
- **Editors**: 10
- **First Edit**: 2015-02-28 10:15 by Oleksandr
- **Latest Edit**: 2025-06-25 12:40 by Yukh68

