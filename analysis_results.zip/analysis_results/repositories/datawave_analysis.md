# DataWave - Distributed Data Processing Framework

## Repository Information
- **Link**: https://github.com/NationalSecurityAgency/datawave
- **Owner**: NationalSecurityAgency
- **Type**: Java-based Framework
- **License**: Apache License 2.0
- **Build System**: Maven (Multi-module)
- **Key Dependencies**: Apache Accumulo, Zookeeper, Hadoop, Wildfly

## Überblick

DataWave ist ein Java-basiertes Ingest- und Query-Framework, das Apache Accumulo nutzt, um schnellen, sicheren Zugriff auf Daten zu bieten.

### Hauptfunktionen

1. **Data Fusion**: Strukturierte und unstrukturierte Datensätze zusammenführen
2. **Graph Construction**: Verteilte Graphen konstruieren und analysieren
3. **Multi-Tenant Architecture**: Mehrere Mandanten mit unterschiedlichen Sicherheitsanforderungen
4. **Fine-Grained Access Control**: Detaillierte Zugriffskontrolle mit PKI-Integration

## Repository-Struktur

### Hauptverzeichnisse

```
datawave/
├── contrib/
│   └── datawave-utils ..................... Hilfsfunktionen
├── core/
│   ├── in-memory-accumulo ................ In-Memory Datenbank
│   └── metrics-reporter .................. Performance-Metriken
├── microservices/
│   ├── microservice-parent ............... Parent POM
│   ├── microservice-service-parent ....... Service Parent
│   ├── starters/
│   │   ├── audit ......................... Audit Service Starter
│   │   ├── cache ......................... Cache Starter
│   │   ├── cached-results ............... Cached Results Starter
│   │   ├── datawave ...................... DataWave Starter
│   │   ├── metadata ...................... Metadata Starter
│   │   ├── query ......................... Query Starter
│   │   └── query-metric .................. Query Metric Starter
│   └── services/
│       ├── accumulo ...................... Accumulo Service
│       ├── audit ......................... Audit Service
│       ├── authorization ................ Authorization Service
│       ├── config ........................ Configuration Service
│       ├── dictionary .................... Dictionary Service
│       ├── file-provider ................ File Provider Service
│       ├── hazelcast ..................... Hazelcast Service
│       ├── map ........................... Map Service
│       ├── mapreduce-query .............. MapReduce Query Service
│       ├── modification .................. Modification Service
│       ├── query ......................... Query Service
│       ├── query-executor ............... Query Executor Service
│       └── query-metric .................. Query Metric Service
├── docker/ .............................. Docker-Konfiguration
└── docs/ ................................ Dokumentation
```

### Submodule-System

DataWave nutzt **git subrepo** Mechanismus zur Verwaltung von Submodulen:

```bash
# Submodul klonen
git subrepo clone <repo> <dir>

# Änderungen pullen
git subrepo pull <dir>
```

Jedes Submodul enthält eine `.gitrepo` Datei, die den Ursprung des Codes verfolgt.

## Microservices-Architektur

### Service-Kategorien

#### 1. Core Services
- **Accumulo Service**: Verbindung zu Apache Accumulo
- **Authorization Service**: Benutzer-Authentifizierung und -Autorisierung
- **Audit Service**: Protokollierung von Aktivitäten
- **Config Service**: Zentrale Konfigurationsverwaltung

#### 2. Query Services
- **Query Service**: Haupt-Query-Verarbeitung
- **Query Executor Service**: Query-Ausführung
- **Query Metric Service**: Query-Performance-Metriken
- **MapReduce Query Service**: Verteilte Query-Verarbeitung

#### 3. Data Services
- **Dictionary Service**: Datenstruktur-Definitionen
- **File Provider Service**: Dateiverwaltung
- **Metadata Service**: Metadaten-Verwaltung
- **Modification Service**: Datenänderungen

#### 4. Infrastructure Services
- **Hazelcast Service**: In-Memory Data Grid
- **Map Service**: Daten-Mapping
- **Cache Service**: Caching-Layer

### Starters (Spring Boot Integration)

DataWave bietet Spring Boot Starters für einfache Integration:

```
microservices/starters/
├── audit ........................ @EnableAudit
├── cache ........................ @EnableCache
├── cached-results .............. @EnableCachedResults
├── datawave ..................... @EnableDataWave
├── metadata ..................... @EnableMetadata
├── query ........................ @EnableQuery
└── query-metric ................ @EnableQueryMetric
```

## Build-Prozess

### Standard Build (ohne Services)

```bash
mvn -Ddocker-release -Ddist clean install -T 1C
```

**Flags**:
- `-Ddocker-release`: Docker-Image erstellen
- `-Ddist`: Distribution bauen
- `-T 1C`: Multi-threaded Build (1 Thread pro Core)

### Vollständiger Build (mit Services)

```bash
mvn -Ddocker-release -Dmicroservice-docker -Ddist -Dutils -Dservices -Dstarters clean install -T 1C
```

**Zusätzliche Flags**:
- `-Dmicroservice-docker`: Microservice Docker-Images
- `-Dutils`: Utility-Module
- `-Dservices`: Services
- `-Dstarters`: Spring Boot Starters
- `-DonlyServiceApis`: Nur Service-APIs (ohne Implementierung)

### Versioning

**Wichtig**: Util-Module, Starters und Services sind unabhängig versioniert:

```
Snapshot-Versionen in Sub-Repos sind nicht miteinander verbunden
Jedes Modul kann unabhängig released werden
```

## Key Dependencies

### Binäre Abhängigkeiten

| Komponente | Rolle |
|-----------|-------|
| Apache Accumulo | Verteilte Datenbank |
| Zookeeper | Koordination |
| Hadoop | Verteilte Verarbeitung |
| Wildfly | Application Server |

### Versioning-Hinweise

- **Accumulo**: Version 2.1.2 in Root POM (MiniAccumuloCluster Kompatibilität)
- **Quickstart**: Überschreibt `<version.accumulo>` für neuere Versionen
- **Verschiedene Versionen**: Microservices nutzen unterschiedliche Versionen

## Deployment

### Docker Quickstart

```bash
# Docker-basierter Quickstart
docker-compose up

# Siehe docker/README.md für Details
```

### Microservices Deployment

Siehe [Docker Readme](docker/README.md#usage) für:
- Quickstart-Deployment
- Microservices-Konfiguration
- Production-Setup

## Use Cases

### 1. Data Fusion
```
Strukturierte Daten + Unstrukturierte Daten → Unified Query Interface
```

### 2. Graph Analysis
```
Entities + Relationships → Distributed Graph Construction
```

### 3. Multi-Tenant Systems
```
Tenant A (Security Level 1) + Tenant B (Security Level 2) → Isolated Access
```

### 4. Fine-Grained Access Control
```
User Authorization + PKI Integration → Row/Column-Level Security
```

## Dokumentation

- **Quickstart**: https://code.nsa.gov/datawave/docs/quickstart
- **Full Docs**: https://code.nsa.gov/datawave/docs/
- **Build Instructions**: BUILDME.md

## Integration Points

### Apache Accumulo Integration
- Distributed key-value store
- Security-first design
- Multi-tenant support

### Spring Boot Integration
- Auto-configuration starters
- Microservices framework
- Cloud-ready deployment

### Hadoop Integration
- Distributed processing
- MapReduce support
- Large-scale data handling

## Code Organization Pattern

DataWave folgt einem **Multi-Module Maven** Pattern:

```
Parent POM
├── Core Modules (in-memory, metrics)
├── Microservice Modules
│   ├── Service Parents
│   ├── Starters
│   └── Services
└── Utility Modules
```

Jedes Modul ist:
- Unabhängig versioniert
- Separat deploybar
- Eigenständig testbar

## Key Technologies

| Technologie | Verwendung |
|------------|-----------|
| Java | Hauptsprache |
| Maven | Build-System |
| Apache Accumulo | Datenbank |
| Spring Boot | Microservices |
| Docker | Containerisierung |
| Zookeeper | Koordination |
| Hadoop | Verteilte Verarbeitung |

## Zusammenfassung

DataWave ist ein **Enterprise-Grade Framework** für:

1. **Sichere Datenverarbeitung**: Fine-grained access control
2. **Verteilte Systeme**: Microservices-Architektur
3. **Multi-Tenant Support**: Isolierte Datenzugriffe
4. **Graph Analysis**: Beziehungen zwischen Entitäten
5. **Data Fusion**: Heterogene Datenquellen

Die Architektur basiert auf:
- **Modularen Komponenten**: Unabhängige Microservices
- **Spring Boot Integration**: Moderne Java-Entwicklung
- **Docker Support**: Cloud-ready Deployment
- **Apache Accumulo**: Sichere, verteilte Datenbank

---

**Analysiert**: 15. Juni 2026  
**Status**: Repository-Struktur und Architektur dokumentiert  
**Nächster Schritt**: Detaillierte Code-Analyse der Services
