# HIRS - Host Integrity at Runtime and Start-up

## Repository Information
- **Link**: https://github.com/nsacyber/HIRS
- **Owner**: NSA Cyberspace (nsacyber)
- **Type**: TPM Attestation & Supply Chain Validation
- **License**: Open Source
- **Latest Version**: 3.0 (Multi-OS Support)
- **Build System**: Gradle (v3.0+), Maven (Legacy)
- **Base OS**: Rocky Linux (v3.0)
- **Documentation**: Wiki + PDF Guides

## Überblick

HIRS ist ein **Attestation Certificate Authority (ACA)** und **TPM Provisioning System** mit Trusted Computing-basierter Supply Chain Validation.

### Kernfunktionalität

1. **TPM Provisioning**: Attestation Identity Credentials ausstellen
2. **Supply Chain Validation**: Endorsement und Platform Credentials validieren
3. **Firmware Integrity**: Firmware-Hashes gegen OEM-Werte validieren
4. **Platform Validation**: Hardware-Komponenten-Provenance überprüfen
5. **Reference Integrity Manifest (RIM)**: Firmware-Validierung

## Architektur

### Komponenten

```
HIRS System
├── TPM Provisioner (Client)
│   ├── Windows (10, 11)
│   ├── Linux (CentOS 7, RHEL 7+, Rocky 7+, Ubuntu 18+)
│   └── HIRS_Provisioner.NET (C#)
├── Attestation Certificate Authority (ACA)
│   ├── Web Server (Tomcat)
│   ├── Database (MariaDB)
│   └── Portal Interface
├── Certificate Validation
│   ├── EK Credential Chain
│   ├── Platform Credential Chain
│   └── RIM Validation
└── Tools
    ├── tcg_rim_tool
    ├── tcg_eventlog_tool
    └── Platform Certificate Creator
```

### TPM Provisioning Flow

```
Device (TPM)
    ↓
HIRS Provisioner (Client)
    ↓ (REST Calls)
Attestation Certificate Authority (ACA)
    ↓
Validation & Policy Checking
    ↓
Attestation Identity Credential (AIC)
    ↓
Device (TPM NvRAM)
```

## Versionshistorie

### Version 3.0 (Aktuell)
- **Status**: Vollständig überarbeitete Architektur
- **Basis**: Rocky Linux
- **Build**: Gradle
- **Features**:
  - Multi-OS Support
  - PC Client RIM 1.1 Specification
  - Composite RIMs
  - Timestamps und Counter Signatures
  - Docker Images für jedes Release
  - Detaillierte TCG Event Log Linkage

### Version 2.2
- **Feature**: HIRS_Provisioner.NET (C#)
- **Plattformen**: Windows + Linux
- **Portabilität**: Erweiterte OS-Unterstützung

### Version 2.0
- **Feature**: PC Client RIM Specification
- **Firmware Validation**: RIM Bundle Upload/Viewing
- **Policy**: Firmware Validation erforderlich

### Version 1.1
- **Feature**: Platform Certificate v1.1 Specification
- **Delta Certificates**: Supply Chain Entities

## Funktionalität

### TPM Provisioner Features

1. **Attestation Identity Request**: AIC-Anforderung
2. **TPM Ownership**: TPM-Übernahme wenn nicht owned
3. **REST Integration**: ACA-Kommunikation
4. **NvRAM Reading**: Credentials aus TPM auslesen
5. **Platform Validation**: Hardware/Network/Firmware/OS Info

### Attestation Certificate Authority Features

1. **AIC Issuance**: Attestation Identity Credentials ausstellen
2. **Policy Configuration**: Validierungsrichtlinien setzen
3. **Supply Chain Validation**: TCG-basierte Validierung
4. **Credential Validation**: EK und Platform Credentials
5. **Dashboard**: Validation Reports, Credentials, Trust Chains

### Validation Features

#### Endorsement Credential Validation
- **Standard**: TCG EK Credential Profile for TPM 2.0
- **Zweck**: OEM-Authentizität des TPM überprüfen
- **Verifikation**: Endorsement Key vom OEM platziert

#### Platform Credential Validation
- **Standard**: TCG Platform Attribute Credential Profile v1.1
- **Zweck**: Hardware-Provenance überprüfen
- **Verifikation**: Motherboard, Chassis, Komponenten-Info

#### Firmware Integrity Validation
- **RIM Bundles**: OEM-signierte Firmware-Hashes
- **PCR Verification**: TPM Platform Configuration Registers
- **Boot Variables**: UEFI/BIOS Integrität (Secure Boot)

### Reference Integrity Manifest (RIM)

- **Format**: NISTIR 8060 compatible SWID tags
- **Signierung**: Digitale Signatur erforderlich
- **Features**: Composite RIMs, Timestamps, Counter Signatures
- **Tool**: tcg_rim_tool für RIM-Erstellung

## Deployment

### ACA Installation

#### CentOS 7
```bash
yum install HIRS_AttestationCA*el7.noarch.rpm
```

#### Docker (Alle Versionen)
```bash
# Docker Image von GitHub Packages
docker pull ghcr.io/nsacyber/hirs:latest
docker run -d -p 8080:8080 ghcr.io/nsacyber/hirs:latest
```

### Provisioner Installation

#### Windows (10, 11)
```powershell
# MSI Package installieren
# Siehe HIRS_Provisioner.NET README
```

#### Linux (CentOS 7, RHEL 7+, Rocky 7+, Ubuntu 18+)
```bash
# RPM oder DEB Package
sudo yum install HIRS_Provisioner*el7.noarch.rpm
# oder
sudo apt install hirs-provisioner*.deb
```

### Provisioning Prozess

```bash
# 1. TPM in BIOS/UEFI aktivieren
# 2. Provisioner installieren
# 3. Provisioning starten
sudo tpm_aca_provision

# 4. ACA Portal aufrufen
https://ACAPortalAddress:ACAPortalPort/HIRS_AttestationCAPortal/portal/index
```

## Systemanforderungen

### ACA Server
- **OS**: CentOS 7 (Legacy), Rocky Linux (v3.0+)
- **Java**: JDK (aktuell)
- **Tomcat**: Aktuell
- **MariaDB**: Aktuell
- **Gradle**: v3.0+

### Provisioner
- **Windows**: 10, 11
- **Linux**: CentOS 7, RHEL 7+, Rocky 7+, Ubuntu 18+
- **TPM**: 2.0 (1.2 in Legacy-Versionen)
- **Runtime**: .NET (v2.2+)

## Tools

### tcg_rim_tool
- **Zweck**: RIM-Erstellung
- **Format**: NISTIR 8060 SWID tags
- **Features**: Digitale Signierung
- **Dokumentation**: TCG RIM Tool Users Guide

### tcg_eventlog_tool
- **Zweck**: TCG Event Log Analyse
- **Features**: Event Log Parsing und Visualisierung
- **Dokumentation**: TCG Event Log Tool Users Guide

### Platform Certificate Creator (paccor)
- **Repository**: https://github.com/nsacyber/paccor
- **Zweck**: Platform Certificates erstellen
- **Unterstützung**: Base und Delta Certificates

## Use Cases

### 1. Supply Chain Validation
```
Device Attestation → Credential Validation → Supply Chain Verification
```

### 2. Firmware Integrity
```
TPM Measurements → RIM Comparison → Firmware Validation
```

### 3. Device Provisioning
```
New Device → TPM Ownership → ACA Provisioning → Attestation Credential
```

### 4. Compliance Monitoring
```
Continuous Attestation → Policy Enforcement → Compliance Reports
```

## Sicherheitsmerkmale

### Trusted Computing
- **TPM 2.0**: Trusted Platform Module
- **Attestation**: Kryptographische Attestation
- **Credentials**: Digitale Zertifikate

### Supply Chain Security
- **EK Validation**: Endorsement Key Authentizität
- **Platform Validation**: Hardware-Provenance
- **Firmware Validation**: Firmware-Integrität
- **OEM Trust**: Hersteller-Authentizität

### Policy Enforcement
- **Validation Policies**: Konfigurierbare Regeln
- **Certificate Chains**: Trust Chain Validation
- **Credential Management**: Credential Import/Export

## Community & Support

### Documentation
- **Installation**: https://github.com/nsacyber/HIRS/wiki/installation_notes
- **Build Guide**: https://github.com/nsacyber/HIRS/wiki/Hirs-build-guide
- **FAQ**: https://github.com/nsacyber/HIRS/wiki/FAQ
- **Debug Guides**: Provisioner & ACA Debug

### GitHub Discussions
- **Development Changes**: https://github.com/nsacyber/HIRS/discussions/498
- **Support**: Community Support
- **Notifications**: Development Announcements

## Zusammenfassung

HIRS ist ein **Enterprise-Grade Attestation System**, das:

1. **Sicherheit**: TPM-basierte Attestation
2. **Validierung**: Supply Chain Validation
3. **Firmware**: Firmware-Integrität überprüfen
4. **Compliance**: Policy-Enforcement
5. **Skalierbarkeit**: Multi-OS Support (v3.0+)

### Architektur-Merkmale
- **TPM-native**: Trusted Platform Module Integration
- **TCG-konform**: Trusted Computing Group Standards
- **Multi-Platform**: Windows + Linux (v3.0+)
- **Enterprise-Ready**: Production-Deployment
- **Containerisiert**: Docker-Support

### Ideal für
- Supply Chain Security
- Device Attestation
- Firmware Validation
- Compliance Monitoring
- Critical Infrastructure

### Besonderheiten
- **TCG Standards**: Vollständige TCG-Konformität
- **RIM Support**: Reference Integrity Manifests
- **Policy-basiert**: Flexible Validierungsrichtlinien
- **Open Source**: Transparente Sicherheit
- **NSA-entwickelt**: Vertrauenswürdige Quelle

---

**Analysiert**: 15. Juni 2026  
**Status**: Repository-Struktur, Architektur und Funktionalität dokumentiert  
**Version**: 3.0  
**Nächster Schritt**: Security Guidance Repositories Analyse
