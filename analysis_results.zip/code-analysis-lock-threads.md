# Code-Analyse: lock-threads.yml GitHub Actions Workflow

## Datei-Information
**Dateiname**: `.github/workflows/lock-threads.yml`  
**Typ**: GitHub Actions Workflow (YAML)  
**Pfad**: `Hack-with-Github/Awesome-Hacking/.github/workflows/lock-threads.yml`  
**Letzter Commit**: Aug 22, 2024 (PR #163)  
**Autor**: Chandrapal Badshah (@Chan9390), 0xbadshah

## Zeilenweise Code-Analyse

### Zeile 1: Workflow-Name
```yaml
name: 'Lock Threads'
```
**Analyse**: Definiert den Namen des GitHub Actions Workflows als "Lock Threads". Dieser Name wird in der GitHub Actions UI angezeigt.

### Zeile 3-6: Trigger-Konfiguration
```yaml
on:
  schedule:
    - cron: '0 * * * *'
  workflow_dispatch:
```
**Analyse**:
- **Zeile 3**: `on:` - Definiert die Auslöser für den Workflow
- **Zeile 4**: `schedule:` - Aktiviert zeitgesteuerte Ausführung
- **Zeile 5**: `cron: '0 * * * *'` - Cron-Expression für stündliche Ausführung (jede Stunde zur Minute 0)
  - Format: `minute hour day month day-of-week`
  - `0` = Minute 0
  - `*` = Jede Stunde
  - `*` = Jeden Tag des Monats
  - `*` = Jeden Monat
  - `*` = Jeden Wochentag
- **Zeile 6**: `workflow_dispatch:` - Erlaubt manuelle Auslösung über GitHub UI

**Zweck**: Der Workflow wird automatisch jede Stunde ausgeführt oder kann manuell ausgelöst werden.

### Zeile 8-12: Berechtigungen
```yaml
permissions:
  issues: write
  pull-requests: write
  discussions: write
```
**Analyse**:
- **Zeile 8**: `permissions:` - Definiert die Berechtigungen für den Workflow
- **Zeile 9**: `issues: write` - Schreibzugriff auf Issues (zum Sperren/Entsperren)
- **Zeile 10**: `pull-requests: write` - Schreibzugriff auf Pull Requests (zum Sperren/Entsperren)
- **Zeile 11**: `discussions: write` - Schreibzugriff auf Diskussionen

**Zweck**: Erteilt dem Workflow die notwendigen Berechtigungen, um Threads zu sperren.

### Zeile 14-15: Concurrency-Kontrolle
```yaml
concurrency:
  group: lock-threads
```
**Analyse**:
- **Zeile 14**: `concurrency:` - Definiert Concurrency-Kontrolle
- **Zeile 15**: `group: lock-threads` - Gruppiert alle Ausführungen unter "lock-threads"

**Zweck**: Verhindert, dass mehrere Instanzen des Workflows gleichzeitig laufen. Nur eine Ausführung pro Gruppe ist gleichzeitig aktiv.

### Zeile 17-24: Job-Definition
```yaml
jobs:
  action:
    runs-on: ubuntu-latest
    steps:
      - uses: dessant/lock-threads@v5
        with:
          issue-inactive-days: '7'
          pr-inactive-days: '7'
```

**Zeile 17**: `jobs:` - Definiert die Jobs des Workflows

**Zeile 18**: `action:` - Job-Name (eindeutige Kennung für diesen Job)

**Zeile 19**: `runs-on: ubuntu-latest` - Gibt die Laufzeitumgebung an
- Verwendet die neueste Ubuntu-Version
- GitHub-gehostete Runner

**Zeile 20**: `steps:` - Definiert die Schritte des Jobs

**Zeile 21-24**: Aktion "lock-threads"
```yaml
- uses: dessant/lock-threads@v5
  with:
    issue-inactive-days: '7'
    pr-inactive-days: '7'
```

**Zeile 21**: `- uses: dessant/lock-threads@v5`
- Verwendet die GitHub Action "lock-threads" von Benutzer "dessant"
- Version: `v5` (Major Version 5)
- Diese Action ist ein Community-Projekt, das automatisch inaktive Threads sperrt

**Zeile 22-24**: Konfigurationsparameter
- **`issue-inactive-days: '7'`** - Sperrt Issues, die 7 Tage lang inaktiv waren
- **`pr-inactive-days: '7'`** - Sperrt Pull Requests, die 7 Tage lang inaktiv waren

## Workflow-Funktionalität

### Zusammenfassung
Dieser Workflow automatisiert die Verwaltung von GitHub Discussions und Pull Requests:

1. **Zeitgesteuerte Ausführung**: Läuft jede Stunde automatisch
2. **Inaktivitätserkennung**: Erkennt Issues und PRs, die länger als 7 Tage inaktiv sind
3. **Automatisches Sperren**: Sperrt diese automatisch, um alte Diskussionen zu archivieren
4. **Manuelle Auslösung**: Kann jederzeit manuell über GitHub UI ausgelöst werden

### Zweck im Repository
Im Kontext des Awesome-Hacking Repositories dient dieser Workflow dazu:
- **Diskussionen organisieren**: Verhindert, dass alte, abgelöste Diskussionen weiterhin Aufmerksamkeit erhalten
- **Wartung automatisieren**: Reduziert manuelle Moderationsarbeit
- **Fokus bewahren**: Hält aktive Diskussionen im Vordergrund

## Technische Details

### GitHub Actions Konzepte

| Konzept | Bedeutung |
|---------|-----------|
| `on` | Trigger/Auslöser für den Workflow |
| `schedule` | Zeitgesteuerte Ausführung (Cron-basiert) |
| `workflow_dispatch` | Manuelle Auslösung |
| `permissions` | Berechtigungen für die Workflow-Ausführung |
| `concurrency` | Kontrolle paralleler Ausführungen |
| `jobs` | Haupteinheiten der Arbeit |
| `runs-on` | Laufzeitumgebung |
| `steps` | Einzelne Aktionen innerhalb eines Jobs |
| `uses` | Referenziert eine externe Action |
| `with` | Parameter für die Action |

### Cron-Expression Erklärung
```
0 * * * *
│ │ │ │ │
│ │ │ │ └─── Wochentag (0-6, 0=Sonntag)
│ │ │ └───── Monat (1-12)
│ │ └─────── Tag des Monats (1-31)
│ └───────── Stunde (0-23)
└─────────── Minute (0-59)
```

**Bedeutung**: `0 * * * *` = Jede Stunde zur Minute 0

## Abhängigkeiten

### Externe Abhängigkeiten
- **dessant/lock-threads@v5**: GitHub Action von dessant
  - Repository: https://github.com/dessant/lock-threads
  - Lizenz: ISC
  - Funktion: Automatisches Sperren inaktiver Threads

### Berechtigungen
Der Workflow benötigt folgende Berechtigungen:
- `issues:write` - Zum Sperren/Entsperren von Issues
- `pull-requests:write` - Zum Sperren/Entsperren von PRs
- `discussions:write` - Zum Sperren/Entsperren von Diskussionen

## Best Practices in diesem Workflow

1. **Explizite Berechtigungen**: Definiert nur notwendige Berechtigungen (Principle of Least Privilege)
2. **Concurrency-Kontrolle**: Verhindert Race Conditions durch Concurrency-Grouping
3. **Versionierung**: Nutzt spezifische Action-Version (`v5`) statt `latest`
4. **Konfigurierbare Parameter**: 7-Tage-Inaktivität ist ein sinnvoller Standard
5. **Redundante Auslöser**: Kombiniert automatische Planung mit manueller Auslösung

## Sicherheitsaspekte

1. **Minimale Berechtigungen**: Nur die notwendigen Berechtigungen werden erteilt
2. **Vertrauenswürdige Action**: dessant/lock-threads ist ein etabliertes Community-Projekt
3. **Keine Secrets**: Keine sensiblen Daten in der Konfiguration
4. **Transparenz**: Workflow ist öffentlich einsehbar

## Zusammenfassung

Die `lock-threads.yml` ist ein einfacher, aber effektiver Workflow, der:
- Automatisch alle Stunde ausgeführt wird
- Inaktive Issues und PRs nach 7 Tagen sperrt
- Die Repository-Verwaltung automatisiert
- Best Practices für GitHub Actions befolgt
