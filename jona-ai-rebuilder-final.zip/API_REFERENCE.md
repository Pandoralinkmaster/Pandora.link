# JonaAI Link-Code Rebuilder - API Referenz

## tRPC Procedures

### Analysis Router

#### `analysis.listLinks`
Rufe alle Links mit Filterung, Suche und Pagination ab.

**Input:**
```typescript
{
  skip: number;        // Offset
  take: number;        // Limit
  search?: string;     // URL-Suche
  kind?: string;       // Link-Typ Filter
}
```

**Output:**
```typescript
Array<{
  id: number;
  url: string;
  host: string;
  path: string;
  kind: string;
  sha256: string;
  occurrences: number;
}>
```

#### `analysis.getLink`
Rufe Link-Details mit Analyse-Status und Signaturen ab.

**Input:**
```typescript
{ linkId: number }
```

**Output:**
```typescript
{
  link: Link;
  analysis?: Analysis;
  signatures: Signature[];
}
```

#### `analysis.analyzeLink`
Starte Analyse für einen Link.

**Input:**
```typescript
{ linkId: number }
```

**Output:**
```typescript
{
  analysisId: number;
  status: "ausstehend" | "läuft" | "fertig" | "Fehler";
}
```

#### `analysis.getStats`
Rufe Statistik-Kacheln ab.

**Output:**
```typescript
{
  totalLinks: number;
  completedAnalyses: number;
  generatedModules: number;
  successRate: number;
}
```

#### `analysis.getAuditLines`
Rufe Quellzeilen mit Pagination ab.

**Input:**
```typescript
{
  skip: number;
  take: number;
}
```

**Output:**
```typescript
Array<{
  id: number;
  text: string;
  sha256: string;
  urlCount: number;
}>
```

#### `analysis.getLinkManifest`
Rufe Link-Manifest mit vollständigen Metadaten ab.

**Output:**
```typescript
Array<{
  id: number;
  url: string;
  host: string;
  path: string;
  kind: string;
  sha256: string;
  occurrences: number;
}>
```

### Reports Router

#### `reports.listReports`
Rufe alle Berichte mit Filterung ab.

**Input:**
```typescript
{
  skip: number;
  take: number;
  status?: string;
}
```

#### `reports.getReport`
Rufe detaillierten Bericht ab.

**Input:**
```typescript
{ analysisId: number }
```

#### `reports.getAnalyticsSummary`
Rufe Analytics-Zusammenfassung ab.

**Output:**
```typescript
{
  summary: {
    totalLinks: number;
    totalAnalyses: number;
    completedAnalyses: number;
    totalSignatures: number;
    averageSignaturesPerAnalysis: number;
    completionRate: number;
  };
  byStatus: Record<string, number>;
  byLinkType: Record<string, number>;
  bySignatureType: Record<string, number>;
}
```

#### `reports.exportReport`
Exportiere Bericht als JSON.

**Input:**
```typescript
{ analysisId: number }
```

#### `reports.getTopSignatures`
Rufe häufigste Signaturen ab.

**Input:**
```typescript
{ limit?: number }
```

#### `reports.getAnalysisTimeline`
Rufe Analyse-Timeline ab.

## Datenbank-Schema

### links
```typescript
{
  id: number;
  url: string;
  host: string;
  path: string;
  kind: string;
  sha256: string;
  occurrences: number;
}
```

### analyses
```typescript
{
  id: number;
  linkId: number;
  status: "ausstehend" | "läuft" | "fertig" | "Fehler";
  analysisType?: string;
  totalFiles?: number;
  selectedCodeFiles?: number;
  analyzedFiles?: number;
  signatureCount?: number;
  importCount?: number;
  riskTermsFound?: string; // JSON
  aiSummary?: string;
  generatedModulePath?: string;
  reportPath?: string;
  startedAt?: Date;
  completedAt?: Date;
}
```

### signatures
```typescript
{
  id: number;
  analysisId: number;
  linkId: number;
  filePath: string;
  signatureType: string; // "function", "class", "import"
  name: string;
  params?: string;
}
```

### auditLines
```typescript
{
  id: number;
  text: string;
  sha256: string;
  urlCount: number;
}
```

### generatedModules
```typescript
{
  id: number;
  analysisId: number;
  linkId: number;
  moduleHash: string;
  modulePath: string;
  functionCount?: number;
  classCount?: number;
  content?: string;
  createdAt: Date;
}
```

## Frontend Hooks

### useAuth()
```typescript
const { user, loading, error, isAuthenticated, logout } = useAuth();
```

### trpc Hooks
```typescript
// Query
const { data, isLoading, error } = trpc.analysis.listLinks.useQuery({ skip: 0, take: 50 });

// Mutation
const { mutateAsync, isPending } = trpc.analysis.analyzeLink.useMutation();
await mutateAsync({ linkId: 1 });
```

## Fehlerbehandlung

Alle tRPC Procedures werfen `TRPCError` mit folgenden Codes:

- `INTERNAL_SERVER_ERROR` - Datenbank nicht verfügbar
- `NOT_FOUND` - Ressource nicht gefunden
- `BAD_REQUEST` - Ungültige Eingabe
- `UNAUTHORIZED` - Authentifizierung erforderlich
- `FORBIDDEN` - Berechtigung erforderlich

## Rate Limiting

GitHub API:
- 60 Anfragen/Stunde (unauthentifiziert)
- 5000 Anfragen/Stunde (authentifiziert mit Token)

LLM API:
- Abhängig von Manus Kontingent

## Best Practices

1. **Pagination**: Verwende `skip` und `take` für große Datenmengen
2. **Fehlerbehandlung**: Implementiere `onError` Handler in Mutations
3. **Caching**: tRPC cached Queries automatisch
4. **Invalidation**: Nutze `trpc.useUtils().*.invalidate()` nach Mutations
5. **Optimistic Updates**: Verwende `onMutate` für sofortiges UI-Feedback

## Beispiele

### Link-Analyse starten
```typescript
const { mutateAsync } = trpc.analysis.analyzeLink.useMutation({
  onSuccess: () => {
    toast.success("Analyse gestartet");
    trpc.useUtils().analysis.getStats.invalidate();
  },
  onError: (error) => {
    toast.error(`Fehler: ${error.message}`);
  },
});

await mutateAsync({ linkId: 1 });
```

### Bericht exportieren
```typescript
const report = await trpc.reports.exportReport.query({ analysisId: 1 });
const blob = new Blob([JSON.stringify(report, null, 2)], { type: "application/json" });
const url = URL.createObjectURL(blob);
const a = document.createElement("a");
a.href = url;
a.download = "report.json";
a.click();
```

### Analytics abrufen
```typescript
const { data: analytics } = trpc.reports.getAnalyticsSummary.useQuery();

console.log(`Abschlussquote: ${analytics.summary.completionRate}%`);
console.log(`Durchschnitt Signaturen: ${analytics.summary.averageSignaturesPerAnalysis}`);
```
