import { Toaster } from "@/components/ui/sonner";
import { TooltipProvider } from "@/components/ui/tooltip";
import NotFound from "@/pages/NotFound";
import { Route, Switch } from "wouter";
import ErrorBoundary from "./components/ErrorBoundary";
import { ThemeProvider } from "./contexts/ThemeContext";
import Home from "./pages/Home";
import Dashboard from "./pages/Dashboard";
import LinkDetail from "./pages/LinkDetail";
import Manifest from "./pages/Manifest";
import Modules from "./pages/Modules";
import BatchAnalysis from "./pages/BatchAnalysis";
import Reports from "./pages/Reports";
import SignatureViewer from "./pages/SignatureViewer";
import Analytics from "./pages/Analytics";
import CompareAnalyses from "./pages/CompareAnalyses";
import Settings from "./pages/Settings";
import LinkDetailsExtended from "./pages/LinkDetailsExtended";
import LinkCatalog from "./pages/LinkCatalog";
import CodeViewerComplete from "./pages/CodeViewerComplete";
import ModuleGenerator from "./pages/ModuleGenerator";
import DataExport from "./pages/DataExport";
import LinkComparison from "./pages/LinkComparison";
import Verification from "./pages/Verification";

function Router() {
  // make sure to consider if you need authentication for certain routes
  return (
    <Switch>
      <Route path={"/{"} component={Home} />
      <Route path={"/dashboard"} component={Dashboard} />
      <Route path={"/link/:linkId"} component={LinkDetail} />
      <Route path={"/manifest"} component={Manifest} />
      <Route path={"/modules"} component={Modules} />
      <Route path={"/batch"} component={BatchAnalysis} />
      <Route path={"/reports"} component={Reports} />
      <Route path={"/signatures/:linkId"} component={SignatureViewer} />
      <Route path={"/analytics"} component={Analytics} />
      <Route path={"/compare"} component={CompareAnalyses} />
      <Route path={"/settings"} component={Settings} />
      <Route path={"/link-extended/:linkId"} component={LinkDetailsExtended} />
      <Route path={"/catalog"} component={LinkCatalog} />
      <Route path={"/code"} component={CodeViewerComplete} />
      <Route path={"/generator"} component={ModuleGenerator} />
      <Route path={"/export"} component={DataExport} />
      <Route path={"/comparison"} component={LinkComparison} />
      <Route path={"/verification"} component={Verification} />
      <Route path={"/404"} component={NotFound} />
      {/* Final fallback route */}
      <Route component={NotFound} />
    </Switch>
  );
}

// NOTE: About Theme
// - First choose a default theme according to your design style (dark or light bg), than change color palette in index.css
//   to keep consistent foreground/background color across components
// - If you want to make theme switchable, pass `switchable` ThemeProvider and use `useTheme` hook

function App() {
  return (
    <ErrorBoundary>
      <ThemeProvider
        defaultTheme="light"
        // switchable
      >
        <TooltipProvider>
          <Toaster />
          <Router />
        </TooltipProvider>
      </ThemeProvider>
    </ErrorBoundary>
  );
}

export default App;
