import { useState, useEffect } from "react";
import { trpc } from "@/lib/trpc";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { ChevronLeft } from "lucide-react";
import { useLocation } from "wouter";

export default function Analytics() {
  const [, setLocation] = useLocation();
  const { data: stats } = trpc.analysis.getStats.useQuery();
  const { data: links } = trpc.analysis.listLinks.useQuery({ skip: 0, take: 1000 });
  const { data: auditLines } = trpc.analysis.getAuditLines.useQuery({ skip: 0, take: 1000 });

  const [analytics, setAnalytics] = useState({
    totalLinks: 0,
    completedAnalyses: 0,
    pendingAnalyses: 0,
    failedAnalyses: 0,
    averageSignaturesPerLink: 0,
    mostCommonLinkType: "",
    totalAuditLines: 0,
  });

  useEffect(() => {
    if (links && stats) {
      const completed = stats.completedAnalyses || 0;
      const total = stats.totalLinks || 0;
      const pending = total - completed;

      setAnalytics({
        totalLinks: total,
        completedAnalyses: completed,
        pendingAnalyses: pending,
        failedAnalyses: 0,
        averageSignaturesPerLink: completed > 0 ? Math.round((stats.successRate || 0) / completed) : 0,
        mostCommonLinkType: links[0]?.kind || "N/A",
        totalAuditLines: auditLines?.length || 0,
      });
    }
  }, [links, stats, auditLines]);

  const linkTypeDistribution = links?.reduce((acc: Record<string, number>, link: any) => {
    acc[link.kind] = (acc[link.kind] || 0) + 1;
    return acc;
  }, {}) || {};

  const completionPercentage = analytics.totalLinks > 0 
    ? Math.round((analytics.completedAnalyses / analytics.totalLinks) * 100)
    : 0;

  return (
    <div className="min-h-screen bg-[#10141d] text-[#eef]">
      {/* Header */}
      <div className="border-b border-[#334] bg-[#0f0f15] p-6">
        <div className="flex items-center gap-4 mb-4">
          <Button
            variant="ghost"
            onClick={() => setLocation("/dashboard")}
            className="text-[#9df] hover:bg-[#1b2332]"
          >
            <ChevronLeft className="w-4 h-4" />
          </Button>
          <h1 className="text-2xl font-bold">Analytics & Statistiken</h1>
        </div>
        <p className="text-[#9df] text-sm">Detaillierte Übersicht aller Analyse-Metriken</p>
      </div>

      {/* Content */}
      <div className="p-6 space-y-6">
        {/* Key Metrics */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
          <Card className="bg-[#1b2332] border-[#334] p-6">
            <div className="text-[#9df] text-sm font-medium">Gesamt Links</div>
            <div className="text-3xl font-bold mt-2">{analytics.totalLinks}</div>
            <div className="text-[#666] text-xs mt-2">100% Inventar</div>
          </Card>

          <Card className="bg-[#1b2332] border-[#334] p-6">
            <div className="text-[#9df] text-sm font-medium">Abgeschlossen</div>
            <div className="text-3xl font-bold mt-2 text-[#00ff00]">{analytics.completedAnalyses}</div>
            <div className="text-[#666] text-xs mt-2">{completionPercentage}% fertig</div>
          </Card>

          <Card className="bg-[#1b2332] border-[#334] p-6">
            <div className="text-[#9df] text-sm font-medium">Ausstehend</div>
            <div className="text-3xl font-bold mt-2 text-[#ff9500]">{analytics.pendingAnalyses}</div>
            <div className="text-[#666] text-xs mt-2">{100 - completionPercentage}% offen</div>
          </Card>

          <Card className="bg-[#1b2332] border-[#334] p-6">
            <div className="text-[#9df] text-sm font-medium">Module</div>
            <div className="text-3xl font-bold mt-2">{stats?.generatedModules || 0}</div>
            <div className="text-[#666] text-xs mt-2">Generiert</div>
          </Card>
        </div>

        {/* Progress Bar */}
        <Card className="bg-[#1b2332] border-[#334] p-6">
          <h3 className="text-lg font-semibold mb-4">Analyse-Fortschritt</h3>
          <div className="space-y-3">
            <div>
              <div className="flex justify-between text-sm mb-2">
                <span className="text-[#9df]">Gesamtfortschritt</span>
                <span className="text-[#eef] font-semibold">{completionPercentage}%</span>
              </div>
              <div className="w-full bg-[#0f0f15] rounded-full h-3 overflow-hidden">
                <div
                  className="bg-[#00ff00] h-full transition-all duration-500"
                  style={{ width: `${completionPercentage}%` }}
                />
              </div>
            </div>

            <div className="grid grid-cols-3 gap-4 text-sm mt-4">
              <div className="bg-[#0f0f15] p-3 rounded">
                <div className="text-[#9df] text-xs">Fertig</div>
                <div className="text-lg font-bold text-[#00ff00]">{analytics.completedAnalyses}</div>
              </div>
              <div className="bg-[#0f0f15] p-3 rounded">
                <div className="text-[#9df] text-xs">Ausstehend</div>
                <div className="text-lg font-bold text-[#ff9500]">{analytics.pendingAnalyses}</div>
              </div>
              <div className="bg-[#0f0f15] p-3 rounded">
                <div className="text-[#9df] text-xs">Fehler</div>
                <div className="text-lg font-bold text-[#ff0000]">{analytics.failedAnalyses}</div>
              </div>
            </div>
          </div>
        </Card>

        {/* Link Type Distribution */}
        <Card className="bg-[#1b2332] border-[#334] p-6">
          <h3 className="text-lg font-semibold mb-4">Link-Typ Verteilung</h3>
          <div className="space-y-3">
            {Object.entries(linkTypeDistribution).map(([type, count]) => (
              <div key={type}>
                <div className="flex justify-between text-sm mb-1">
                  <span className="text-[#9df]">{type}</span>
                  <span className="text-[#eef]">{count}</span>
                </div>
                <div className="w-full bg-[#0f0f15] rounded-full h-2 overflow-hidden">
                  <div
                    className="bg-[#9df] h-full"
                    style={{ width: `${(count as number / analytics.totalLinks) * 100}%` }}
                  />
                </div>
              </div>
            ))}
          </div>
        </Card>

        {/* Detailed Statistics */}
        <div className="grid grid-cols-2 gap-4">
          <Card className="bg-[#1b2332] border-[#334] p-6">
            <h3 className="text-lg font-semibold mb-4">Quellzeilen</h3>
            <div className="text-3xl font-bold text-[#9df]">{analytics.totalAuditLines}</div>
            <p className="text-[#666] text-sm mt-2">Eindeutige Quellzeilen mit SHA256</p>
          </Card>

          <Card className="bg-[#1b2332] border-[#334] p-6">
            <h3 className="text-lg font-semibold mb-4">Erfolgsquote</h3>
            <div className="text-3xl font-bold text-[#00ff00]">{stats?.successRate || 0}%</div>
            <p className="text-[#666] text-sm mt-2">Abgeschlossene Analysen</p>
          </Card>
        </div>

        {/* Export Section */}
        <Card className="bg-[#1b2332] border-[#334] p-6">
          <h3 className="text-lg font-semibold mb-4">Daten-Export</h3>
          <p className="text-[#9df] text-sm mb-4">
            Exportiere alle Analyse-Daten als JSON für externe Verarbeitung
          </p>
          <Button
            onClick={() => {
              const exportData = {
                exportDate: new Date().toISOString(),
                analytics,
                linkTypeDistribution,
                stats,
              };
              const blob = new Blob([JSON.stringify(exportData, null, 2)], { type: "application/json" });
              const url = URL.createObjectURL(blob);
              const a = document.createElement("a");
              a.href = url;
              a.download = `analytics_${Date.now()}.json`;
              document.body.appendChild(a);
              a.click();
              document.body.removeChild(a);
              URL.revokeObjectURL(url);
            }}
            className="bg-[#00ff00] text-[#000] hover:bg-[#00cc00]"
          >
            Analytics als JSON exportieren
          </Button>
        </Card>
      </div>
    </div>
  );
}
