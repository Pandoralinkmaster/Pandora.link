import { useState, useEffect } from "react";
import { trpc } from "@/lib/trpc";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Progress } from "@/components/ui/progress";
import { Loader2, ChevronLeft } from "lucide-react";
import { useLocation } from "wouter";

export default function BatchAnalysis() {
  const [, setLocation] = useLocation();
  const [analyzing, setAnalyzing] = useState(false);
  const [progress, setProgress] = useState(0);
  const [currentLink, setCurrentLink] = useState<number | null>(null);
  const [showConfirm, setShowConfirm] = useState(false);

  const { data: stats, refetch: refetchStats } = trpc.analysis.getStats.useQuery();
  const { data: links } = trpc.analysis.listLinks.useQuery({ skip: 0, take: 1000 });
  const analyzeMutation = trpc.analysis.analyzeLink.useMutation();

  const handleBatchAnalyze = async () => {
    if (!links || links.length === 0) return;
    setShowConfirm(false);
    setAnalyzing(true);
    setProgress(0);

    for (let i = 0; i < links.length; i++) {
      try {
        setCurrentLink(links[i].id);
        await analyzeMutation.mutateAsync({ linkId: links[i].id });
        setProgress(Math.round(((i + 1) / links.length) * 100));
        await refetchStats();
      } catch (error) {
        console.error(`Failed to analyze link ${links[i].id}:`, error);
      }
    }

    setAnalyzing(false);
    setCurrentLink(null);
  };

  return (
    <div className="min-h-screen bg-[#10141d] text-[#eef]">
      {/* Header */}
      <div className="border-b border-[#334] bg-[#0f0f15] p-6">
        <div className="flex items-center gap-4 mb-4">
          <Button
            variant="ghost"
            onClick={() => setLocation("/dashboard")}
            className="text-[#9df] hover:bg-[#1b2332]"
          >
            <ChevronLeft className="w-4 h-4" />
          </Button>
          <h1 className="text-2xl font-bold">Batch-Analyse</h1>
        </div>
        <p className="text-[#9df] text-sm">Analysiere alle 118 Links automatisch</p>
      </div>

      {/* Content */}
      <div className="p-6 max-w-2xl mx-auto">
        <Card className="bg-[#1b2332] border-[#334] p-8 space-y-6">
          {/* Statistics */}
          <div className="grid grid-cols-2 gap-4">
            <div className="bg-[#0f0f15] p-4 rounded">
              <div className="text-[#9df] text-sm">Gesamt</div>
              <div className="text-2xl font-bold mt-2">{stats?.totalLinks || 0}</div>
            </div>
            <div className="bg-[#0f0f15] p-4 rounded">
              <div className="text-[#9df] text-sm">Abgeschlossen</div>
              <div className="text-2xl font-bold mt-2">{stats?.completedAnalyses || 0}</div>
            </div>
          </div>

          {/* Progress */}
          {analyzing && (
            <div className="space-y-4">
              <div className="text-sm text-[#9df]">
                Analysiere Link #{currentLink}... ({progress}%)
              </div>
              <Progress value={progress} className="h-2" />
            </div>
          )}

          {/* Button */}
          {showConfirm ? (
            <div className="space-y-3">
              <p className="text-[#9df] text-sm">Wirklich alle 118 Links analysieren? Dies kann mehrere Minuten dauern.</p>
              <div className="flex gap-3">
                <Button
                  onClick={handleBatchAnalyze}
                  className="flex-1 bg-[#00ff00] text-[#000] hover:bg-[#00cc00]"
                >
                  Ja, analysieren
                </Button>
                <Button
                  onClick={() => setShowConfirm(false)}
                  variant="outline"
                  className="flex-1 border-[#334] text-[#9df]"
                >
                  Abbrechen
                </Button>
              </div>
            </div>
          ) : (
            <Button
              onClick={() => setShowConfirm(true)}
              disabled={analyzing}
              className="w-full bg-[#00ff00] text-[#000] hover:bg-[#00cc00] py-6 text-lg"
            >
              {analyzing ? (
                <>
                  <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                  Analysiere... ({progress}%)
                </>
              ) : (
                "Alle 118 Links analysieren"
              )}
            </Button>
          )}

          {analyzing && (
            <p className="text-[#9df] text-sm text-center">
              Dies kann mehrere Minuten dauern. Bitte nicht schließen.
            </p>
          )}
          {!analyzing && progress > 0 && (
            <div className="bg-[#0f0f15] p-4 rounded text-center">
              <p className="text-[#00ff00] font-semibold">✓ Analyse abgeschlossen!</p>
              <p className="text-[#9df] text-sm mt-2">{stats?.completedAnalyses} von {stats?.totalLinks} Links analysiert</p>
            </div>
          )}
        </Card>
      </div>
    </div>
  );
}
