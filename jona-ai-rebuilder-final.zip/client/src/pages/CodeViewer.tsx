import { useState } from "react";
import { trpc } from "@/lib/trpc";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { ChevronLeft, Copy, Download, Search } from "lucide-react";
import { useLocation } from "wouter";

const SAMPLE_CODE_FILES = [
  {
    id: 1,
    name: "main.py",
    language: "python",
    content: `from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel
from pathlib import Path
import json, re, hashlib, subprocess, tempfile, os, shutil
from urllib.parse import urlparse
import requests
from bs4 import BeautifulSoup

ROOT = Path(__file__).resolve().parents[1]
DATA = ROOT / 'data'
REPORTS = ROOT / 'reports'
GENERATED = ROOT / 'generated_modules'
REPORTS.mkdir(exist_ok=True)
GENERATED.mkdir(exist_ok=True)
app = FastAPI(title='Link Code Function Rebuilder', version='1.0')
app.add_middleware(CORSMiddleware, allow_origins=['*'], allow_credentials=True, allow_methods=['*'], allow_headers=['*'])

SAFE_EXTENSIONS = {'.py','.js','.ts','.tsx','.jsx','.java','.kt','.kts','.go','.rs','.c','.h','.cpp','.hpp','.cs','.php','.rb','.sh','.yml','.yaml','.json','.xml','.html','.css','.md','.gradle','.toml','.ini','.cfg','.properties'}
MAX_FILE_BYTES = 300_000
MAX_REPO_FILES = 400

SIG_PATTERNS = [
    ('python_function', re.compile(r'^\s*def\s+([A-Za-z_][\w]*)\s*\(([^)]*)\)\s*:', re.M)),
    ('python_class', re.compile(r'^\s*class\s+([A-Za-z_][\w]*)\s*(?:\(([^)]*)\))?\s*:', re.M)),
    ('js_function', re.compile(r'\bfunction\s+([A-Za-z_$][\w$]*)\s*\(([^)]*)\)', re.M)),
]

RISK_WORDS = re.compile(r'(exploit|payload|shellcode|meterpreter|ransom|keylogger|credential|steal|ddos|botnet|reverse shell|malware)', re.I)

def load_links():
    return json.loads((DATA/'links.json').read_text())

def classify_file(path):
    p=Path(path)
    if p.suffix.lower() in SAFE_EXTENSIONS or p.name in {'Dockerfile','Makefile','gradlew'}:
        return 'code_or_config'
    return 'other'

def extract_signatures(content):
    out=[]
    for typ,pat in SIG_PATTERNS:
        for m in pat.finditer(content):
            out.append({'type':typ,'name':m.group(1),'params':m.group(2) if m.lastindex and m.lastindex>=2 else '', 'start':m.start()})
    return out`,
  },
  {
    id: 2,
    name: "App.jsx",
    language: "javascript",
    content: `import React,{useEffect,useState}from'react';import{createRoot}from'react-dom/client';import'./style.css';
const API='http://localhost:8000';
function App(){const[links,setLinks]=useState([]);const[status,setStatus]=useState({});const[log,setLog]=useState('');useEffect(()=>{fetch(API+'/api/links').then(r=>r.json()).then(setLinks);refresh()},[]);function refresh(){fetch(API+'/api/status').then(r=>r.json()).then(setStatus)}async function one(id){setLog('Analysiere Link '+id+' ...');let r=await fetch(API+'/api/analyze/'+id,{method:'POST'});let j=await r.json();setLog(JSON.stringify(j,null,2));refresh()}async function all(){setLog('Starte Analyse aller Links. Das kann lokal lange dauern.');let r=await fetch(API+'/api/analyze_all',{method:'POST'});let j=await r.json();setLog(JSON.stringify(j,null,2));refresh()}return <main><h1>Code Function Rebuilder Web-App</h1><p>Quelle enthält {links.length} eindeutige Links. Die App analysiert jeden Link, erkennt Code-Dateien und erzeugt eigene sichere Module aus Signaturen/Funktionsmustern.</p><section className="cards"><div>Links: {status.links||0}</div><div>Berichte: {status.reports_done||0}</div><div>Module: {status.generated_modules||0}</div></section><button onClick={all}>Alle Links analysieren</button><div className="grid">{links.map(l=><article key={l.id}><b>#{l.id}</b><span>{l.kind}</span><code>{l.url}</code><button onClick={()=>one(l.id)}>Analysieren</button></article>)}</div><pre>{log}</pre></main>}
createRoot(document.getElementById('root')).render(<App/>);`,
  },
  {
    id: 3,
    name: "verify_integrity.py",
    language: "python",
    content: `import json,hashlib,sys
from pathlib import Path
root=Path(__file__).parent
source=(root/'source'/'Notes_260615_102612.txt').read_text(errors='replace')
links=json.loads((root/'data'/'links.json').read_text())
line_audit=json.loads((root/'data'/'line_audit.json').read_text())
errors=[]
if len(line_audit)!=len(source.splitlines()): errors.append('line count mismatch')
for item in line_audit:
    if hashlib.sha256(item['text'].encode()).hexdigest()!=item['sha256']: errors.append(f"line hash mismatch {item['line']}")
if not links: errors.append('no links')
print('OK' if not errors else 'FAIL')
print('links',len(links),'lines',len(line_audit),'errors',len(errors))
if errors: print('\\n'.join(errors)); sys.exit(1)`,
  },
];

export default function CodeViewer() {
  const [, setLocation] = useLocation();
  const [selectedFile, setSelectedFile] = useState(SAMPLE_CODE_FILES[0]);
  const [search, setSearch] = useState("");
  const [copied, setCopied] = useState(false);

  const { data: summary } = trpc.code.summarizeCode.useQuery({ content: selectedFile.content });

  const handleCopy = () => {
    navigator.clipboard.writeText(selectedFile.content);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const handleDownload = () => {
    const blob = new Blob([selectedFile.content], { type: "text/plain" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = selectedFile.name;
    a.click();
  };

  const highlightCode = (code: string) => {
    let highlighted = code;
    
    // Python Keywords
    highlighted = highlighted.replace(/\b(def|class|import|from|return|if|else|for|while|try|except|with|as|pass|break|continue|yield)\b/g, '<span class="keyword">$1</span>');
    
    // Strings
    highlighted = highlighted.replace(/(['"])(?:(?=(\\?))\2.)*?\1/g, '<span class="string">$&</span>');
    
    // Comments
    highlighted = highlighted.replace(/#.*/g, '<span class="comment">$&</span>');
    
    // Numbers
    highlighted = highlighted.replace(/\b\d+\b/g, '<span class="number">$&</span>');
    
    return highlighted;
  };

  const filteredLines = selectedFile.content
    .split("\n")
    .map((line, idx) => ({ idx: idx + 1, line }))
    .filter(({ line }) => !search || line.toLowerCase().includes(search.toLowerCase()));

  return (
    <div className="min-h-screen bg-[#10141d] text-[#eef]">
      {/* Header */}
      <div className="border-b border-[#334] bg-[#0f0f15] p-6">
        <div className="flex items-center gap-4 mb-4">
          <Button
            variant="ghost"
            onClick={() => setLocation("/dashboard")}
            className="text-[#9df] hover:bg-[#1b2332]"
          >
            <ChevronLeft className="w-4 h-4" />
          </Button>
          <h1 className="text-2xl font-bold">Code-Viewer</h1>
        </div>
        <p className="text-[#9df] text-sm">Alle Original-Code-Dateien mit Syntax-Highlighting</p>
      </div>

      {/* Content */}
      <div className="p-6 grid grid-cols-4 gap-6">
        {/* File List */}
        <div className="col-span-1">
          <Card className="bg-[#1b2332] border-[#334] p-4">
            <h3 className="text-sm font-semibold mb-3 text-[#9df]">Dateien</h3>
            <div className="space-y-2">
              {SAMPLE_CODE_FILES.map((file) => (
                <Button
                  key={file.id}
                  variant={selectedFile.id === file.id ? "default" : "outline"}
                  onClick={() => setSelectedFile(file)}
                  className={`w-full justify-start text-xs ${
                    selectedFile.id === file.id
                      ? "bg-[#9df] text-[#000]"
                      : "bg-[#0f0f15] border-[#334] text-[#9df]"
                  }`}
                >
                  {file.name}
                </Button>
              ))}
            </div>
          </Card>
        </div>

        {/* Code Editor */}
        <div className="col-span-3 space-y-4">
          {/* Toolbar */}
          <div className="flex gap-2 items-center">
            <Input
              placeholder="Code durchsuchen..."
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              className="bg-[#1b2332] border-[#334] text-[#eef] flex-1"
            />
            <Button
              onClick={handleCopy}
              className="bg-[#9df] text-[#000] hover:bg-[#7bc]"
              size="sm"
            >
              <Copy className="w-4 h-4" />
            </Button>
            <Button
              onClick={handleDownload}
              className="bg-[#1b2332] border border-[#334] text-[#9df]"
              size="sm"
            >
              <Download className="w-4 h-4" />
            </Button>
          </div>

          {/* Code Display */}
          <Card className="bg-[#0f0f15] border-[#334] p-4 font-mono text-xs overflow-auto max-h-[600px]">
            <div className="space-y-0">
              {filteredLines.map(({ idx, line }) => (
                <div key={idx} className="flex">
                  <div className="text-[#666] w-12 text-right pr-4 select-none">{idx}</div>
                  <div className="text-[#9df] flex-1 whitespace-pre-wrap break-words">{line}</div>
                </div>
              ))}
            </div>
          </Card>

          {/* Summary */}
          {summary && (
            <Card className="bg-[#1b2332] border-[#334] p-4">
              <h3 className="text-sm font-semibold mb-3 text-[#9df]">Zusammenfassung</h3>
              <div className="grid grid-cols-4 gap-2 text-xs">
                <div className="bg-[#0f0f15] p-2 rounded">
                  <div className="text-[#666]">Zeilen</div>
                  <div className="text-[#9df] font-bold">{summary.lines}</div>
                </div>
                <div className="bg-[#0f0f15] p-2 rounded">
                  <div className="text-[#666]">Bytes</div>
                  <div className="text-[#9df] font-bold">{summary.bytes}</div>
                </div>
                <div className="bg-[#0f0f15] p-2 rounded">
                  <div className="text-[#666]">Signaturen</div>
                  <div className="text-[#9df] font-bold">{summary.signatures.length}</div>
                </div>
                <div className="bg-[#0f0f15] p-2 rounded">
                  <div className="text-[#666]">Imports</div>
                  <div className="text-[#9df] font-bold">{summary.imports.length}</div>
                </div>
              </div>
              {summary.riskTerms.length > 0 && (
                <div className="mt-3 p-2 bg-[#2d1515] rounded border border-[#8b3333]">
                  <div className="text-[#ff6b6b] text-xs font-semibold mb-1">⚠️ Risk-Terms:</div>
                  <div className="text-[#ff9999] text-xs">{summary.riskTerms.join(", ")}</div>
                </div>
              )}
            </Card>
          )}
        </div>
      </div>

      {copied && (
        <div className="fixed bottom-6 right-6 bg-[#00ff00] text-[#000] px-4 py-2 rounded font-semibold">
          ✓ Kopiert!
        </div>
      )}
    </div>
  );
}
