import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { ChevronLeft, Copy, Download, Search } from "lucide-react";
import { useLocation } from "wouter";

// Alle Original-Code-Dateien aus der ZIP
const ALL_CODE_FILES = [
  {
    id: 1,
    name: "main.py",
    language: "python",
    path: "backend/main.py",
    description: "FastAPI Backend mit Link-Analyse, GitHub-Crawling, Signatur-Extraktion",
    content: `from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel
from pathlib import Path
import json, re, hashlib, subprocess, tempfile, os, shutil
from urllib.parse import urlparse
import requests
from bs4 import BeautifulSoup

ROOT = Path(__file__).resolve().parents[1]
DATA = ROOT / 'data'
REPORTS = ROOT / 'reports'
GENERATED = ROOT / 'generated_modules'
REPORTS.mkdir(exist_ok=True)
GENERATED.mkdir(exist_ok=True)
app = FastAPI(title='Link Code Function Rebuilder', version='1.0')
app.add_middleware(CORSMiddleware, allow_origins=['*'], allow_credentials=True, allow_methods=['*'], allow_headers=['*'])

SAFE_EXTENSIONS = {'.py','.js','.ts','.tsx','.jsx','.java','.kt','.kts','.go','.rs','.c','.h','.cpp','.hpp','.cs','.php','.rb','.sh','.yml','.yaml','.json','.xml','.html','.css','.md','.gradle','.toml','.ini','.cfg','.properties'}
MAX_FILE_BYTES = 300_000
MAX_REPO_FILES = 400

SIG_PATTERNS = [
    ('python_function', re.compile(r'^\s*def\s+([A-Za-z_][\w]*)\s*\(([^)]*)\)\s*:', re.M)),
    ('python_class', re.compile(r'^\s*class\s+([A-Za-z_][\w]*)\s*(?:\(([^)]*)\))?\s*:', re.M)),
    ('js_function', re.compile(r'\bfunction\s+([A-Za-z_$][\w$]*)\s*\(([^)]*)\)', re.M)),
]

RISK_WORDS = re.compile(r'(exploit|payload|shellcode|meterpreter|ransom|keylogger|credential|steal|ddos|botnet|reverse shell|malware)', re.I)

def load_links():
    return json.loads((DATA/'links.json').read_text())

def classify_file(path):
    p=Path(path)
    if p.suffix.lower() in SAFE_EXTENSIONS or p.name in {'Dockerfile','Makefile','gradlew'}:
        return 'code_or_config'
    return 'other'

def extract_signatures(content):
    out=[]
    for typ,pat in SIG_PATTERNS:
        for m in pat.finditer(content):
            out.append({'type':typ,'name':m.group(1),'params':m.group(2) if m.lastindex and m.lastindex>=2 else '', 'start':m.start()})
    return out

@app.get('/api/links')
def api_links():
    return load_links()

@app.get('/api/status')
def api_status():
    return {'links':len(load_links()),'reports_done':0,'generated_modules':0}

@app.post('/api/analyze/{link_id}')
def api_analyze(link_id: int):
    links = load_links()
    link = next((l for l in links if l['id']==link_id), None)
    if not link: raise HTTPException(status_code=404)
    return {'link_id':link_id,'url':link['url'],'signatures':[],'status':'completed'}

@app.post('/api/analyze_all')
def api_analyze_all():
    links = load_links()
    return {'total':len(links),'analyzed':0,'status':'started'}`,
  },
  {
    id: 2,
    name: "App.jsx",
    language: "javascript",
    path: "frontend/src/App.jsx",
    description: "React Frontend mit Link-Übersicht und Analyse-UI",
    content: `import React,{useEffect,useState}from'react';import{createRoot}from'react-dom/client';import'./style.css';
const API='http://localhost:8000';
function App(){const[links,setLinks]=useState([]);const[status,setStatus]=useState({});const[log,setLog]=useState('');useEffect(()=>{fetch(API+'/api/links').then(r=>r.json()).then(setLinks);refresh()},[]);function refresh(){fetch(API+'/api/status').then(r=>r.json()).then(setStatus)}async function one(id){setLog('Analysiere Link '+id+' ...');let r=await fetch(API+'/api/analyze/'+id,{method:'POST'});let j=await r.json();setLog(JSON.stringify(j,null,2));refresh()}async function all(){setLog('Starte Analyse aller Links. Das kann lokal lange dauern.');let r=await fetch(API+'/api/analyze_all',{method:'POST'});let j=await r.json();setLog(JSON.stringify(j,null,2));refresh()}return <main><h1>Code Function Rebuilder Web-App</h1><p>Quelle enthält {links.length} eindeutige Links. Die App analysiert jeden Link, erkennt Code-Dateien und erzeugt eigene sichere Module aus Signaturen/Funktionsmustern.</p><section className="cards"><div>Links: {status.links||0}</div><div>Berichte: {status.reports_done||0}</div><div>Module: {status.generated_modules||0}</div></section><button onClick={all}>Alle Links analysieren</button><div className="grid">{links.map(l=><article key={l.id}><b>#{l.id}</b><span>{l.kind}</span><code>{l.url}</code><button onClick={()=>one(l.id)}>Analysieren</button></article>)}</div><pre>{log}</pre></main>}
createRoot(document.getElementById('root')).render(<App/>);`,
  },
  {
    id: 3,
    name: "style.css",
    language: "css",
    path: "frontend/src/style.css",
    description: "Dark Mode Styling mit Cyan-Akzenten",
    content: `body{font-family:system-ui;margin:0;background:#10141d;color:#eef}main{padding:24px}.cards{display:flex;gap:12px;margin:16px 0}.cards div,article{background:#1b2332;border:1px solid #334;padding:12px;border-radius:12px}.grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(320px,1fr));gap:10px}code{display:block;overflow:auto;white-space:nowrap;color:#9df}button{padding:9px 12px;border-radius:10px;border:0;margin:8px 0;cursor:pointer}pre{background:#05070a;padding:16px;border-radius:12px;overflow:auto;max-height:480px}`,
  },
  {
    id: 4,
    name: "verify_integrity.py",
    language: "python",
    path: "verify_integrity.py",
    description: "SHA256-Verifikation aller Quellzeilen und Links",
    content: `import json,hashlib,sys
from pathlib import Path
root=Path(__file__).parent
source=(root/'source'/'Notes_260615_102612.txt').read_text(errors='replace')
links=json.loads((root/'data'/'links.json').read_text())
line_audit=json.loads((root/'data'/'line_audit.json').read_text())
errors=[]
if len(line_audit)!=len(source.splitlines()): errors.append('line count mismatch')
for item in line_audit:
    if hashlib.sha256(item['text'].encode()).hexdigest()!=item['sha256']: errors.append(f"line hash mismatch {item['line']}")
if not links: errors.append('no links')
print('OK' if not errors else 'FAIL')
print('links',len(links),'lines',len(line_audit),'errors',len(errors))
if errors: print('\\n'.join(errors)); sys.exit(1)`,
  },
  {
    id: 5,
    name: "requirements.txt",
    language: "plaintext",
    path: "backend/requirements.txt",
    description: "Python-Abhängigkeiten für Backend",
    content: `fastapi
uvicorn
requests
beautifulsoup4
GitPython
python-multipart`,
  },
];

const LANGUAGE_KEYWORDS: Record<string, Record<string, string>> = {
  python: {
    keyword: "def|class|import|from|return|if|else|for|while|try|except|with|as|pass|break|continue|yield|async|await|lambda",
    builtin: "print|len|range|str|int|float|list|dict|set|tuple|open|file|input|output",
    string: "'[^']*'|\"[^\"]*\"|'''[^''']*'''|\"\"\"[^\"\"\"]*\"\"\"",
    comment: "#.*",
    number: "\\b\\d+\\.?\\d*\\b",
  },
  javascript: {
    keyword: "function|const|let|var|return|if|else|for|while|switch|case|break|continue|async|await|import|export|class|extends|new",
    builtin: "console|log|document|window|fetch|Promise|Array|Object|String|Number|Boolean",
    string: "'[^']*'|\"[^\"]*\"|`[^`]*`",
    comment: "//.*|/\\*[^*]*\\*\\/",
    number: "\\b\\d+\\.?\\d*\\b",
  },
  css: {
    keyword: "@media|@import|@keyframes|@font-face|body|div|class|id|color|background|margin|padding|border|display|flex|grid",
    string: "'[^']*'|\"[^\"]*\"",
    comment: "/\\*[^*]*\\*/",
    number: "\\b\\d+(?:px|em|%|rem)?\\b",
  },
};

export default function CodeViewerComplete() {
  const [, setLocation] = useLocation();
  const [selectedFile, setSelectedFile] = useState(ALL_CODE_FILES[0]);
  const [search, setSearch] = useState("");
  const [copied, setCopied] = useState(false);

  const handleCopy = () => {
    navigator.clipboard.writeText(selectedFile.content);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const handleDownload = () => {
    const blob = new Blob([selectedFile.content], { type: "text/plain" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = selectedFile.name;
    a.click();
  };

  const highlightLine = (line: string) => {
    const lang = selectedFile.language;
    const keywords = LANGUAGE_KEYWORDS[lang];
    
    if (!keywords) return line;

    let highlighted = line;
    
    // Kommentare (zuerst, um Konflikt zu vermeiden)
    highlighted = highlighted.replace(
      new RegExp(keywords.comment, "g"),
      '<span class="comment">$&</span>'
    );
    
    // Strings
    highlighted = highlighted.replace(
      new RegExp(keywords.string, "g"),
      '<span class="string">$&</span>'
    );
    
    // Keywords
    highlighted = highlighted.replace(
      new RegExp(`\\b(${keywords.keyword})\\b`, "g"),
      '<span class="keyword">$1</span>'
    );
    
    // Numbers
    highlighted = highlighted.replace(
      new RegExp(keywords.number, "g"),
      '<span class="number">$&</span>'
    );
    
    return highlighted;
  };

  const filteredLines = selectedFile.content
    .split("\n")
    .map((line, idx) => ({ idx: idx + 1, line }))
    .filter(({ line }) => !search || line.toLowerCase().includes(search.toLowerCase()));

  return (
    <div className="min-h-screen bg-[#10141d] text-[#eef]">
      {/* Header */}
      <div className="border-b border-[#334] bg-[#0f0f15] p-6">
        <div className="flex items-center gap-4 mb-4">
          <Button
            variant="ghost"
            onClick={() => setLocation("/dashboard")}
            className="text-[#9df] hover:bg-[#1b2332]"
          >
            <ChevronLeft className="w-4 h-4" />
          </Button>
          <h1 className="text-2xl font-bold">Code-Viewer (Vollständig)</h1>
        </div>
        <p className="text-[#9df] text-sm">Alle {ALL_CODE_FILES.length} Original-Code-Dateien mit Syntax-Highlighting</p>
      </div>

      {/* Content */}
      <div className="p-6 grid grid-cols-4 gap-6">
        {/* File List */}
        <div className="col-span-1">
          <Card className="bg-[#1b2332] border-[#334] p-4 sticky top-6">
            <h3 className="text-sm font-semibold mb-3 text-[#9df]">Dateien ({ALL_CODE_FILES.length})</h3>
            <div className="space-y-2 max-h-[600px] overflow-y-auto">
              {ALL_CODE_FILES.map((file) => (
                <Button
                  key={file.id}
                  variant={selectedFile.id === file.id ? "default" : "outline"}
                  onClick={() => setSelectedFile(file)}
                  className={`w-full justify-start text-xs flex-col items-start h-auto py-2 ${
                    selectedFile.id === file.id
                      ? "bg-[#9df] text-[#000]"
                      : "bg-[#0f0f15] border-[#334] text-[#9df]"
                  }`}
                >
                  <div className="font-semibold">{file.name}</div>
                  <div className={selectedFile.id === file.id ? "text-[#000] opacity-80" : "text-[#666] text-xs"}>
                    {file.language}
                  </div>
                </Button>
              ))}
            </div>
          </Card>
        </div>

        {/* Code Editor */}
        <div className="col-span-3 space-y-4">
          {/* File Info */}
          <Card className="bg-[#1b2332] border-[#334] p-4">
            <div className="flex justify-between items-start">
              <div>
                <h3 className="text-lg font-semibold">{selectedFile.name}</h3>
                <p className="text-[#9df] text-sm mt-1">{selectedFile.description}</p>
                <p className="text-[#666] text-xs mt-2">{selectedFile.path}</p>
              </div>
              <div className="flex gap-2">
                <Button
                  onClick={handleCopy}
                  className="bg-[#9df] text-[#000] hover:bg-[#7bc]"
                  size="sm"
                >
                  <Copy className="w-4 h-4" />
                </Button>
                <Button
                  onClick={handleDownload}
                  className="bg-[#1b2332] border border-[#334] text-[#9df]"
                  size="sm"
                >
                  <Download className="w-4 h-4" />
                </Button>
              </div>
            </div>
          </Card>

          {/* Search */}
          <div className="flex gap-2">
            <div className="flex-1 relative">
              <Search className="absolute left-3 top-2.5 w-4 h-4 text-[#666]" />
              <input
                placeholder="Code durchsuchen..."
                value={search}
                onChange={(e) => setSearch(e.target.value)}
                className="w-full bg-[#1b2332] border border-[#334] text-[#eef] pl-10 pr-4 py-2 rounded text-sm"
              />
            </div>
            <div className="text-[#9df] text-sm px-3 py-2 bg-[#1b2332] rounded border border-[#334]">
              {filteredLines.length} Zeilen
            </div>
          </div>

          {/* Code Display */}
          <Card className="bg-[#0f0f15] border-[#334] p-4 font-mono text-xs overflow-auto max-h-[700px]">
            <div className="space-y-0">
              {filteredLines.map(({ idx, line }) => (
                <div key={idx} className="flex hover:bg-[#1b2332] transition-colors">
                  <div className="text-[#666] w-12 text-right pr-4 select-none flex-shrink-0">{idx}</div>
                  <div
                    className="text-[#9df] flex-1 whitespace-pre-wrap break-words"
                    dangerouslySetInnerHTML={{ __html: highlightLine(line) }}
                  />
                </div>
              ))}
            </div>
          </Card>

          {/* Stats */}
          <Card className="bg-[#1b2332] border-[#334] p-4">
            <div className="grid grid-cols-4 gap-2 text-xs">
              <div className="bg-[#0f0f15] p-2 rounded">
                <div className="text-[#666]">Zeilen</div>
                <div className="text-[#9df] font-bold">{selectedFile.content.split("\n").length}</div>
              </div>
              <div className="bg-[#0f0f15] p-2 rounded">
                <div className="text-[#666]">Bytes</div>
                <div className="text-[#9df] font-bold">{Buffer.byteLength(selectedFile.content)}</div>
              </div>
              <div className="bg-[#0f0f15] p-2 rounded">
                <div className="text-[#666]">Sprache</div>
                <div className="text-[#9df] font-bold">{selectedFile.language}</div>
              </div>
              <div className="bg-[#0f0f15] p-2 rounded">
                <div className="text-[#666]">Dateien</div>
                <div className="text-[#9df] font-bold">{ALL_CODE_FILES.length}</div>
              </div>
            </div>
          </Card>
        </div>
      </div>

      {copied && (
        <div className="fixed bottom-6 right-6 bg-[#00ff00] text-[#000] px-4 py-2 rounded font-semibold">
          ✓ Kopiert!
        </div>
      )}

      <style>{`
        .keyword { color: #ff6b9d; font-weight: bold; }
        .string { color: #c3e88d; }
        .comment { color: #546e7a; font-style: italic; }
        .number { color: #f78c6b; }
      `}</style>
    </div>
  );
}
