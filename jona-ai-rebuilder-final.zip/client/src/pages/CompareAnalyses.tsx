import { useState } from "react";
import { trpc } from "@/lib/trpc";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Loader2, ChevronLeft } from "lucide-react";
import { useLocation } from "wouter";

export default function CompareAnalyses() {
  const [, setLocation] = useLocation();
  const [link1Id, setLink1Id] = useState<string>("");
  const [link2Id, setLink2Id] = useState<string>("");
  const [comparison, setComparison] = useState<any | null>(null);
  const [loading, setLoading] = useState(false);

  const { data: links } = trpc.analysis.listLinks.useQuery({ skip: 0, take: 1000 });

  const handleCompare = async () => {
    if (!link1Id || !link2Id) return;
    setLoading(true);

    try {
      const link1 = await fetch(`/api/trpc/analysis.getLink?input=${JSON.stringify({ linkId: parseInt(link1Id) })}`)
        .then((r) => r.json())
        .then((r) => r.result?.data);

      const link2 = await fetch(`/api/trpc/analysis.getLink?input=${JSON.stringify({ linkId: parseInt(link2Id) })}`)
        .then((r) => r.json())
        .then((r) => r.result?.data);

      setComparison({
        link1,
        link2,
        differences: {
          signatureDiff: (link1?.analysis?.signatureCount || 0) - (link2?.analysis?.signatureCount || 0),
          fileDiff: (link1?.analysis?.analyzedFiles || 0) - (link2?.analysis?.analyzedFiles || 0),
          statusChanged: link1?.analysis?.status !== link2?.analysis?.status,
        },
      });
    } catch (error) {
      console.error("Comparison failed:", error);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-[#10141d] text-[#eef]">
      {/* Header */}
      <div className="border-b border-[#334] bg-[#0f0f15] p-6">
        <div className="flex items-center gap-4 mb-4">
          <Button
            variant="ghost"
            onClick={() => setLocation("/dashboard")}
            className="text-[#9df] hover:bg-[#1b2332]"
          >
            <ChevronLeft className="w-4 h-4" />
          </Button>
          <h1 className="text-2xl font-bold">Analysen vergleichen</h1>
        </div>
        <p className="text-[#9df] text-sm">Vergleiche Signaturen und Metriken zweier Links</p>
      </div>

      {/* Content */}
      <div className="p-6 max-w-4xl mx-auto space-y-6">
        {/* Selection */}
        <Card className="bg-[#1b2332] border-[#334] p-6">
          <h3 className="text-lg font-semibold mb-4">Links auswählen</h3>
          <div className="grid grid-cols-2 gap-4 mb-4">
            <div>
              <label className="text-[#9df] text-sm block mb-2">Link 1</label>
              <Select value={link1Id} onValueChange={setLink1Id}>
                <SelectTrigger className="bg-[#0f0f15] border-[#334] text-[#eef]">
                  <SelectValue placeholder="Link auswählen..." />
                </SelectTrigger>
                <SelectContent className="bg-[#1b2332] border-[#334]">
                  {links?.map((link: any) => (
                    <SelectItem key={link.id} value={link.id.toString()}>
                      #{link.id} - {link.host}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            <div>
              <label className="text-[#9df] text-sm block mb-2">Link 2</label>
              <Select value={link2Id} onValueChange={setLink2Id}>
                <SelectTrigger className="bg-[#0f0f15] border-[#334] text-[#eef]">
                  <SelectValue placeholder="Link auswählen..." />
                </SelectTrigger>
                <SelectContent className="bg-[#1b2332] border-[#334]">
                  {links?.map((link: any) => (
                    <SelectItem key={link.id} value={link.id.toString()}>
                      #{link.id} - {link.host}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          </div>

          <Button
            onClick={handleCompare}
            disabled={!link1Id || !link2Id || loading}
            className="w-full bg-[#00ff00] text-[#000] hover:bg-[#00cc00]"
          >
            {loading ? (
              <>
                <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                Vergleiche...
              </>
            ) : (
              "Vergleichen"
            )}
          </Button>
        </Card>

        {/* Comparison Results */}
        {comparison && (
          <div className="space-y-4">
            {/* Side by Side */}
            <div className="grid grid-cols-2 gap-4">
              {/* Link 1 */}
              <Card className="bg-[#1b2332] border-[#334] p-6">
                <h3 className="text-lg font-semibold mb-4 text-[#9df]">
                  Link #{comparison.link1?.link?.id}
                </h3>
                <div className="space-y-3 text-sm">
                  <div>
                    <div className="text-[#666]">Host</div>
                    <div className="text-[#eef] font-mono">{comparison.link1?.link?.host}</div>
                  </div>
                  <div>
                    <div className="text-[#666]">Status</div>
                    <div className="text-[#eef]">{comparison.link1?.analysis?.status}</div>
                  </div>
                  <div>
                    <div className="text-[#666]">Signaturen</div>
                    <div className="text-2xl font-bold text-[#00ff00]">
                      {comparison.link1?.analysis?.signatureCount || 0}
                    </div>
                  </div>
                  <div>
                    <div className="text-[#666]">Dateien</div>
                    <div className="text-2xl font-bold text-[#9df]">
                      {comparison.link1?.analysis?.analyzedFiles || 0}
                    </div>
                  </div>
                </div>
              </Card>

              {/* Link 2 */}
              <Card className="bg-[#1b2332] border-[#334] p-6">
                <h3 className="text-lg font-semibold mb-4 text-[#9df]">
                  Link #{comparison.link2?.link?.id}
                </h3>
                <div className="space-y-3 text-sm">
                  <div>
                    <div className="text-[#666]">Host</div>
                    <div className="text-[#eef] font-mono">{comparison.link2?.link?.host}</div>
                  </div>
                  <div>
                    <div className="text-[#666]">Status</div>
                    <div className="text-[#eef]">{comparison.link2?.analysis?.status}</div>
                  </div>
                  <div>
                    <div className="text-[#666]">Signaturen</div>
                    <div className="text-2xl font-bold text-[#00ff00]">
                      {comparison.link2?.analysis?.signatureCount || 0}
                    </div>
                  </div>
                  <div>
                    <div className="text-[#666]">Dateien</div>
                    <div className="text-2xl font-bold text-[#9df]">
                      {comparison.link2?.analysis?.analyzedFiles || 0}
                    </div>
                  </div>
                </div>
              </Card>
            </div>

            {/* Differences */}
            <Card className="bg-[#1b2332] border-[#334] p-6">
              <h3 className="text-lg font-semibold mb-4">Unterschiede</h3>
              <div className="grid grid-cols-3 gap-4">
                <div className="bg-[#0f0f15] p-4 rounded">
                  <div className="text-[#9df] text-sm">Signatur-Differenz</div>
                  <div className={`text-2xl font-bold mt-2 ${comparison.differences.signatureDiff > 0 ? "text-[#00ff00]" : "text-[#ff0000]"}`}>
                    {comparison.differences.signatureDiff > 0 ? "+" : ""}{comparison.differences.signatureDiff}
                  </div>
                </div>
                <div className="bg-[#0f0f15] p-4 rounded">
                  <div className="text-[#9df] text-sm">Datei-Differenz</div>
                  <div className={`text-2xl font-bold mt-2 ${comparison.differences.fileDiff > 0 ? "text-[#00ff00]" : "text-[#ff0000]"}`}>
                    {comparison.differences.fileDiff > 0 ? "+" : ""}{comparison.differences.fileDiff}
                  </div>
                </div>
                <div className="bg-[#0f0f15] p-4 rounded">
                  <div className="text-[#9df] text-sm">Status geändert</div>
                  <div className={`text-2xl font-bold mt-2 ${comparison.differences.statusChanged ? "text-[#ff9500]" : "text-[#00ff00]"}`}>
                    {comparison.differences.statusChanged ? "Ja" : "Nein"}
                  </div>
                </div>
              </div>
            </Card>
          </div>
        )}
      </div>
    </div>
  );
}
