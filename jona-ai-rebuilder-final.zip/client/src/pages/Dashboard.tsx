import { useState } from "react";
import { trpc } from "@/lib/trpc";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Loader2, Search, Download } from "lucide-react";

function LinkRow({ link }: { link: any }) {
  const { data: analysis } = trpc.analysis.getLink.useQuery({ linkId: link.id });
  const statusColors: Record<string, string> = {
    ausstehend: "text-[#666]",
    läuft: "text-[#ff9500]",
    fertig: "text-[#00ff00]",
    Fehler: "text-[#ff0000]",
  };

  return (
    <tr className="border-b border-[#334] hover:bg-[#252d3d]">
      <td className="px-4 py-3 text-[#eef] font-mono">#{link.id}</td>
      <td className="px-4 py-3 text-[#9df] font-mono text-xs truncate max-w-[300px]">{link.url}</td>
      <td className="px-4 py-3 text-[#eef] text-xs">{link.kind}</td>
      <td className="px-4 py-3 text-[#eef]">{link.host}</td>
      <td className="px-4 py-3 text-[#eef]">{link.occurrences}</td>
      <td className={`px-4 py-3 font-semibold ${statusColors[analysis?.analysis?.status || "ausstehend"]}`}>
        {analysis?.analysis?.status || "ausstehend"}
      </td>
      <td className="px-4 py-3 text-center">
        <Button
          size="sm"
          variant="outline"
          className="bg-[#0f0f15] border-[#334] text-[#9df] hover:bg-[#1b2332]"
          onClick={() => {
            window.location.href = `/link/${link.id}`;
          }}
        >
          Details
        </Button>
      </td>
    </tr>
  );
}

export default function Dashboard() {
  const [search, setSearch] = useState("");
  const [kind, setKind] = useState<string | undefined>();
  const [skip, setSkip] = useState(0);
  const take = 50;

  const { data: linksData, isLoading: linksLoading } = trpc.analysis.listLinks.useQuery({
    skip,
    take,
    search: search || undefined,
    kind: kind || undefined,
  });

  const links = linksData || [];

  const { data: stats } = trpc.analysis.getStats.useQuery();

  const linkTypes = [
    "github_repository_or_page",
    "web_page",
    "github_topic_page",
    "download_page",
  ];

  return (
    <div className="min-h-screen bg-[#10141d] text-[#eef]">
      {/* Header */}
      <div className="border-b border-[#334] bg-[#0f0f15] p-6">
        <h1 className="text-3xl font-bold mb-2">Link-Code Rebuilder</h1>
        <p className="text-[#9df] text-sm">Analysiere 118 Links, extrahiere Funktionssignaturen und generiere Module</p>
      </div>

      {/* Statistics */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4 p-6">
        <Card className="bg-[#1b2332] border-[#334] p-4">
          <div className="text-[#9df] text-sm font-medium">Gesamt Links</div>
          <div className="text-2xl font-bold mt-2">{stats?.totalLinks || 0}</div>
        </Card>
        <Card className="bg-[#1b2332] border-[#334] p-4">
          <div className="text-[#9df] text-sm font-medium">Abgeschlossen</div>
          <div className="text-2xl font-bold mt-2">{stats?.completedAnalyses || 0}</div>
        </Card>
        <Card className="bg-[#1b2332] border-[#334] p-4">
          <div className="text-[#9df] text-sm font-medium">Module</div>
          <div className="text-2xl font-bold mt-2">{stats?.generatedModules || 0}</div>
        </Card>
        <Card className="bg-[#1b2332] border-[#334] p-4">
          <div className="text-[#9df] text-sm font-medium">Erfolgsquote</div>
          <div className="text-2xl font-bold mt-2">{stats?.successRate || 0}%</div>
        </Card>
      </div>

      {/* Navigation */}
      <div className="px-6 py-4 flex gap-2 flex-wrap">
        <Button
          variant="outline"
          className="bg-[#1b2332] border-[#334] text-[#9df]"
          onClick={() => window.location.href = "/batch"}
        >
          Batch-Analyse
        </Button>
        <Button
          variant="outline"
          className="bg-[#1b2332] border-[#334] text-[#9df]"
          onClick={() => window.location.href = "/modules"}
        >
          Module
        </Button>
        <Button
          variant="outline"
          className="bg-[#1b2332] border-[#334] text-[#9df]"
          onClick={() => window.location.href = "/compare"}
        >
          Vergleichen
        </Button>
        <Button
          variant="outline"
          className="bg-[#1b2332] border-[#334] text-[#9df]"
          onClick={() => window.location.href = "/analytics"}
        >
          Analytics
        </Button>
        <Button
          variant="outline"
          className="bg-[#1b2332] border-[#334] text-[#9df]"
          onClick={() => window.location.href = "/reports"}
        >
          Berichte
        </Button>
        <Button
          variant="outline"
          className="bg-[#1b2332] border-[#334] text-[#9df]"
          onClick={() => window.location.href = "/manifest"}
        >
          Manifest & Audit
        </Button>
        <Button
          variant="outline"
          className="bg-[#1b2332] border-[#334] text-[#9df]"
          onClick={() => window.location.href = "/code"}
        >
          Code-Viewer
        </Button>
        <Button
          variant="outline"
          className="bg-[#1b2332] border-[#334] text-[#9df]"
          onClick={() => window.location.href = "/generator"}
        >
          Modul-Generator
        </Button>
        <Button
          variant="outline"
          className="bg-[#1b2332] border-[#334] text-[#9df]"
          onClick={() => window.location.href = "/export"}
        >
          Daten-Export
        </Button>
        <Button
          variant="outline"
          className="bg-[#1b2332] border-[#334] text-[#9df]"
          onClick={() => window.location.href = "/comparison"}
        >
          Link-Vergleich
        </Button>
        <Button
          variant="outline"
          className="bg-[#1b2332] border-[#334] text-[#9df]"
          onClick={() => window.location.href = "/verification"}
        >
          Verifikation
        </Button>
        <Button
          variant="outline"
          className="bg-[#1b2332] border-[#334] text-[#9df]"
          onClick={() => window.location.href = "/settings"}
        >
          Einstellungen
        </Button>
      </div>

      {/* Filters */}
      <div className="px-6 py-4 flex gap-4 flex-wrap items-end">
        <div className="flex-1 min-w-[200px]">
          <label className="block text-sm font-medium text-[#9df] mb-2">Suchen</label>
          <div className="relative">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-[#666]" />
            <Input
              placeholder="URL durchsuchen..."
              value={search}
              onChange={(e) => {
                setSearch(e.target.value);
                setSkip(0);
              }}
              className="pl-10 bg-[#1b2332] border-[#334] text-[#eef]"
            />
          </div>
        </div>

        <div className="w-[200px]">
          <label className="block text-sm font-medium text-[#9df] mb-2">Link-Typ</label>
          <Select value={kind || ""} onValueChange={(v) => {
            setKind(v || undefined);
            setSkip(0);
          }}>
            <SelectTrigger className="bg-[#1b2332] border-[#334] text-[#eef]">
              <SelectValue placeholder="Alle Typen" />
            </SelectTrigger>
            <SelectContent className="bg-[#1b2332] border-[#334]">
              <SelectItem value="">Alle Typen</SelectItem>
              {linkTypes.map((type) => (
                <SelectItem key={type} value={type}>
                  {type}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>
      </div>

      {/* Links Table */}
      <div className="px-6 pb-6">
        <Card className="bg-[#1b2332] border-[#334] overflow-hidden">
          {linksLoading ? (
            <div className="flex items-center justify-center p-8">
              <Loader2 className="w-6 h-6 animate-spin text-[#9df]" />
            </div>
          ) : (
            <div className="overflow-x-auto">
              <table className="w-full text-sm">
                <thead className="bg-[#0f0f15] border-b border-[#334]">
                  <tr>
                    <th className="px-4 py-3 text-left font-semibold text-[#9df]">ID</th>
                    <th className="px-4 py-3 text-left font-semibold text-[#9df]">URL</th>
                    <th className="px-4 py-3 text-left font-semibold text-[#9df]">Typ</th>
                    <th className="px-4 py-3 text-left font-semibold text-[#9df]">Host</th>
                    <th className="px-4 py-3 text-left font-semibold text-[#9df]">Vorkommen</th>
                    <th className="px-4 py-3 text-left font-semibold text-[#9df]">Status</th>
                    <th className="px-4 py-3 text-center font-semibold text-[#9df]">Aktion</th>
                  </tr>
                </thead>
                <tbody>
                  {links?.map((link) => (
                    <LinkRow key={link.id} link={link} />
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </Card>

        {/* Pagination */}
        <div className="flex justify-between items-center mt-4">
          <div className="text-sm text-[#9df]">
            Zeige {skip + 1} bis {Math.min(skip + take, (links?.length || 0) + skip)} von {stats?.totalLinks || 0}
          </div>
          <div className="flex gap-2">
            <Button
              variant="outline"
              disabled={skip === 0}
              onClick={() => setSkip(Math.max(0, skip - take))}
              className="bg-[#1b2332] border-[#334] text-[#9df]"
            >
              Zurück
            </Button>
            <Button
              variant="outline"
              onClick={() => setSkip(skip + take)}
              className="bg-[#1b2332] border-[#334] text-[#9df]"
            >
              Weiter
            </Button>
          </div>
        </div>
      </div>
    </div>
  );
}
