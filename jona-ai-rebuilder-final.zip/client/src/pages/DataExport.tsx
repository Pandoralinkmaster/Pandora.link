import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { ChevronLeft, Download, Copy, Eye } from "lucide-react";
import { useLocation } from "wouter";

// Import der Daten (werden später aus Datenbank geladen)
const SAMPLE_LINKS_COUNT = 118;
const SAMPLE_AUDIT_COUNT = 126;

export default function DataExport() {
  const [, setLocation] = useLocation();
  const [exportFormat, setExportFormat] = useState<"json" | "csv">("json");
  const [copied, setCopied] = useState(false);
  const [viewingData, setViewingData] = useState<"links" | "audit" | null>(null);

  const handleDownloadLinks = async () => {
    try {
      const response = await fetch("/data-links.json");
      const data = await response.json();
      
      let content = "";
      if (exportFormat === "json") {
        content = JSON.stringify(data, null, 2);
      } else {
        // CSV Format
        const headers = ["ID", "URL", "Host", "Path", "Kind", "SHA256", "Occurrences"];
        const rows = data.map((link: any) => [
          link.id,
          link.url,
          link.host,
          link.path,
          link.kind,
          link.sha256.substring(0, 16) + "...",
          link.occurrences.length,
        ]);
        content = [headers, ...rows].map((row: any[]) => row.map((cell: any) => `"${cell}"`).join(",")).join("\n");
      }
      
      const blob = new Blob([content], { type: "text/plain" });
      const url = URL.createObjectURL(blob);
      const a = document.createElement("a");
      a.href = url;
      a.download = `all_links_118.${exportFormat}`;
      a.click();
    } catch (error) {
      console.error("Download failed:", error);
    }
  };

  const handleDownloadAudit = async () => {
    try {
      const response = await fetch("/data-audit.json");
      const data = await response.json();
      
      let content = "";
      if (exportFormat === "json") {
        content = JSON.stringify(data, null, 2);
      } else {
        // CSV Format
        const headers = ["Line", "Text", "SHA256", "URL Count"];
        const rows = data.map((item: any) => [
          item.line,
          item.text.substring(0, 50),
          item.sha256.substring(0, 16) + "...",
          item.urls.length,
        ]);
        content = [headers, ...rows].map((row: any[]) => row.map((cell: any) => `"${cell}"`).join(",")).join("\n");
      }
      
      const blob = new Blob([content], { type: "text/plain" });
      const url = URL.createObjectURL(blob);
      const a = document.createElement("a");
      a.href = url;
      a.download = `audit_lines_126.${exportFormat}`;
      a.click();
    } catch (error) {
      console.error("Download failed:", error);
    }
  };

  const handleCopyLinks = async () => {
    try {
      const response = await fetch("/data-links.json");
      const data = await response.json();
      const text = JSON.stringify(data, null, 2);
      navigator.clipboard.writeText(text);
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    } catch (error) {
      console.error("Copy failed:", error);
    }
  };

  return (
    <div className="min-h-screen bg-[#10141d] text-[#eef]">
      {/* Header */}
      <div className="border-b border-[#334] bg-[#0f0f15] p-6">
        <div className="flex items-center gap-4 mb-4">
          <Button
            variant="ghost"
            onClick={() => setLocation("/dashboard")}
            className="text-[#9df] hover:bg-[#1b2332]"
          >
            <ChevronLeft className="w-4 h-4" />
          </Button>
          <h1 className="text-2xl font-bold">Daten-Export</h1>
        </div>
        <p className="text-[#9df] text-sm">Exportiere alle 118 Links und 126 Audit-Zeilen</p>
      </div>

      {/* Content */}
      <div className="p-6 max-w-4xl mx-auto space-y-6">
        {/* Format Selection */}
        <Card className="bg-[#1b2332] border-[#334] p-6">
          <h3 className="text-lg font-semibold mb-4">Export-Format</h3>
          <div className="flex gap-4">
            <label className="flex items-center gap-2 cursor-pointer">
              <input
                type="radio"
                name="format"
                value="json"
                checked={exportFormat === "json"}
                onChange={(e) => setExportFormat(e.target.value as "json" | "csv")}
                className="w-4 h-4"
              />
              <span className="text-[#9df]">JSON (strukturiert)</span>
            </label>
            <label className="flex items-center gap-2 cursor-pointer">
              <input
                type="radio"
                name="format"
                value="csv"
                checked={exportFormat === "csv"}
                onChange={(e) => setExportFormat(e.target.value as "json" | "csv")}
                className="w-4 h-4"
              />
              <span className="text-[#9df]">CSV (tabellarisch)</span>
            </label>
          </div>
        </Card>

        {/* Links Export */}
        <Card className="bg-[#1b2332] border-[#334] p-6">
          <div className="flex justify-between items-start mb-4">
            <div>
              <h3 className="text-lg font-semibold">Alle Links (118)</h3>
              <p className="text-[#9df] text-sm mt-1">Vollständige Liste aller analysierten Links mit Metadaten</p>
            </div>
            <div className="flex gap-2">
              <Button
                onClick={() => setViewingData(viewingData === "links" ? null : "links")}
                className="bg-[#1b2332] border border-[#334] text-[#9df]"
                size="sm"
              >
                <Eye className="w-4 h-4 mr-1" />
                Vorschau
              </Button>
              <Button
                onClick={handleCopyLinks}
                className="bg-[#9df] text-[#000] hover:bg-[#7bc]"
                size="sm"
              >
                <Copy className="w-4 h-4" />
              </Button>
              <Button
                onClick={handleDownloadLinks}
                className="bg-[#00ff00] text-[#000] hover:bg-[#00cc00]"
                size="sm"
              >
                <Download className="w-4 h-4" />
              </Button>
            </div>
          </div>

          {viewingData === "links" && (
            <div className="mt-4 bg-[#0f0f15] p-4 rounded max-h-[300px] overflow-auto font-mono text-xs">
              <div className="text-[#9df]">
                Lade Links-Daten...
              </div>
            </div>
          )}
        </Card>

        {/* Audit Lines Export */}
        <Card className="bg-[#1b2332] border-[#334] p-6">
          <div className="flex justify-between items-start mb-4">
            <div>
              <h3 className="text-lg font-semibold">Audit-Zeilen (126)</h3>
              <p className="text-[#9df] text-sm mt-1">Alle 126 Quellzeilen mit SHA256-Hashes und URL-Verknüpfungen</p>
            </div>
            <div className="flex gap-2">
              <Button
                onClick={() => setViewingData(viewingData === "audit" ? null : "audit")}
                className="bg-[#1b2332] border border-[#334] text-[#9df]"
                size="sm"
              >
                <Eye className="w-4 h-4 mr-1" />
                Vorschau
              </Button>
              <Button
                onClick={handleDownloadAudit}
                className="bg-[#00ff00] text-[#000] hover:bg-[#00cc00]"
                size="sm"
              >
                <Download className="w-4 h-4" />
              </Button>
            </div>
          </div>

          {viewingData === "audit" && (
            <div className="mt-4 bg-[#0f0f15] p-4 rounded max-h-[300px] overflow-auto font-mono text-xs">
              <div className="text-[#9df]">
                Lade Audit-Daten...
              </div>
            </div>
          )}
        </Card>

        {/* Statistics */}
        <Card className="bg-[#1b2332] border-[#334] p-6">
          <h3 className="text-lg font-semibold mb-4">Statistiken</h3>
          <div className="grid grid-cols-3 gap-4">
            <div className="bg-[#0f0f15] p-4 rounded text-center">
              <div className="text-[#9df] text-sm">Gesamt Links</div>
              <div className="text-3xl font-bold text-[#00ff00] mt-2">118</div>
            </div>
            <div className="bg-[#0f0f15] p-4 rounded text-center">
              <div className="text-[#9df] text-sm">Audit-Zeilen</div>
              <div className="text-3xl font-bold text-[#00ff00] mt-2">126</div>
            </div>
            <div className="bg-[#0f0f15] p-4 rounded text-center">
              <div className="text-[#9df] text-sm">Daten-Größe</div>
              <div className="text-3xl font-bold text-[#00ff00] mt-2">~103 KB</div>
            </div>
          </div>
        </Card>

        {/* Info */}
        <Card className="bg-[#1b3a2d] border-[#336b5a] p-4">
          <h4 className="text-[#9df] font-semibold text-sm mb-2">ℹ️ Daten-Formate</h4>
          <div className="text-[#9df] text-xs space-y-2">
            <p><strong>JSON:</strong> Vollständig strukturiert mit allen Metadaten und verschachtelten Objekten</p>
            <p><strong>CSV:</strong> Tabellarisch für Excel/Sheets, gekürzte Werte für bessere Lesbarkeit</p>
            <p>Alle Links enthalten: ID, URL, Host, Pfad, Typ, SHA256, Vorkommen</p>
            <p>Alle Audit-Zeilen enthalten: Zeilennummer, Text, SHA256, verknüpfte URLs</p>
          </div>
        </Card>
      </div>

      {copied && (
        <div className="fixed bottom-6 right-6 bg-[#00ff00] text-[#000] px-4 py-2 rounded font-semibold">
          ✓ Kopiert!
        </div>
      )}
    </div>
  );
}
