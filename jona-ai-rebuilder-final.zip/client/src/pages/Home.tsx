import { useAuth } from "@/_core/hooks/useAuth";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { useLocation } from "wouter";
import { getLoginUrl } from "@/const";
import { Code2, Database, Zap, GitBranch } from "lucide-react";

export default function Home() {
  const { user, isAuthenticated, logout } = useAuth();
  const [, setLocation] = useLocation();

  if (!isAuthenticated) {
    return (
      <div className="min-h-screen bg-[#10141d] text-[#eef] flex flex-col">
        {/* Header */}
        <div className="border-b border-[#334] bg-[#0f0f15] p-8">
          <h1 className="text-4xl font-bold mb-2">Link-Code Rebuilder</h1>
          <p className="text-[#9df] text-lg">Analysiere 118 Links, extrahiere Funktionssignaturen und generiere sichere Module</p>
        </div>

        {/* Features */}
        <div className="flex-1 p-8">
          <div className="grid md:grid-cols-2 gap-6 max-w-4xl mx-auto">
            <Card className="bg-[#1b2332] border-[#334] p-6">
              <Code2 className="w-8 h-8 text-[#9df] mb-3" />
              <h3 className="text-lg font-semibold mb-2">Funktionssignaturen</h3>
              <p className="text-[#9df] text-sm">Extrahiere Python, JavaScript, TypeScript, Go, Kotlin und Java Funktionen automatisch</p>
            </Card>
            <Card className="bg-[#1b2332] border-[#334] p-6">
              <Database className="w-8 h-8 text-[#9df] mb-3" />
              <h3 className="text-lg font-semibold mb-2">Datenbank-Analyse</h3>
              <p className="text-[#9df] text-sm">Speichere Analyseergebnisse, Signaturen und Berichte in einer strukturierten Datenbank</p>
            </Card>
            <Card className="bg-[#1b2332] border-[#334] p-6">
              <Zap className="w-8 h-8 text-[#9df] mb-3" />
              <h3 className="text-lg font-semibold mb-2">Modul-Generator</h3>
              <p className="text-[#9df] text-sm">Generiere sichere Python-Module aus erkannten Signaturen als Download</p>
            </Card>
            <Card className="bg-[#1b2332] border-[#334] p-6">
              <GitBranch className="w-8 h-8 text-[#9df] mb-3" />
              <h3 className="text-lg font-semibold mb-2">GitHub-Integration</h3>
              <p className="text-[#9df] text-sm">Crawle GitHub-Repositories und analysiere Code-Dateien automatisch</p>
            </Card>
          </div>
        </div>

        {/* CTA */}
        <div className="border-t border-[#334] bg-[#0f0f15] p-8 text-center">
          <Button
            onClick={() => {
              const url = getLoginUrl();
              const redirectUrl = new URL(url);
              redirectUrl.searchParams.set("returnTo", "/dashboard");
              window.location.href = redirectUrl.toString();
            }}
            className="bg-[#00ff00] text-[#000] hover:bg-[#00cc00] text-lg px-8 py-6"
          >
            Mit Manus anmelden
          </Button>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-[#10141d] text-[#eef] flex flex-col">
      {/* Header */}
      <div className="border-b border-[#334] bg-[#0f0f15] p-8 flex justify-between items-center">
        <div>
          <h1 className="text-3xl font-bold">Link-Code Rebuilder</h1>
          <p className="text-[#9df] mt-1">Willkommen, {user?.name || "Benutzer"}</p>
        </div>
        <div className="flex gap-3">
          <Button
            onClick={() => setLocation("/dashboard")}
            className="bg-[#00ff00] text-[#000] hover:bg-[#00cc00]"
          >
            Zum Dashboard
          </Button>
          <Button
            onClick={logout}
            variant="outline"
            className="border-[#334] text-[#9df] hover:bg-[#1b2332]"
          >
            Abmelden
          </Button>
        </div>
      </div>

      {/* Content */}
      <div className="flex-1 p-8 text-center">
        <p className="text-[#9df]">Klicke auf "Zum Dashboard" um die Analyse zu starten</p>
      </div>
    </div>
  );
}
