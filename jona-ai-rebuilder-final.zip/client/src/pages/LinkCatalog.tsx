import { useState } from "react";
import { trpc } from "@/lib/trpc";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Loader2, ChevronLeft, ExternalLink, Tag } from "lucide-react";
import { useLocation } from "wouter";

export default function LinkCatalog() {
  const [, setLocation] = useLocation();
  const [search, setSearch] = useState("");
  const [skip, setSkip] = useState(0);
  const take = 25;

  const { data: links, isLoading } = trpc.analysis.listLinks.useQuery({
    skip,
    take,
    search: search || undefined,
  });

  const filteredLinks = links || [];

  const getCategoryColor = (kind: string) => {
    if (kind.includes("github")) return "bg-[#333] text-[#eef]";
    if (kind.includes("web")) return "bg-[#1b3a5c] text-[#9df]";
    if (kind.includes("documentation")) return "bg-[#2d3a1b] text-[#9f9]";
    return "bg-[#2d2d2d] text-[#bbb]";
  };

  return (
    <div className="min-h-screen bg-[#10141d] text-[#eef]">
      {/* Header */}
      <div className="border-b border-[#334] bg-[#0f0f15] p-6">
        <div className="flex items-center gap-4 mb-4">
          <Button
            variant="ghost"
            onClick={() => setLocation("/dashboard")}
            className="text-[#9df] hover:bg-[#1b2332]"
          >
            <ChevronLeft className="w-4 h-4" />
          </Button>
          <h1 className="text-2xl font-bold">Link-Katalog</h1>
        </div>
        <p className="text-[#9df] text-sm">Alle 118 Links durchsuchen und erkunden</p>
      </div>

      {/* Search */}
      <div className="px-6 py-4">
        <Input
          placeholder="Nach URL, Host oder Typ suchen..."
          value={search}
          onChange={(e) => {
            setSearch(e.target.value);
            setSkip(0);
          }}
          className="bg-[#1b2332] border-[#334] text-[#eef]"
        />
      </div>

      {/* Links Grid */}
      <div className="p-6">
        {isLoading ? (
          <div className="flex items-center justify-center p-8">
            <Loader2 className="w-6 h-6 animate-spin text-[#9df]" />
          </div>
        ) : filteredLinks.length === 0 ? (
          <div className="text-center text-[#9df] py-8">
            Keine Links gefunden
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {filteredLinks.map((link: any) => (
              <Card
                key={link.id}
                className="bg-[#1b2332] border-[#334] p-4 hover:border-[#9df] transition-colors cursor-pointer"
                onClick={() => window.location.href = `/link/${link.id}`}
              >
                <div className="space-y-3">
                  {/* ID & Type */}
                  <div className="flex justify-between items-start gap-2">
                    <div className="text-[#9df] font-mono text-sm">#{link.id}</div>
                    <div className={`px-2 py-1 rounded text-xs font-semibold ${getCategoryColor(link.kind)}`}>
                      {link.kind}
                    </div>
                  </div>

                  {/* URL */}
                  <div>
                    <a
                      href={link.url}
                      target="_blank"
                      rel="noopener noreferrer"
                      onClick={(e) => e.stopPropagation()}
                      className="text-[#9df] hover:text-[#7bc] text-sm font-mono truncate flex items-center gap-1"
                    >
                      {link.url.substring(0, 40)}...
                      <ExternalLink className="w-3 h-3" />
                    </a>
                  </div>

                  {/* Host */}
                  <div className="text-[#666] text-xs font-mono">{link.host}</div>

                  {/* Metadata */}
                  <div className="flex gap-2 text-xs">
                    <span className="bg-[#0f0f15] px-2 py-1 rounded text-[#9df]">
                      <Tag className="w-3 h-3 inline mr-1" />
                      {link.occurrences}x
                    </span>
                    <span className="bg-[#0f0f15] px-2 py-1 rounded text-[#666] font-mono">
                      {link.sha256.substring(0, 8)}...
                    </span>
                  </div>

                  {/* Details Button */}
                  <Button
                    onClick={(e) => {
                      e.stopPropagation();
                      window.location.href = `/link/${link.id}`;
                    }}
                    className="w-full bg-[#9df] text-[#000] hover:bg-[#7bc] text-xs"
                  >
                    Details anzeigen
                  </Button>
                </div>
              </Card>
            ))}
          </div>
        )}

        {/* Pagination */}
        {filteredLinks.length > 0 && (
          <div className="flex justify-between items-center mt-6">
            <div className="text-sm text-[#9df]">
              Zeige {skip + 1} bis {Math.min(skip + take, 118)}
            </div>
            <div className="flex gap-2">
              <Button
                variant="outline"
                disabled={skip === 0}
                onClick={() => setSkip(Math.max(0, skip - take))}
                className="bg-[#1b2332] border-[#334] text-[#9df]"
              >
                Zurück
              </Button>
              <Button
                variant="outline"
                disabled={skip + take >= 118}
                onClick={() => setSkip(skip + take)}
                className="bg-[#1b2332] border-[#334] text-[#9df]"
              >
                Weiter
              </Button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
