import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { ChevronLeft, BarChart3 } from "lucide-react";
import { useLocation } from "wouter";

const SAMPLE_LINKS = [
  { id: 1, url: "https://github.com/NationalSecurityAgency/accumulo-python3", kind: "github_repository" },
  { id: 2, url: "https://github.com/apache/accumulo", kind: "github_repository" },
  { id: 3, url: "https://nifi.apache.org/download/", kind: "download_page" },
  { id: 4, url: "https://github.com/nsacyber/BitLocker-Guidance", kind: "github_repository" },
  { id: 5, url: "https://github.com/nsacyber/Blocking-Outdated-Web-Technologies", kind: "github_repository" },
];

export default function LinkComparison() {
  const [, setLocation] = useLocation();
  const [selectedLinks, setSelectedLinks] = useState<number[]>([1, 2]);
  const [comparisonResults, setComparisonResults] = useState<any>(null);

  const toggleLink = (id: number) => {
    setSelectedLinks(prev =>
      prev.includes(id) ? prev.filter(l => l !== id) : [...prev, id]
    );
  };

  const handleCompare = () => {
    // Simuliere Vergleich
    const results = {
      links: selectedLinks.map(id => SAMPLE_LINKS.find(l => l.id === id)),
      commonTypes: selectedLinks.length > 1 ? ["github_repository"] : [],
      uniqueHosts: selectedLinks.map(id => {
        const link = SAMPLE_LINKS.find(l => l.id === id);
        return link?.url.split("/")[2];
      }),
      totalLinks: selectedLinks.length,
    };
    setComparisonResults(results);
  };

  return (
    <div className="min-h-screen bg-[#10141d] text-[#eef]">
      {/* Header */}
      <div className="border-b border-[#334] bg-[#0f0f15] p-6">
        <div className="flex items-center gap-4 mb-4">
          <Button
            variant="ghost"
            onClick={() => setLocation("/dashboard")}
            className="text-[#9df] hover:bg-[#1b2332]"
          >
            <ChevronLeft className="w-4 h-4" />
          </Button>
          <h1 className="text-2xl font-bold">Link-Vergleich</h1>
        </div>
        <p className="text-[#9df] text-sm">Vergleiche mehrere Links und analysiere Gemeinsamkeiten</p>
      </div>

      {/* Content */}
      <div className="p-6 grid grid-cols-3 gap-6">
        {/* Link Selection */}
        <div className="col-span-1">
          <Card className="bg-[#1b2332] border-[#334] p-6">
            <h3 className="text-lg font-semibold mb-4">Links auswählen</h3>
            <div className="space-y-2 max-h-[400px] overflow-y-auto">
              {SAMPLE_LINKS.map(link => (
                <label key={link.id} className="flex items-center gap-2 cursor-pointer p-2 rounded hover:bg-[#0f0f15]">
                  <input
                    type="checkbox"
                    checked={selectedLinks.includes(link.id)}
                    onChange={() => toggleLink(link.id)}
                    className="w-4 h-4"
                  />
                  <div className="flex-1 min-w-0">
                    <div className="text-[#9df] text-sm truncate">#{link.id}</div>
                    <div className="text-[#666] text-xs truncate">{link.url.substring(0, 40)}...</div>
                  </div>
                </label>
              ))}
            </div>

            <Button
              onClick={handleCompare}
              disabled={selectedLinks.length < 2}
              className="w-full mt-4 bg-[#00ff00] text-[#000] hover:bg-[#00cc00]"
            >
              <BarChart3 className="w-4 h-4 mr-2" />
              Vergleichen ({selectedLinks.length})
            </Button>
          </Card>
        </div>

        {/* Comparison Results */}
        <div className="col-span-2 space-y-4">
          {comparisonResults ? (
            <>
              {/* Summary */}
              <Card className="bg-[#1b2332] border-[#334] p-6">
                <h3 className="text-lg font-semibold mb-4">Vergleichs-Zusammenfassung</h3>
                <div className="grid grid-cols-3 gap-4">
                  <div className="bg-[#0f0f15] p-4 rounded text-center">
                    <div className="text-[#9df] text-sm">Ausgewählte Links</div>
                    <div className="text-3xl font-bold text-[#00ff00] mt-2">{comparisonResults.totalLinks}</div>
                  </div>
                  <div className="bg-[#0f0f15] p-4 rounded text-center">
                    <div className="text-[#9df] text-sm">Gemeinsame Typen</div>
                    <div className="text-3xl font-bold text-[#9df] mt-2">{comparisonResults.commonTypes.length}</div>
                  </div>
                  <div className="bg-[#0f0f15] p-4 rounded text-center">
                    <div className="text-[#9df] text-sm">Unique Hosts</div>
                    <div className="text-3xl font-bold text-[#9df] mt-2">{new Set(comparisonResults.uniqueHosts).size}</div>
                  </div>
                </div>
              </Card>

              {/* Details */}
              <Card className="bg-[#1b2332] border-[#334] p-6">
                <h3 className="text-lg font-semibold mb-4">Details</h3>
                <div className="space-y-3">
                  <div>
                    <h4 className="text-[#9df] font-semibold text-sm mb-2">Ausgewählte Links:</h4>
                    <div className="space-y-1">
                      {comparisonResults.links.map((link: any) => (
                        <div key={link.id} className="bg-[#0f0f15] p-2 rounded text-xs">
                          <div className="text-[#9df]">#{link.id} - {link.kind}</div>
                          <div className="text-[#666] truncate">{link.url}</div>
                        </div>
                      ))}
                    </div>
                  </div>

                  <div>
                    <h4 className="text-[#9df] font-semibold text-sm mb-2">Gemeinsame Typen:</h4>
                    <div className="flex gap-2 flex-wrap">
                      {comparisonResults.commonTypes.map((type: string) => (
                        <span key={type} className="bg-[#0f0f15] px-2 py-1 rounded text-xs text-[#9df]">
                          {type}
                        </span>
                      ))}
                    </div>
                  </div>

                  <div>
                    <h4 className="text-[#9df] font-semibold text-sm mb-2">Hosts:</h4>
                    <div className="flex gap-2 flex-wrap">
                      {Array.from(new Set(comparisonResults.uniqueHosts)).map((host: any) => (
                        <span key={host} className="bg-[#0f0f15] px-2 py-1 rounded text-xs text-[#9df]">
                          {host}
                        </span>
                      ))}
                    </div>
                  </div>
                </div>
              </Card>

              {/* Recommendations */}
              <Card className="bg-[#1b3a2d] border-[#336b5a] p-4">
                <h4 className="text-[#9df] font-semibold text-sm mb-2">💡 Empfehlungen</h4>
                <ul className="text-[#9df] text-xs space-y-1">
                  <li>• Diese Links stammen von {new Set(comparisonResults.uniqueHosts).size} verschiedenen Hosts</li>
                  <li>• {comparisonResults.commonTypes.length} gemeinsame Link-Typen gefunden</li>
                  <li>• Für detaillierte Code-Vergleiche nutze den Code-Viewer</li>
                </ul>
              </Card>
            </>
          ) : (
            <Card className="bg-[#1b2332] border-[#334] p-12 text-center">
              <div className="text-[#666]">
                <p className="mb-2">Wähle mindestens 2 Links aus und klicke "Vergleichen"</p>
                <p className="text-sm">um eine Analyse zu starten</p>
              </div>
            </Card>
          )}
        </div>
      </div>
    </div>
  );
}
