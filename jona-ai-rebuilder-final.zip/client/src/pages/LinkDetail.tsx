import { useParams, useLocation } from "wouter";
import { useState } from "react";
import { trpc } from "@/lib/trpc";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Loader2, ChevronLeft, Download } from "lucide-react";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";

export default function LinkDetail() {
  const { linkId } = useParams<{ linkId: string }>();
  const [, setLocation] = useLocation();
  const [analyzing, setAnalyzing] = useState(false);

  const linkIdNum = parseInt(linkId || "0");
  const { data: linkData, isLoading, refetch } = trpc.analysis.getLink.useQuery({ linkId: linkIdNum });
  const analyzeMutation = trpc.analysis.analyzeLink.useMutation();

  const handleAnalyze = async () => {
    setAnalyzing(true);
    try {
      await analyzeMutation.mutateAsync({ linkId: linkIdNum });
      refetch();
    } finally {
      setAnalyzing(false);
    }
  };

  if (isLoading) {
    return (
      <div className="min-h-screen bg-[#10141d] flex items-center justify-center">
        <Loader2 className="w-8 h-8 animate-spin text-[#9df]" />
      </div>
    );
  }

  if (!linkData) {
    return (
      <div className="min-h-screen bg-[#10141d] text-[#eef] p-6">
        <div>Link nicht gefunden</div>
      </div>
    );
  }

  const { link, analysis, signatures } = linkData;
  const statusColors: Record<string, string> = {
    ausstehend: "text-[#666]",
    läuft: "text-[#ff9500]",
    fertig: "text-[#00ff00]",
    Fehler: "text-[#ff0000]",
  };

  return (
    <div className="min-h-screen bg-[#10141d] text-[#eef]">
      {/* Header */}
      <div className="border-b border-[#334] bg-[#0f0f15] p-6">
        <div className="flex items-center gap-4 mb-4">
          <Button
            variant="ghost"
            onClick={() => setLocation("/dashboard")}
            className="text-[#9df] hover:bg-[#1b2332]"
          >
            <ChevronLeft className="w-4 h-4" />
          </Button>
          <h1 className="text-2xl font-bold">Link #{link.id}</h1>
        </div>
        <p className="text-[#9df] font-mono text-sm break-all">{link.url}</p>
      </div>

      {/* Content */}
      <div className="p-6 space-y-6">
        {/* Metadata */}
        <Card className="bg-[#1b2332] border-[#334] p-6">
          <h2 className="text-lg font-semibold mb-4">Metadaten</h2>
          <div className="grid grid-cols-2 md:grid-cols-3 gap-4 text-sm">
            <div>
              <div className="text-[#9df] font-medium">Host</div>
              <div className="text-[#eef] font-mono">{link.host}</div>
            </div>
            <div>
              <div className="text-[#9df] font-medium">Typ</div>
              <div className="text-[#eef]">{link.kind}</div>
            </div>
            <div>
              <div className="text-[#9df] font-medium">Vorkommen</div>
              <div className="text-[#eef]">{link.occurrences}</div>
            </div>
            <div>
              <div className="text-[#9df] font-medium">Pfad</div>
              <div className="text-[#eef] font-mono text-xs break-all">{link.path}</div>
            </div>
            <div className="col-span-2 md:col-span-3">
              <div className="text-[#9df] font-medium">SHA256</div>
              <div className="text-[#eef] font-mono text-xs break-all">{link.sha256}</div>
            </div>
          </div>
        </Card>

        {/* Analysis Status */}
        <Card className="bg-[#1b2332] border-[#334] p-6">
          <div className="flex items-center justify-between mb-4">
            <h2 className="text-lg font-semibold">Analyse</h2>
            <div className={`font-semibold ${statusColors[analysis?.status || "ausstehend"]}`}>
              {analysis?.status || "ausstehend"}
            </div>
          </div>

          {analysis ? (
            <div className="space-y-4 text-sm">
              <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                <div>
                  <div className="text-[#9df]">Dateien gesamt</div>
                  <div className="text-lg font-bold">{analysis.totalFiles || 0}</div>
                </div>
                <div>
                  <div className="text-[#9df]">Code-Dateien</div>
                  <div className="text-lg font-bold">{analysis.selectedCodeFiles || 0}</div>
                </div>
                <div>
                  <div className="text-[#9df]">Analysiert</div>
                  <div className="text-lg font-bold">{analysis.analyzedFiles || 0}</div>
                </div>
                <div>
                  <div className="text-[#9df]">Signaturen</div>
                  <div className="text-lg font-bold">{analysis.signatureCount || 0}</div>
                </div>
              </div>

              {analysis.aiSummary && (
                <div className="bg-[#0f0f15] p-4 rounded border border-[#334]">
                  <div className="text-[#9df] font-medium mb-2">KI-Zusammenfassung</div>
                  <p className="text-[#eef] text-sm">{analysis.aiSummary}</p>
                </div>
              )}

              {analysis.errorMessage && (
                <div className="bg-[#2d1515] p-4 rounded border border-[#8b3333]">
                  <div className="text-[#ff6b6b] font-medium mb-2">Fehler</div>
                  <p className="text-[#eef] text-sm font-mono">{analysis.errorMessage}</p>
                </div>
              )}
            </div>
          ) : (
            <div className="text-[#9df] text-sm">Keine Analyse vorhanden</div>
          )}

          <Button
            onClick={handleAnalyze}
            disabled={analyzing || analysis?.status === "läuft"}
            className="mt-4 bg-[#00ff00] text-[#000] hover:bg-[#00cc00]"
          >
            {analyzing || analysis?.status === "läuft" ? (
              <>
                <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                Analysiere...
              </>
            ) : (
              "Analysieren"
            )}
          </Button>
        </Card>

        {/* Signatures */}
        {signatures.length > 0 && (
          <Card className="bg-[#1b2332] border-[#334] p-6">
            <div className="flex justify-between items-center mb-4">
              <h2 className="text-lg font-semibold">Funktionssignaturen ({signatures.length})</h2>
              <Button
                onClick={() => window.location.href = `/signatures/${linkIdNum}`}
                className="bg-[#9df] text-[#000] hover:bg-[#7bc]"
              >
                Vollständiger Viewer
              </Button>
            </div>
            <Tabs defaultValue="all" className="w-full">
              <TabsList className="bg-[#0f0f15] border-b border-[#334]">
                <TabsTrigger value="all" className="text-[#9df]">Alle</TabsTrigger>
                <TabsTrigger value="functions" className="text-[#9df]">Funktionen</TabsTrigger>
                <TabsTrigger value="classes" className="text-[#9df]">Klassen</TabsTrigger>
              </TabsList>

              <TabsContent value="all" className="space-y-2 mt-4">
                {signatures.map((sig) => (
                  <div key={sig.id} className="bg-[#0f0f15] p-3 rounded font-mono text-xs text-[#9df] break-all">
                    <div className="text-[#666] mb-1">{sig.signatureType}</div>
                    <div>{sig.name}({sig.params})</div>
                    <div className="text-[#666] text-xs mt-1">{sig.filePath}</div>
                  </div>
                ))}
              </TabsContent>

              <TabsContent value="functions" className="space-y-2 mt-4">
                {signatures
                  .filter((s) => s.signatureType.includes("function"))
                  .map((sig) => (
                    <div key={sig.id} className="bg-[#0f0f15] p-3 rounded font-mono text-xs text-[#9df] break-all">
                      <div>{sig.name}({sig.params})</div>
                    </div>
                  ))}
              </TabsContent>

              <TabsContent value="classes" className="space-y-2 mt-4">
                {signatures
                  .filter((s) => s.signatureType.includes("class"))
                  .map((sig) => (
                    <div key={sig.id} className="bg-[#0f0f15] p-3 rounded font-mono text-xs text-[#9df] break-all">
                      <div>{sig.name}</div>
                    </div>
                  ))}
              </TabsContent>
            </Tabs>
          </Card>
        )}
      </div>
    </div>
  );
}
