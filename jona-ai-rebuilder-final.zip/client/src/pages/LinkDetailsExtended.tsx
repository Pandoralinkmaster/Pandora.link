import { useState } from "react";
import { useParams } from "wouter";
import { trpc } from "@/lib/trpc";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Loader2, ChevronLeft, ExternalLink, Copy } from "lucide-react";
import { useLocation } from "wouter";

export default function LinkDetailsExtended() {
  const { linkId } = useParams<{ linkId: string }>();
  const [, setLocation] = useLocation();
  const linkIdNum = parseInt(linkId || "0");

  const { data: linkData, isLoading } = trpc.analysis.getLink.useQuery({ linkId: linkIdNum });
  const [copied, setCopied] = useState(false);

  if (isLoading) {
    return (
      <div className="min-h-screen bg-[#10141d] flex items-center justify-center">
        <Loader2 className="w-8 h-8 animate-spin text-[#9df]" />
      </div>
    );
  }

  if (!linkData) {
    return (
      <div className="min-h-screen bg-[#10141d] text-[#eef] p-6">
        <div>Link nicht gefunden</div>
      </div>
    );
  }

  const { link, analysis, signatures } = linkData;

  const handleCopy = (text: string) => {
    navigator.clipboard.writeText(text);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const isGitHub = link.url.includes("github.com");
  const isNSA = link.host.includes("nsacyber") || link.host.includes("NationalSecurityAgency");
  const isGovernment = link.host.includes("gov") || link.host.includes("gsa");

  const sigsByType = signatures.reduce((acc: Record<string, any[]>, sig: any) => {
    if (!acc[sig.signatureType]) acc[sig.signatureType] = [];
    acc[sig.signatureType].push(sig);
    return acc;
  }, {});

  const riskTerms = analysis?.riskTermsFound ? JSON.parse(analysis.riskTermsFound) : [];
  const hasRiskTerms = riskTerms.length > 0;

  return (
    <div className="min-h-screen bg-[#10141d] text-[#eef]">
      {/* Header */}
      <div className="border-b border-[#334] bg-[#0f0f15] p-6">
        <div className="flex items-center gap-4 mb-4">
          <Button
            variant="ghost"
            onClick={() => setLocation("/dashboard")}
            className="text-[#9df] hover:bg-[#1b2332]"
          >
            <ChevronLeft className="w-4 h-4" />
          </Button>
          <h1 className="text-2xl font-bold">Link #{link.id} - Erweiterte Details</h1>
        </div>
        <div className="flex gap-2 flex-wrap">
          {isNSA && <span className="bg-[#ff6b6b] text-[#000] px-3 py-1 rounded text-xs font-semibold">NSA/Cyber</span>}
          {isGovernment && <span className="bg-[#4dabf7] text-[#000] px-3 py-1 rounded text-xs font-semibold">Government</span>}
          {isGitHub && <span className="bg-[#9df] text-[#000] px-3 py-1 rounded text-xs font-semibold">GitHub</span>}
          {hasRiskTerms && <span className="bg-[#ff9500] text-[#000] px-3 py-1 rounded text-xs font-semibold">⚠️ Risk Terms</span>}
        </div>
      </div>

      {/* Content */}
      <div className="p-6 space-y-6">
        {/* URL & Links */}
        <Card className="bg-[#1b2332] border-[#334] p-6">
          <h3 className="text-lg font-semibold mb-4">URL & Quellen</h3>
          <div className="space-y-3">
            <div>
              <div className="text-[#9df] text-sm mb-2">Hauptlink</div>
              <div className="flex items-center gap-2 bg-[#0f0f15] p-3 rounded font-mono text-xs break-all">
                <span className="text-[#eef] flex-1">{link.url}</span>
                <Button
                  size="sm"
                  variant="ghost"
                  onClick={() => handleCopy(link.url)}
                  className="text-[#9df]"
                >
                  <Copy className="w-4 h-4" />
                </Button>
                <a href={link.url} target="_blank" rel="noopener noreferrer">
                  <Button size="sm" variant="ghost" className="text-[#9df]">
                    <ExternalLink className="w-4 h-4" />
                  </Button>
                </a>
              </div>
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div>
                <div className="text-[#9df] text-sm mb-1">Host</div>
                <div className="text-[#eef] font-mono text-sm">{link.host}</div>
              </div>
              <div>
                <div className="text-[#9df] text-sm mb-1">Typ</div>
                <div className="text-[#eef] font-mono text-sm">{link.kind}</div>
              </div>
            </div>
          </div>
        </Card>

        {/* Metadata */}
        <Card className="bg-[#1b2332] border-[#334] p-6">
          <h3 className="text-lg font-semibold mb-4">Metadaten</h3>
          <div className="grid grid-cols-2 md:grid-cols-3 gap-4 text-sm">
            <div className="bg-[#0f0f15] p-3 rounded">
              <div className="text-[#9df] text-xs">Pfad</div>
              <div className="text-[#eef] font-mono text-xs mt-1 break-all">{link.path}</div>
            </div>
            <div className="bg-[#0f0f15] p-3 rounded">
              <div className="text-[#9df] text-xs">Vorkommen</div>
              <div className="text-2xl font-bold text-[#9df] mt-1">{link.occurrences}</div>
            </div>
            <div className="bg-[#0f0f15] p-3 rounded">
              <div className="text-[#9df] text-xs">SHA256</div>
              <div className="text-[#eef] font-mono text-xs mt-1 break-all">{link.sha256.substring(0, 16)}...</div>
            </div>
          </div>
          <div className="mt-4">
            <div className="text-[#9df] text-sm mb-2">Vollständiger SHA256</div>
            <div className="bg-[#0f0f15] p-3 rounded font-mono text-xs text-[#eef] break-all">{link.sha256}</div>
          </div>
        </Card>

        {/* Analysis Status */}
        {analysis && (
          <Card className="bg-[#1b2332] border-[#334] p-6">
            <h3 className="text-lg font-semibold mb-4">Analyse-Status</h3>
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
              <div className="bg-[#0f0f15] p-3 rounded">
                <div className="text-[#9df] text-xs">Status</div>
                <div className={`text-lg font-bold mt-1 ${
                  analysis.status === "fertig" ? "text-[#00ff00]" :
                  analysis.status === "läuft" ? "text-[#ff9500]" :
                  analysis.status === "Fehler" ? "text-[#ff0000]" :
                  "text-[#666]"
                }`}>
                  {analysis.status}
                </div>
              </div>
              <div className="bg-[#0f0f15] p-3 rounded">
                <div className="text-[#9df] text-xs">Signaturen</div>
                <div className="text-2xl font-bold text-[#9df] mt-1">{analysis.signatureCount || 0}</div>
              </div>
              <div className="bg-[#0f0f15] p-3 rounded">
                <div className="text-[#9df] text-xs">Dateien</div>
                <div className="text-2xl font-bold text-[#9df] mt-1">{analysis.analyzedFiles || 0}</div>
              </div>
              <div className="bg-[#0f0f15] p-3 rounded">
                <div className="text-[#9df] text-xs">Imports</div>
                <div className="text-2xl font-bold text-[#9df] mt-1">{analysis.importCount || 0}</div>
              </div>
            </div>
          </Card>
        )}

        {/* Signatures by Type */}
        {Object.keys(sigsByType).length > 0 && (
          <Card className="bg-[#1b2332] border-[#334] p-6">
            <h3 className="text-lg font-semibold mb-4">Funktionssignaturen nach Typ</h3>
            <Tabs defaultValue={Object.keys(sigsByType)[0]} className="w-full">
              <TabsList className="bg-[#0f0f15] border-b border-[#334]">
                {Object.entries(sigsByType).map(([type, sigs]) => (
                  <TabsTrigger key={type} value={type} className="text-[#9df]">
                    {type} ({(sigs as any[]).length})
                  </TabsTrigger>
                ))}
              </TabsList>

              {Object.entries(sigsByType).map(([type, sigs]) => (
                <TabsContent key={type} value={type} className="space-y-2 mt-4">
                  {(sigs as any[]).map((sig, idx) => (
                    <div key={idx} className="bg-[#0f0f15] p-3 rounded font-mono text-xs">
                      <div className="text-[#9df]">{sig.name}({sig.params})</div>
                      <div className="text-[#666] text-xs mt-1">{sig.filePath}</div>
                    </div>
                  ))}
                </TabsContent>
              ))}
            </Tabs>
          </Card>
        )}

        {/* Risk Terms */}
        {hasRiskTerms && (
          <Card className="bg-[#2d1515] border-[#8b3333] p-6">
            <h3 className="text-lg font-semibold mb-4 text-[#ff6b6b]">⚠️ Potenzielle Sicherheitsrisiken</h3>
            <div className="space-y-2">
              {riskTerms.map((term: string, idx: number) => (
                <div key={idx} className="bg-[#1b0f0f] p-3 rounded text-[#ff9999] font-mono text-sm">
                  {term}
                </div>
              ))}
            </div>
            <p className="text-[#ff9999] text-xs mt-4">
              Diese Begriffe wurden in den Quellcode-Signaturen gefunden und könnten auf sicherheitskritische Funktionen hindeuten.
            </p>
          </Card>
        )}

        {/* AI Summary */}
        {analysis?.aiSummary && (
          <Card className="bg-[#1b2332] border-[#334] p-6">
            <h3 className="text-lg font-semibold mb-4">KI-Zusammenfassung</h3>
            <div className="bg-[#0f0f15] p-4 rounded text-[#eef] leading-relaxed">
              {analysis.aiSummary}
            </div>
          </Card>
        )}

        {/* Statistics */}
        <Card className="bg-[#1b2332] border-[#334] p-6">
          <h3 className="text-lg font-semibold mb-4">Statistiken</h3>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            <div className="bg-[#0f0f15] p-3 rounded text-center">
              <div className="text-[#9df] text-xs">Gesamt Signaturen</div>
              <div className="text-2xl font-bold mt-2">{signatures.length}</div>
            </div>
            <div className="bg-[#0f0f15] p-3 rounded text-center">
              <div className="text-[#9df] text-xs">Typen</div>
              <div className="text-2xl font-bold mt-2">{Object.keys(sigsByType).length}</div>
            </div>
            <div className="bg-[#0f0f15] p-3 rounded text-center">
              <div className="text-[#9df] text-xs">Dateien</div>
              <div className="text-2xl font-bold mt-2">{new Set(signatures.map((s: any) => s.filePath)).size}</div>
            </div>
            <div className="bg-[#0f0f15] p-3 rounded text-center">
              <div className="text-[#9df] text-xs">Risk-Terms</div>
              <div className="text-2xl font-bold mt-2 text-[#ff6b6b]">{riskTerms.length}</div>
            </div>
          </div>
        </Card>

        {/* Action Buttons */}
        <div className="flex gap-3 flex-wrap">
          <Button
            onClick={() => window.location.href = `/signatures/${linkIdNum}`}
            className="bg-[#9df] text-[#000] hover:bg-[#7bc]"
          >
            Zum Signatur-Viewer
          </Button>
          <Button
            onClick={() => window.location.href = `/analytics`}
            className="bg-[#1b2332] border border-[#334] text-[#9df] hover:bg-[#252d3d]"
          >
            Analytics anzeigen
          </Button>
        </div>

        {copied && (
          <div className="fixed bottom-6 right-6 bg-[#00ff00] text-[#000] px-4 py-2 rounded font-semibold">
            ✓ Kopiert!
          </div>
        )}
      </div>
    </div>
  );
}
