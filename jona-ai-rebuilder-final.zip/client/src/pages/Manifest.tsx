import { useState } from "react";
import { trpc } from "@/lib/trpc";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Loader2, ChevronLeft } from "lucide-react";
import { useLocation } from "wouter";

export default function Manifest() {
  const [, setLocation] = useLocation();
  const [linkSkip, setLinkSkip] = useState(0);
  const [auditSkip, setAuditSkip] = useState(0);
  const take = 50;

  const { data: links, isLoading: linksLoading } = trpc.analysis.getLinkManifest.useQuery({
    skip: linkSkip,
    take,
  });

  const { data: auditLines, isLoading: auditLoading } = trpc.analysis.getAuditLines.useQuery({
    skip: auditSkip,
    take,
  });

  return (
    <div className="min-h-screen bg-[#10141d] text-[#eef]">
      {/* Header */}
      <div className="border-b border-[#334] bg-[#0f0f15] p-6">
        <div className="flex items-center gap-4 mb-4">
          <Button
            variant="ghost"
            onClick={() => setLocation("/dashboard")}
            className="text-[#9df] hover:bg-[#1b2332]"
          >
            <ChevronLeft className="w-4 h-4" />
          </Button>
          <h1 className="text-2xl font-bold">Manifest & Audit</h1>
        </div>
        <p className="text-[#9df] text-sm">Alle 118 Links und 126 Quellzeilen mit vollständigen Metadaten</p>
      </div>

      {/* Tabs */}
      <div className="p-6">
        <Tabs defaultValue="manifest" className="w-full">
          <TabsList className="bg-[#1b2332] border-b border-[#334]">
            <TabsTrigger value="manifest" className="text-[#9df]">Link-Manifest (118)</TabsTrigger>
            <TabsTrigger value="audit" className="text-[#9df]">Quellzeilen-Audit (126)</TabsTrigger>
          </TabsList>

          {/* Link Manifest */}
          <TabsContent value="manifest" className="space-y-4 mt-4">
            <Card className="bg-[#1b2332] border-[#334] overflow-hidden">
              {linksLoading ? (
                <div className="flex items-center justify-center p-8">
                  <Loader2 className="w-6 h-6 animate-spin text-[#9df]" />
                </div>
              ) : (
                <div className="overflow-x-auto">
                  <table className="w-full text-sm">
                    <thead className="bg-[#0f0f15] border-b border-[#334]">
                      <tr>
                        <th className="px-4 py-3 text-left font-semibold text-[#9df]">ID</th>
                        <th className="px-4 py-3 text-left font-semibold text-[#9df]">Host</th>
                        <th className="px-4 py-3 text-left font-semibold text-[#9df]">Typ</th>
                        <th className="px-4 py-3 text-left font-semibold text-[#9df]">Pfad</th>
                        <th className="px-4 py-3 text-left font-semibold text-[#9df]">SHA256</th>
                        <th className="px-4 py-3 text-left font-semibold text-[#9df]">Vorkommen</th>
                      </tr>
                    </thead>
                    <tbody>
                      {links?.map((link) => (
                        <tr key={link.id} className="border-b border-[#334] hover:bg-[#252d3d]">
                          <td className="px-4 py-3 font-mono text-[#9df]">#{link.id}</td>
                          <td className="px-4 py-3 text-[#eef]">{link.host}</td>
                          <td className="px-4 py-3 text-[#eef] text-xs">{link.kind}</td>
                          <td className="px-4 py-3 text-[#9df] font-mono text-xs truncate max-w-[200px]">{link.path}</td>
                          <td className="px-4 py-3 text-[#9df] font-mono text-xs truncate max-w-[150px]">{link.sha256}</td>
                          <td className="px-4 py-3 text-[#eef]">{link.occurrences}</td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              )}
            </Card>

            {/* Pagination */}
            <div className="flex justify-between items-center">
              <div className="text-sm text-[#9df]">
                Zeige {linkSkip + 1} bis {Math.min(linkSkip + take, (links?.length || 0) + linkSkip)}
              </div>
              <div className="flex gap-2">
                <Button
                  variant="outline"
                  disabled={linkSkip === 0}
                  onClick={() => setLinkSkip(Math.max(0, linkSkip - take))}
                  className="bg-[#1b2332] border-[#334] text-[#9df]"
                >
                  Zurück
                </Button>
                <Button
                  variant="outline"
                  onClick={() => setLinkSkip(linkSkip + take)}
                  className="bg-[#1b2332] border-[#334] text-[#9df]"
                >
                  Weiter
                </Button>
              </div>
            </div>
          </TabsContent>

          {/* Audit Lines */}
          <TabsContent value="audit" className="space-y-4 mt-4">
            <Card className="bg-[#1b2332] border-[#334] overflow-hidden">
              {auditLoading ? (
                <div className="flex items-center justify-center p-8">
                  <Loader2 className="w-6 h-6 animate-spin text-[#9df]" />
                </div>
              ) : (
                <div className="overflow-x-auto">
                  <table className="w-full text-sm">
                    <thead className="bg-[#0f0f15] border-b border-[#334]">
                      <tr>
                        <th className="px-4 py-3 text-left font-semibold text-[#9df]">Zeile</th>
                        <th className="px-4 py-3 text-left font-semibold text-[#9df]">Text</th>
                        <th className="px-4 py-3 text-left font-semibold text-[#9df]">SHA256</th>
                        <th className="px-4 py-3 text-left font-semibold text-[#9df]">URLs</th>
                      </tr>
                    </thead>
                    <tbody>
                      {auditLines?.map((line) => (
                        <tr key={line.id} className="border-b border-[#334] hover:bg-[#252d3d]">
                          <td className="px-4 py-3 font-mono text-[#9df]">{line.id}</td>
                          <td className="px-4 py-3 text-[#eef] font-mono text-xs truncate max-w-[300px]">{line.text}</td>
                          <td className="px-4 py-3 text-[#9df] font-mono text-xs truncate max-w-[150px]">{line.sha256}</td>
                          <td className="px-4 py-3 text-[#eef]">{line.urlCount}</td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              )}
            </Card>

            {/* Pagination */}
            <div className="flex justify-between items-center">
              <div className="text-sm text-[#9df]">
                Zeige {auditSkip + 1} bis {Math.min(auditSkip + take, (auditLines?.length || 0) + auditSkip)}
              </div>
              <div className="flex gap-2">
                <Button
                  variant="outline"
                  disabled={auditSkip === 0}
                  onClick={() => setAuditSkip(Math.max(0, auditSkip - take))}
                  className="bg-[#1b2332] border-[#334] text-[#9df]"
                >
                  Zurück
                </Button>
                <Button
                  variant="outline"
                  onClick={() => setAuditSkip(auditSkip + take)}
                  className="bg-[#1b2332] border-[#334] text-[#9df]"
                >
                  Weiter
                </Button>
              </div>
            </div>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
}
