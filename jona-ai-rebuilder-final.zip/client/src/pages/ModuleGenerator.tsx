import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { ChevronLeft, Copy, Download, Zap } from "lucide-react";
import { useLocation } from "wouter";

const SAMPLE_SIGNATURES = [
  { name: "analyze_data", type: "python_function", params: "dataset" },
  { name: "process_file", type: "python_function", params: "filepath" },
  { name: "DataProcessor", type: "python_class", params: "" },
  { name: "extract_features", type: "python_function", params: "data, config" },
  { name: "validate_input", type: "python_function", params: "input_data" },
];

const generateModuleCode = (linkId: number, signatures: any[]) => {
  const lines: string[] = [
    '"""Generated safe module. It is function-equivalent scaffolding derived from signatures/structures, not copied source."""',
    "from typing import Any, Dict, List",
    "",
    "",
  ];

  const seen = new Set<string>();
  
  for (const sig of signatures.slice(0, 50)) {
    let name = sig.name.replace(/\W+/g, "_");
    if (name.startsWith("_")) name = "fn" + name;
    
    if (seen.has(name)) continue;
    seen.add(name);
    
    lines.push(`def ${name}(*args: Any, **kwargs: Any) -> Dict[str, Any]:`);
    lines.push(`    """Safe rebuilt placeholder for discovered ${sig.type}."""`);
    lines.push(`    return {"ok": True, "function": "${name}", "args_count": len(args), "kwargs": sorted(kwargs.keys())}`);
    lines.push("");
  }
  
  if (lines.length <= 4) {
    lines.push("def analyze_source(*args: Any, **kwargs: Any) -> Dict[str, Any]:");
    lines.push('    """Default safe placeholder."""');
    lines.push('    return {"ok": True, "function": "analyze_source"}');
  }
  
  return lines.join("\n");
};

export default function ModuleGenerator() {
  const [, setLocation] = useLocation();
  const [signatures, setSignatures] = useState(SAMPLE_SIGNATURES);
  const [linkId, setLinkId] = useState(1);
  const [generatedCode, setGeneratedCode] = useState("");
  const [copied, setCopied] = useState(false);

  const handleGenerate = () => {
    const code = generateModuleCode(linkId, signatures);
    setGeneratedCode(code);
  };

  const handleCopy = () => {
    navigator.clipboard.writeText(generatedCode);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const handleDownload = () => {
    const blob = new Blob([generatedCode], { type: "text/plain" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = `module_link_${linkId}.py`;
    a.click();
  };

  const addSignature = () => {
    setSignatures([
      ...signatures,
      { name: "new_function", type: "python_function", params: "" },
    ]);
  };

  const removeSignature = (idx: number) => {
    setSignatures(signatures.filter((_, i) => i !== idx));
  };

  const updateSignature = (idx: number, field: string, value: string) => {
    const updated = [...signatures];
    (updated[idx] as any)[field] = value;
    setSignatures(updated);
  };

  return (
    <div className="min-h-screen bg-[#10141d] text-[#eef]">
      {/* Header */}
      <div className="border-b border-[#334] bg-[#0f0f15] p-6">
        <div className="flex items-center gap-4 mb-4">
          <Button
            variant="ghost"
            onClick={() => setLocation("/dashboard")}
            className="text-[#9df] hover:bg-[#1b2332]"
          >
            <ChevronLeft className="w-4 h-4" />
          </Button>
          <h1 className="text-2xl font-bold">Modul-Generator</h1>
        </div>
        <p className="text-[#9df] text-sm">Generiere sichere Python-Module aus Funktionssignaturen</p>
      </div>

      {/* Content */}
      <div className="p-6 grid grid-cols-2 gap-6">
        {/* Input Panel */}
        <div className="space-y-4">
          <Card className="bg-[#1b2332] border-[#334] p-6">
            <h3 className="text-lg font-semibold mb-4">Konfiguration</h3>
            
            <div className="mb-4">
              <label className="text-[#9df] text-sm block mb-2">Link-ID</label>
              <input
                type="number"
                value={linkId}
                onChange={(e) => setLinkId(parseInt(e.target.value))}
                className="w-full bg-[#0f0f15] border border-[#334] text-[#eef] p-2 rounded text-sm"
              />
            </div>

            <Button
              onClick={handleGenerate}
              className="w-full bg-[#00ff00] text-[#000] hover:bg-[#00cc00] mb-4"
            >
              <Zap className="w-4 h-4 mr-2" />
              Modul generieren
            </Button>
          </Card>

          <Card className="bg-[#1b2332] border-[#334] p-6">
            <h3 className="text-lg font-semibold mb-4">Signaturen ({signatures.length})</h3>
            
            <div className="space-y-3 max-h-[400px] overflow-y-auto">
              {signatures.map((sig, idx) => (
                <div key={idx} className="bg-[#0f0f15] p-3 rounded space-y-2">
                  <div className="flex gap-2">
                    <input
                      type="text"
                      value={sig.name}
                      onChange={(e) => updateSignature(idx, "name", e.target.value)}
                      placeholder="Funktionsname"
                      className="flex-1 bg-[#1b2332] border border-[#334] text-[#eef] p-1 rounded text-xs"
                    />
                    <Button
                      onClick={() => removeSignature(idx)}
                      variant="ghost"
                      className="text-[#ff6b6b] hover:bg-[#2d1515]"
                      size="sm"
                    >
                      ✕
                    </Button>
                  </div>
                  <div className="flex gap-2">
                    <select
                      value={sig.type}
                      onChange={(e) => updateSignature(idx, "type", e.target.value)}
                      className="flex-1 bg-[#1b2332] border border-[#334] text-[#eef] p-1 rounded text-xs"
                    >
                      <option>python_function</option>
                      <option>python_class</option>
                      <option>js_function</option>
                      <option>java_method</option>
                    </select>
                  </div>
                  <input
                    type="text"
                    value={sig.params}
                    onChange={(e) => updateSignature(idx, "params", e.target.value)}
                    placeholder="Parameter"
                    className="w-full bg-[#1b2332] border border-[#334] text-[#eef] p-1 rounded text-xs"
                  />
                </div>
              ))}
            </div>

            <Button
              onClick={addSignature}
              variant="outline"
              className="w-full mt-3 border-[#334] text-[#9df]"
            >
              + Signatur hinzufügen
            </Button>
          </Card>
        </div>

        {/* Output Panel */}
        <div className="space-y-4">
          <Card className="bg-[#1b2332] border-[#334] p-6">
            <div className="flex justify-between items-center mb-4">
              <h3 className="text-lg font-semibold">Generiertes Modul</h3>
              <div className="flex gap-2">
                <Button
                  onClick={handleCopy}
                  disabled={!generatedCode}
                  className="bg-[#9df] text-[#000] hover:bg-[#7bc]"
                  size="sm"
                >
                  <Copy className="w-4 h-4" />
                </Button>
                <Button
                  onClick={handleDownload}
                  disabled={!generatedCode}
                  className="bg-[#1b2332] border border-[#334] text-[#9df]"
                  size="sm"
                >
                  <Download className="w-4 h-4" />
                </Button>
              </div>
            </div>

            {generatedCode ? (
              <div className="bg-[#0f0f15] p-4 rounded font-mono text-xs overflow-auto max-h-[600px]">
                <div className="space-y-0">
                  {generatedCode.split("\n").map((line, idx) => (
                    <div key={idx} className="flex">
                      <div className="text-[#666] w-8 text-right pr-3 select-none">{idx + 1}</div>
                      <div className="text-[#9df] flex-1 whitespace-pre-wrap break-words">{line}</div>
                    </div>
                  ))}
                </div>
              </div>
            ) : (
              <div className="bg-[#0f0f15] p-4 rounded text-[#666] text-center py-12">
                Klicke auf "Modul generieren" um Code zu erzeugen
              </div>
            )}
          </Card>

          {/* Info */}
          <Card className="bg-[#1b3a2d] border-[#336b5a] p-4">
            <h4 className="text-[#9df] font-semibold text-sm mb-2">ℹ️ Über generierte Module</h4>
            <p className="text-[#9df] text-xs leading-relaxed">
              Die generierten Module sind sichere Platzhalter-Implementierungen, die auf den erkannten 
              Funktionssignaturen basieren. Sie sind nicht kopiert, sondern funktionsäquivalent und 
              können als Basis für eigene Implementierungen verwendet werden.
            </p>
          </Card>
        </div>
      </div>

      {copied && (
        <div className="fixed bottom-6 right-6 bg-[#00ff00] text-[#000] px-4 py-2 rounded font-semibold">
          ✓ Kopiert!
        </div>
      )}
    </div>
  );
}
