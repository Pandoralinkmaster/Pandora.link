import { useState } from "react";
import { trpc } from "@/lib/trpc";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Loader2, ChevronLeft, Download } from "lucide-react";
import { useLocation } from "wouter";

export default function Modules() {
  const [, setLocation] = useLocation();
  const [selectedModule, setSelectedModule] = useState<number | null>(null);

  const handleDownload = async (moduleId: number) => {
    try {
      const module = await fetch(`/api/trpc/analysis.getGeneratedModule?input=${JSON.stringify({ moduleId })}`)
        .then(r => r.json())
        .then(r => r.result?.data);
      if (module?.content) {
        const blob = new Blob([module.content], { type: "text/plain" });
        const url = URL.createObjectURL(blob);
        const a = document.createElement("a");
        a.href = url;
        a.download = module.modulePath;
        document.body.appendChild(a);
        a.click();
        document.body.removeChild(a);
        URL.revokeObjectURL(url);
      }
    } catch (error) {
      console.error("Download failed:", error);
    }
  };

  return (
    <div className="min-h-screen bg-[#10141d] text-[#eef]">
      {/* Header */}
      <div className="border-b border-[#334] bg-[#0f0f15] p-6">
        <div className="flex items-center gap-4 mb-4">
          <Button
            variant="ghost"
            onClick={() => setLocation("/dashboard")}
            className="text-[#9df] hover:bg-[#1b2332]"
          >
            <ChevronLeft className="w-4 h-4" />
          </Button>
          <h1 className="text-2xl font-bold">Generierte Module</h1>
        </div>
        <p className="text-[#9df] text-sm">Sichere Python-Module aus Funktionssignaturen</p>
      </div>

      {/* Content */}
      <div className="p-6">
        <Card className="bg-[#1b2332] border-[#334] p-6">
          <p className="text-[#9df] text-center py-8">Module werden nach Analyse-Abschluss generiert</p>
        </Card>
      </div>
    </div>
  );
}
