import { useState } from "react";
import { trpc } from "@/lib/trpc";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Loader2, ChevronLeft, Download, Eye } from "lucide-react";
import { useLocation } from "wouter";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";

export default function Reports() {
  const [, setLocation] = useLocation();
  const [selectedReport, setSelectedReport] = useState<any | null>(null);
  const [search, setSearch] = useState("");
  const [skip, setSkip] = useState(0);
  const take = 50;

  const { data: analyses, isLoading } = trpc.analysis.listLinks.useQuery({
    skip,
    take,
    search: search || undefined,
  });

  const reportsWithData = (analyses || []).filter((link: any) => link.reportPath);

  const handleDownload = (analysis: any) => {
    if (!analysis.reportPath) return;
    
    const reportData = {
      linkId: analysis.id,
      status: analysis.status,
      analysisType: analysis.analysisType,
      totalFiles: analysis.totalFiles,
      selectedCodeFiles: analysis.selectedCodeFiles,
      analyzedFiles: analysis.analyzedFiles,
      signatureCount: analysis.signatureCount,
      importCount: analysis.importCount,
      riskTermsFound: analysis.riskTermsFound,
      aiSummary: analysis.aiSummary,
      completedAt: analysis.completedAt,
    };

    const blob = new Blob([JSON.stringify(reportData, null, 2)], { type: "application/json" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = `report_link_${analysis.id}.json`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
  };

  return (
    <div className="min-h-screen bg-[#10141d] text-[#eef]">
      {/* Header */}
      <div className="border-b border-[#334] bg-[#0f0f15] p-6">
        <div className="flex items-center gap-4 mb-4">
          <Button
            variant="ghost"
            onClick={() => setLocation("/dashboard")}
            className="text-[#9df] hover:bg-[#1b2332]"
          >
            <ChevronLeft className="w-4 h-4" />
          </Button>
          <h1 className="text-2xl font-bold">Analyse-Berichte</h1>
        </div>
        <p className="text-[#9df] text-sm">JSON-Reports aller abgeschlossenen Analysen</p>
      </div>

      {/* Search */}
      <div className="px-6 py-4">
        <Input
          placeholder="Nach Link-ID oder URL suchen..."
          value={search}
          onChange={(e) => {
            setSearch(e.target.value);
            setSkip(0);
          }}
          className="bg-[#1b2332] border-[#334] text-[#eef]"
        />
      </div>

      {/* Reports Table */}
      <div className="px-6 pb-6">
        <Card className="bg-[#1b2332] border-[#334] overflow-hidden">
          {isLoading ? (
            <div className="flex items-center justify-center p-8">
              <Loader2 className="w-6 h-6 animate-spin text-[#9df]" />
            </div>
          ) : reportsWithData.length === 0 ? (
            <div className="p-8 text-center text-[#9df]">
              Keine Berichte vorhanden. Führe zunächst Analysen durch.
            </div>
          ) : (
            <div className="overflow-x-auto">
              <table className="w-full text-sm">
                <thead className="bg-[#0f0f15] border-b border-[#334]">
                  <tr>
                    <th className="px-4 py-3 text-left font-semibold text-[#9df]">Link-ID</th>
                    <th className="px-4 py-3 text-left font-semibold text-[#9df]">Status</th>
                    <th className="px-4 py-3 text-left font-semibold text-[#9df]">Signaturen</th>
                    <th className="px-4 py-3 text-left font-semibold text-[#9df]">Dateien</th>
                    <th className="px-4 py-3 text-left font-semibold text-[#9df]">Abgeschlossen</th>
                    <th className="px-4 py-3 text-center font-semibold text-[#9df]">Aktionen</th>
                  </tr>
                </thead>
                <tbody>
                  {reportsWithData.map((analysis: any) => (
                    <tr key={analysis.id} className="border-b border-[#334] hover:bg-[#252d3d]">
                      <td className="px-4 py-3 text-[#eef] font-mono">#{analysis.id}</td>
                      <td className="px-4 py-3 text-[#9df]">{analysis.status}</td>
                      <td className="px-4 py-3 text-[#eef]">{analysis.signatureCount || 0}</td>
                      <td className="px-4 py-3 text-[#eef]">{analysis.analyzedFiles || 0}</td>
                      <td className="px-4 py-3 text-[#9df] text-xs">
                        {analysis.completedAt ? new Date(analysis.completedAt).toLocaleDateString("de-DE") : "-"}
                      </td>
                      <td className="px-4 py-3 text-center space-x-2">
                        <Button
                          size="sm"
                          variant="outline"
                          className="bg-[#0f0f15] border-[#334] text-[#9df]"
                          onClick={() => setSelectedReport(analysis)}
                        >
                          <Eye className="w-4 h-4" />
                        </Button>
                        <Button
                          size="sm"
                          variant="outline"
                          className="bg-[#0f0f15] border-[#334] text-[#9df]"
                          onClick={() => handleDownload(analysis)}
                        >
                          <Download className="w-4 h-4" />
                        </Button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </Card>

        {/* Pagination */}
        {reportsWithData.length > 0 && (
          <div className="flex justify-between items-center mt-4">
            <div className="text-sm text-[#9df]">
              Zeige {skip + 1} bis {Math.min(skip + take, reportsWithData.length + skip)}
            </div>
            <div className="flex gap-2">
              <Button
                variant="outline"
                disabled={skip === 0}
                onClick={() => setSkip(Math.max(0, skip - take))}
                className="bg-[#1b2332] border-[#334] text-[#9df]"
              >
                Zurück
              </Button>
              <Button
                variant="outline"
                onClick={() => setSkip(skip + take)}
                className="bg-[#1b2332] border-[#334] text-[#9df]"
              >
                Weiter
              </Button>
            </div>
          </div>
        )}
      </div>

      {/* Report Viewer Modal */}
      {selectedReport && (
        <Dialog open={!!selectedReport} onOpenChange={() => setSelectedReport(null)}>
          <DialogContent className="bg-[#1b2332] border-[#334] max-w-2xl max-h-[80vh] overflow-y-auto">
            <DialogHeader>
              <DialogTitle className="text-[#eef]">Bericht - Link #{selectedReport.id}</DialogTitle>
            </DialogHeader>
            <div className="space-y-4">
              <div className="bg-[#0f0f15] p-4 rounded font-mono text-xs text-[#9df] overflow-auto">
                <pre>{JSON.stringify({
                  linkId: selectedReport.id,
                  status: selectedReport.status,
                  analysisType: selectedReport.analysisType,
                  totalFiles: selectedReport.totalFiles,
                  selectedCodeFiles: selectedReport.selectedCodeFiles,
                  analyzedFiles: selectedReport.analyzedFiles,
                  signatureCount: selectedReport.signatureCount,
                  importCount: selectedReport.importCount,
                  riskTermsFound: selectedReport.riskTermsFound,
                  aiSummary: selectedReport.aiSummary,
                  completedAt: selectedReport.completedAt,
                }, null, 2)}</pre>
              </div>
              <Button
                onClick={() => handleDownload(selectedReport)}
                className="w-full bg-[#00ff00] text-[#000] hover:bg-[#00cc00]"
              >
                <Download className="w-4 h-4 mr-2" />
                Als JSON herunterladen
              </Button>
            </div>
          </DialogContent>
        </Dialog>
      )}
    </div>
  );
}
