import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { ChevronLeft, Save, RotateCcw } from "lucide-react";
import { useLocation } from "wouter";
import { useAuth } from "@/_core/hooks/useAuth";

export default function Settings() {
  const [, setLocation] = useLocation();
  const { user } = useAuth();
  const [settings, setSettings] = useState({
    analysisTimeout: 300,
    maxFilesPerAnalysis: 400,
    enableAutoAnalysis: false,
    notifyOnCompletion: true,
    exportFormat: "json",
  });
  const [saved, setSaved] = useState(false);

  const handleSave = () => {
    localStorage.setItem("app_settings", JSON.stringify(settings));
    setSaved(true);
    setTimeout(() => setSaved(false), 3000);
  };

  const handleReset = () => {
    setSettings({
      analysisTimeout: 300,
      maxFilesPerAnalysis: 400,
      enableAutoAnalysis: false,
      notifyOnCompletion: true,
      exportFormat: "json",
    });
  };

  return (
    <div className="min-h-screen bg-[#10141d] text-[#eef]">
      {/* Header */}
      <div className="border-b border-[#334] bg-[#0f0f15] p-6">
        <div className="flex items-center gap-4 mb-4">
          <Button
            variant="ghost"
            onClick={() => setLocation("/dashboard")}
            className="text-[#9df] hover:bg-[#1b2332]"
          >
            <ChevronLeft className="w-4 h-4" />
          </Button>
          <h1 className="text-2xl font-bold">Einstellungen</h1>
        </div>
        <p className="text-[#9df] text-sm">Konfiguriere Analyse-Parameter und Verhalten</p>
      </div>

      {/* Content */}
      <div className="p-6 max-w-2xl mx-auto space-y-6">
        {/* User Info */}
        <Card className="bg-[#1b2332] border-[#334] p-6">
          <h3 className="text-lg font-semibold mb-4">Benutzer-Informationen</h3>
          <div className="space-y-3 text-sm">
            <div>
              <div className="text-[#9df]">Name</div>
              <div className="text-[#eef] mt-1">{user?.name || "Nicht gesetzt"}</div>
            </div>
            <div>
              <div className="text-[#9df]">E-Mail</div>
              <div className="text-[#eef] font-mono mt-1">{user?.email || "Nicht gesetzt"}</div>
            </div>
            <div>
              <div className="text-[#9df]">Rolle</div>
              <div className="text-[#eef] mt-1">{user?.role || "user"}</div>
            </div>
          </div>
        </Card>

        {/* Analysis Settings */}
        <Card className="bg-[#1b2332] border-[#334] p-6">
          <h3 className="text-lg font-semibold mb-4">Analyse-Einstellungen</h3>
          <div className="space-y-4">
            <div>
              <label className="text-[#9df] text-sm block mb-2">Analyse-Timeout (Sekunden)</label>
              <Input
                type="number"
                value={settings.analysisTimeout}
                onChange={(e) => setSettings({ ...settings, analysisTimeout: parseInt(e.target.value) })}
                className="bg-[#0f0f15] border-[#334] text-[#eef]"
              />
              <p className="text-[#666] text-xs mt-1">Maximale Zeit pro Link-Analyse</p>
            </div>

            <div>
              <label className="text-[#9df] text-sm block mb-2">Max. Dateien pro Analyse</label>
              <Input
                type="number"
                value={settings.maxFilesPerAnalysis}
                onChange={(e) => setSettings({ ...settings, maxFilesPerAnalysis: parseInt(e.target.value) })}
                className="bg-[#0f0f15] border-[#334] text-[#eef]"
              />
              <p className="text-[#666] text-xs mt-1">Maximale Anzahl zu analysierender Dateien</p>
            </div>

            <div className="flex items-center gap-3">
              <input
                type="checkbox"
                checked={settings.enableAutoAnalysis}
                onChange={(e) => setSettings({ ...settings, enableAutoAnalysis: e.target.checked })}
                className="w-4 h-4 rounded bg-[#0f0f15] border-[#334]"
              />
              <label className="text-[#9df] text-sm">Auto-Analyse beim Hinzufügen aktivieren</label>
            </div>

            <div className="flex items-center gap-3">
              <input
                type="checkbox"
                checked={settings.notifyOnCompletion}
                onChange={(e) => setSettings({ ...settings, notifyOnCompletion: e.target.checked })}
                className="w-4 h-4 rounded bg-[#0f0f15] border-[#334]"
              />
              <label className="text-[#9df] text-sm">Benachrichtigung bei Abschluss</label>
            </div>
          </div>
        </Card>

        {/* Export Settings */}
        <Card className="bg-[#1b2332] border-[#334] p-6">
          <h3 className="text-lg font-semibold mb-4">Export-Format</h3>
          <div className="space-y-2">
            {["json", "csv", "xml"].map((format) => (
              <div key={format} className="flex items-center gap-3">
                <input
                  type="radio"
                  name="exportFormat"
                  value={format}
                  checked={settings.exportFormat === format}
                  onChange={(e) => setSettings({ ...settings, exportFormat: e.target.value })}
                  className="w-4 h-4"
                />
                <label className="text-[#9df] text-sm uppercase">{format}</label>
              </div>
            ))}
          </div>
        </Card>

        {/* Actions */}
        <div className="flex gap-3">
          <Button
            onClick={handleSave}
            className="flex-1 bg-[#00ff00] text-[#000] hover:bg-[#00cc00]"
          >
            <Save className="w-4 h-4 mr-2" />
            Speichern
          </Button>
          <Button
            onClick={handleReset}
            variant="outline"
            className="flex-1 border-[#334] text-[#9df]"
          >
            <RotateCcw className="w-4 h-4 mr-2" />
            Zurücksetzen
          </Button>
        </div>

        {saved && (
          <div className="bg-[#00ff00] text-[#000] p-3 rounded font-semibold text-center">
            ✓ Einstellungen gespeichert
          </div>
        )}

        {/* About */}
        <Card className="bg-[#1b2332] border-[#334] p-6">
          <h3 className="text-lg font-semibold mb-4">Über diese Anwendung</h3>
          <div className="space-y-2 text-sm text-[#9df]">
            <p><strong>Name:</strong> JonaAI Link-Code Rebuilder</p>
            <p><strong>Version:</strong> 1.0.0</p>
            <p><strong>Erstellt:</strong> Juni 2026</p>
            <p><strong>Status:</strong> Produktionsbereit</p>
            <p className="mt-4 text-[#666]">
              Eine umfassende webbasierte Analyse-Plattform für 118 Links mit automatischer 
              Funktionssignatur-Extraktion, GitHub-Crawling und KI-Zusammenfassungen.
            </p>
          </div>
        </Card>
      </div>
    </div>
  );
}
