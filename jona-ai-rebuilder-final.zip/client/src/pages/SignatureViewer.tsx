import { useState } from "react";
import { useParams } from "wouter";
import { trpc } from "@/lib/trpc";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Loader2, ChevronLeft, Copy, Download } from "lucide-react";
import { useLocation } from "wouter";

export default function SignatureViewer() {
  const { linkId } = useParams<{ linkId: string }>();
  const [, setLocation] = useLocation();
  const linkIdNum = parseInt(linkId || "0");

  const { data: linkData, isLoading } = trpc.analysis.getLink.useQuery({ linkId: linkIdNum });
  const [copied, setCopied] = useState(false);

  if (isLoading) {
    return (
      <div className="min-h-screen bg-[#10141d] flex items-center justify-center">
        <Loader2 className="w-8 h-8 animate-spin text-[#9df]" />
      </div>
    );
  }

  if (!linkData) {
    return (
      <div className="min-h-screen bg-[#10141d] text-[#eef] p-6">
        <div>Link nicht gefunden</div>
      </div>
    );
  }

  const { link, analysis, signatures } = linkData;

  const groupedSignatures = signatures.reduce((acc: Record<string, any[]>, sig: any) => {
    if (!acc[sig.signatureType]) {
      acc[sig.signatureType] = [];
    }
    acc[sig.signatureType].push(sig);
    return acc;
  }, {});

  const riskTerms = analysis?.riskTermsFound ? JSON.parse(analysis.riskTermsFound) : [];

  const handleCopy = (text: string) => {
    navigator.clipboard.writeText(text);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const handleExport = () => {
    const exportData = {
      link: {
        id: link.id,
        url: link.url,
        host: link.host,
        kind: link.kind,
      },
      analysis: {
        status: analysis?.status,
        totalFiles: analysis?.totalFiles,
        analyzedFiles: analysis?.analyzedFiles,
        signatureCount: analysis?.signatureCount,
      },
      signatures: signatures.map((s: any) => ({
        type: s.signatureType,
        name: s.name,
        params: s.params,
        file: s.filePath,
      })),
      riskTerms,
      exportedAt: new Date().toISOString(),
    };

    const blob = new Blob([JSON.stringify(exportData, null, 2)], { type: "application/json" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = `signatures_link_${link.id}.json`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
  };

  return (
    <div className="min-h-screen bg-[#10141d] text-[#eef]">
      {/* Header */}
      <div className="border-b border-[#334] bg-[#0f0f15] p-6">
        <div className="flex items-center gap-4 mb-4">
          <Button
            variant="ghost"
            onClick={() => setLocation(`/link/${linkIdNum}`)}
            className="text-[#9df] hover:bg-[#1b2332]"
          >
            <ChevronLeft className="w-4 h-4" />
          </Button>
          <h1 className="text-2xl font-bold">Signatur-Viewer</h1>
        </div>
        <p className="text-[#9df] text-sm">Link #{link.id} - {link.host}</p>
      </div>

      {/* Content */}
      <div className="p-6 space-y-6">
        {/* Export Button */}
        <div className="flex gap-2">
          <Button
            onClick={handleExport}
            className="bg-[#00ff00] text-[#000] hover:bg-[#00cc00]"
          >
            <Download className="w-4 h-4 mr-2" />
            Exportieren als JSON
          </Button>
        </div>

        {/* Tabs */}
        <Tabs defaultValue="all" className="w-full">
          <TabsList className="bg-[#1b2332] border-b border-[#334]">
            <TabsTrigger value="all" className="text-[#9df]">
              Alle ({signatures.length})
            </TabsTrigger>
            {Object.entries(groupedSignatures).map(([type, sigs]) => (
              <TabsTrigger key={type} value={type} className="text-[#9df]">
                {type} ({sigs.length})
              </TabsTrigger>
            ))}
            {riskTerms.length > 0 && (
              <TabsTrigger value="risk" className="text-[#ff6b6b]">
                Risk ({riskTerms.length})
              </TabsTrigger>
            )}
          </TabsList>

          {/* All Signatures */}
          <TabsContent value="all" className="space-y-3 mt-4">
            {signatures.length === 0 ? (
              <Card className="bg-[#1b2332] border-[#334] p-4">
                <p className="text-[#9df]">Keine Signaturen gefunden</p>
              </Card>
            ) : (
              signatures.map((sig: any, idx: number) => (
                <Card key={idx} className="bg-[#1b2332] border-[#334] p-4">
                  <div className="flex justify-between items-start mb-2">
                    <div>
                      <div className="text-[#9df] text-xs font-semibold">{sig.signatureType}</div>
                      <div className="text-[#eef] font-mono text-sm mt-1">
                        {sig.name}({sig.params})
                      </div>
                    </div>
                    <Button
                      size="sm"
                      variant="ghost"
                      onClick={() => handleCopy(`${sig.name}(${sig.params})`)}
                      className="text-[#9df] hover:bg-[#0f0f15]"
                    >
                      <Copy className="w-4 h-4" />
                    </Button>
                  </div>
                  <div className="text-[#666] text-xs">{sig.filePath}</div>
                </Card>
              ))
            )}
          </TabsContent>

          {/* By Type */}
          {Object.entries(groupedSignatures).map(([type, sigs]) => (
            <TabsContent key={type} value={type} className="space-y-3 mt-4">
              {(sigs as any[]).map((sig, idx) => (
                <Card key={idx} className="bg-[#1b2332] border-[#334] p-4">
                  <div className="flex justify-between items-start">
                    <div>
                      <div className="text-[#eef] font-mono text-sm">
                        {sig.name}({sig.params})
                      </div>
                      <div className="text-[#666] text-xs mt-1">{sig.filePath}</div>
                    </div>
                    <Button
                      size="sm"
                      variant="ghost"
                      onClick={() => handleCopy(`${sig.name}(${sig.params})`)}
                      className="text-[#9df] hover:bg-[#0f0f15]"
                    >
                      <Copy className="w-4 h-4" />
                    </Button>
                  </div>
                </Card>
              ))}
            </TabsContent>
          ))}

          {/* Risk Terms */}
          {riskTerms.length > 0 && (
            <TabsContent value="risk" className="space-y-3 mt-4">
              <Card className="bg-[#2d1515] border-[#8b3333] p-4">
                <p className="text-[#ff6b6b] font-semibold mb-3">Potenzielle Sicherheitsrisiken gefunden:</p>
                <div className="space-y-2">
                  {riskTerms.map((term: string, idx: number) => (
                    <div key={idx} className="bg-[#1b0f0f] p-2 rounded text-[#ff9999] font-mono text-sm">
                      {term}
                    </div>
                  ))}
                </div>
              </Card>
            </TabsContent>
          )}
        </Tabs>

        {/* Statistics */}
        <Card className="bg-[#1b2332] border-[#334] p-6">
          <h3 className="text-lg font-semibold mb-4">Statistiken</h3>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            <div className="bg-[#0f0f15] p-3 rounded">
              <div className="text-[#9df] text-xs">Gesamt Signaturen</div>
              <div className="text-2xl font-bold mt-1">{signatures.length}</div>
            </div>
            <div className="bg-[#0f0f15] p-3 rounded">
              <div className="text-[#9df] text-xs">Typen</div>
              <div className="text-2xl font-bold mt-1">{Object.keys(groupedSignatures).length}</div>
            </div>
            <div className="bg-[#0f0f15] p-3 rounded">
              <div className="text-[#9df] text-xs">Dateien</div>
              <div className="text-2xl font-bold mt-1">{new Set(signatures.map((s: any) => s.filePath)).size}</div>
            </div>
            <div className="bg-[#0f0f15] p-3 rounded">
              <div className="text-[#9df] text-xs">Risk-Terms</div>
              <div className="text-2xl font-bold mt-1">{riskTerms.length}</div>
            </div>
          </div>
        </Card>

        {/* Copy Confirmation */}
        {copied && (
          <div className="fixed bottom-6 right-6 bg-[#00ff00] text-[#000] px-4 py-2 rounded font-semibold">
            ✓ Kopiert!
          </div>
        )}
      </div>
    </div>
  );
}
