CREATE TABLE `analyses` (
	`id` int AUTO_INCREMENT NOT NULL,
	`linkId` int NOT NULL,
	`status` enum('ausstehend','läuft','fertig','Fehler') NOT NULL DEFAULT 'ausstehend',
	`analysisType` varchar(64),
	`totalFiles` int,
	`selectedCodeFiles` int,
	`analyzedFiles` int,
	`signatureCount` int DEFAULT 0,
	`importCount` int DEFAULT 0,
	`riskTermsFound` text,
	`errorMessage` text,
	`reportPath` varchar(1024),
	`aiSummary` text,
	`generatedModulePath` varchar(1024),
	`startedAt` timestamp,
	`completedAt` timestamp,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `analyses_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `auditLines` (
	`id` int NOT NULL,
	`text` text NOT NULL,
	`sha256` varchar(64) NOT NULL,
	`urlCount` int DEFAULT 0,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `auditLines_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `generatedModules` (
	`id` int AUTO_INCREMENT NOT NULL,
	`analysisId` int NOT NULL,
	`linkId` int NOT NULL,
	`moduleHash` varchar(64) NOT NULL,
	`modulePath` varchar(1024) NOT NULL,
	`functionCount` int DEFAULT 0,
	`classCount` int DEFAULT 0,
	`content` text,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `generatedModules_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `links` (
	`id` int NOT NULL,
	`url` varchar(2048) NOT NULL,
	`host` varchar(255) NOT NULL,
	`path` varchar(1024) NOT NULL,
	`kind` varchar(64) NOT NULL,
	`sha256` varchar(64) NOT NULL,
	`occurrences` int NOT NULL DEFAULT 1,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `links_id` PRIMARY KEY(`id`),
	CONSTRAINT `links_url_unique` UNIQUE(`url`)
);
--> statement-breakpoint
CREATE TABLE `signatures` (
	`id` int AUTO_INCREMENT NOT NULL,
	`analysisId` int NOT NULL,
	`linkId` int NOT NULL,
	`filePath` varchar(1024) NOT NULL,
	`signatureType` varchar(64) NOT NULL,
	`name` varchar(255) NOT NULL,
	`params` text,
	`startPosition` int,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `signatures_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
ALTER TABLE `analyses` ADD CONSTRAINT `analyses_linkId_links_id_fk` FOREIGN KEY (`linkId`) REFERENCES `links`(`id`) ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE `generatedModules` ADD CONSTRAINT `generatedModules_analysisId_analyses_id_fk` FOREIGN KEY (`analysisId`) REFERENCES `analyses`(`id`) ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE `generatedModules` ADD CONSTRAINT `generatedModules_linkId_links_id_fk` FOREIGN KEY (`linkId`) REFERENCES `links`(`id`) ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE `signatures` ADD CONSTRAINT `signatures_analysisId_analyses_id_fk` FOREIGN KEY (`analysisId`) REFERENCES `analyses`(`id`) ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE `signatures` ADD CONSTRAINT `signatures_linkId_links_id_fk` FOREIGN KEY (`linkId`) REFERENCES `links`(`id`) ON DELETE no action ON UPDATE no action;