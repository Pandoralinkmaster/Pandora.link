import { int, mysqlEnum, mysqlTable, text, timestamp, varchar } from "drizzle-orm/mysql-core";

/**
 * Core user table backing auth flow.
 * Extend this file with additional tables as your product grows.
 * Columns use camelCase to match both database fields and generated types.
 */
export const users = mysqlTable("users", {
  /**
   * Surrogate primary key. Auto-incremented numeric value managed by the database.
   * Use this for relations between tables.
   */
  id: int("id").autoincrement().primaryKey(),
  /** Manus OAuth identifier (openId) returned from the OAuth callback. Unique per user. */
  openId: varchar("openId", { length: 64 }).notNull().unique(),
  name: text("name"),
  email: varchar("email", { length: 320 }),
  loginMethod: varchar("loginMethod", { length: 64 }),
  role: mysqlEnum("role", ["user", "admin"]).default("user").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
  lastSignedIn: timestamp("lastSignedIn").defaultNow().notNull(),
});

export type User = typeof users.$inferSelect;
export type InsertUser = typeof users.$inferInsert;

/**
 * Links table: stores all 118 unique links from links.json
 */
export const links = mysqlTable("links", {
  id: int("id").autoincrement().primaryKey(),
  url: varchar("url", { length: 2048 }).notNull().unique(),
  host: varchar("host", { length: 255 }).notNull(),
  path: varchar("path", { length: 1024 }).notNull(),
  kind: varchar("kind", { length: 64 }).notNull(), // github_repository_or_page, web_page, github_topic_page, download_page
  sha256: varchar("sha256", { length: 64 }).notNull(),
  occurrences: int("occurrences").default(1).notNull(), // count of how many times this link appears in source
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type Link = typeof links.$inferSelect;
export type InsertLink = typeof links.$inferInsert;

/**
 * Analyses table: stores analysis results for each link
 */
export const analyses = mysqlTable("analyses", {
  id: int("id").autoincrement().primaryKey(),
  linkId: int("linkId").notNull().references(() => links.id),
  status: mysqlEnum("status", ["ausstehend", "läuft", "fertig", "Fehler"]).default("ausstehend").notNull(),
  analysisType: varchar("analysisType", { length: 64 }), // github_repo, web_page
  totalFiles: int("totalFiles"),
  selectedCodeFiles: int("selectedCodeFiles"),
  analyzedFiles: int("analyzedFiles"),
  signatureCount: int("signatureCount").default(0),
  importCount: int("importCount").default(0),
  riskTermsFound: text("riskTermsFound"), // JSON array
  errorMessage: text("errorMessage"),
  reportPath: varchar("reportPath", { length: 1024 }), // path to JSON report
  aiSummary: text("aiSummary"), // LLM-generated summary
  generatedModulePath: varchar("generatedModulePath", { length: 1024 }),
  startedAt: timestamp("startedAt"),
  completedAt: timestamp("completedAt"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type Analysis = typeof analyses.$inferSelect;
export type InsertAnalysis = typeof analyses.$inferInsert;

/**
 * Signatures table: stores extracted function/class signatures
 */
export const signatures = mysqlTable("signatures", {
  id: int("id").autoincrement().primaryKey(),
  analysisId: int("analysisId").notNull().references(() => analyses.id),
  linkId: int("linkId").notNull().references(() => links.id),
  filePath: varchar("filePath", { length: 1024 }).notNull(),
  signatureType: varchar("signatureType", { length: 64 }).notNull(), // python_function, python_class, js_function, etc.
  name: varchar("name", { length: 255 }).notNull(),
  params: text("params"), // parameter list
  startPosition: int("startPosition"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type Signature = typeof signatures.$inferSelect;
export type InsertSignature = typeof signatures.$inferInsert;

/**
 * Audit lines table: stores all 126 source lines with SHA256
 */
export const auditLines = mysqlTable("auditLines", {
  id: int("id").autoincrement().primaryKey(),
  text: text("text").notNull(),
  sha256: varchar("sha256", { length: 64 }).notNull(),
  urlCount: int("urlCount").default(0),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type AuditLine = typeof auditLines.$inferSelect;
export type InsertAuditLine = typeof auditLines.$inferInsert;

/**
 * Generated modules table: stores info about generated Python modules
 */
export const generatedModules = mysqlTable("generatedModules", {
  id: int("id").autoincrement().primaryKey(),
  analysisId: int("analysisId").notNull().references(() => analyses.id),
  linkId: int("linkId").notNull().references(() => links.id),
  moduleHash: varchar("moduleHash", { length: 64 }).notNull(),
  modulePath: varchar("modulePath", { length: 1024 }).notNull(),
  functionCount: int("functionCount").default(0),
  classCount: int("classCount").default(0),
  content: text("content"), // Python module source code
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type GeneratedModule = typeof generatedModules.$inferSelect;
export type InsertGeneratedModule = typeof generatedModules.$inferInsert;