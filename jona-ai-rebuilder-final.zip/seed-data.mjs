import fs from "fs";
import path from "path";
import mysql from "mysql2/promise";

const DATABASE_URL = process.env.DATABASE_URL;
if (!DATABASE_URL) {
  console.error("DATABASE_URL not set");
  process.exit(1);
}

async function seed() {
  const connection = await mysql.createConnection(DATABASE_URL);

  try {
    // Read links.json
    const linksPath = "/home/ubuntu/zip_analysis/JonaAI_project/JonaAI_AllLinks_Rebuilder_WebApp/data/links.json";
    const linksData = JSON.parse(fs.readFileSync(linksPath, "utf-8"));

    console.log(`Importing ${linksData.length} links...`);

    for (const link of linksData) {
      try {
        await connection.execute(
          `INSERT INTO links (id, url, host, path, kind, sha256, occurrences) 
           VALUES (?, ?, ?, ?, ?, ?, ?)
           ON DUPLICATE KEY UPDATE occurrences = occurrences + 1`,
          [link.id, link.url, link.host, link.path, link.kind, link.sha256, link.occurrences?.length || 1]
        );
      } catch (e) {
        console.error(`Failed to insert link ${link.id}:`, e.message);
      }
    }

    console.log("Links imported successfully");

    // Read line_audit.json
    const auditPath = "/home/ubuntu/zip_analysis/JonaAI_project/JonaAI_AllLinks_Rebuilder_WebApp/data/line_audit.json";
    const auditData = JSON.parse(fs.readFileSync(auditPath, "utf-8"));

    console.log(`Importing ${auditData.length} audit lines...`);

    for (const line of auditData) {
      try {
        await connection.execute(
          `INSERT INTO auditLines (id, text, sha256, urlCount) 
           VALUES (?, ?, ?, ?)
           ON DUPLICATE KEY UPDATE urlCount = ?`,
          [line.line, line.text, line.sha256, line.urls?.length || 0, line.urls?.length || 0]
        );
      } catch (e) {
        console.error(`Failed to insert audit line ${line.line}:`, e.message);
      }
    }

    console.log("Audit lines imported successfully");
  } finally {
    await connection.end();
  }
}

seed().catch(console.error);
