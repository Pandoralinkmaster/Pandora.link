import { getDb } from "./db";
import { analyses, signatures } from "../drizzle/schema";
import { eq } from "drizzle-orm";

/**
 * Speichere Imports für eine Analyse
 */
export async function storeImports(analysisId: number, imports: string[]) {
  const db = await getDb();
  if (!db) return;

  const importStr = JSON.stringify(imports.slice(0, 50));
  await db
    .update(analyses)
    .set({ riskTermsFound: importStr })
    .where(eq(analyses.id, analysisId));
}

/**
 * Speichere Risk-Terms für eine Analyse
 */
export async function storeRiskTerms(analysisId: number, riskTerms: string[]) {
  const db = await getDb();
  if (!db) return;

  const termsStr = JSON.stringify(riskTerms);
  await db
    .update(analyses)
    .set({ riskTermsFound: termsStr })
    .where(eq(analyses.id, analysisId));
}

/**
 * Rufe alle Signaturen für eine Analyse ab
 */
export async function getAnalysisSignatures(analysisId: number) {
  const db = await getDb();
  if (!db) return [];

  return await db
    .select()
    .from(signatures)
    .where(eq(signatures.analysisId, analysisId));
}

/**
 * Rufe Signaturen nach Typ ab
 */
export async function getSignaturesByType(analysisId: number, type: string) {
  const db = await getDb();
  if (!db) return [];

  return await db
    .select()
    .from(signatures)
    .where(eq(signatures.analysisId, analysisId) && eq(signatures.signatureType, type));
}

/**
 * Berechne Analyse-Statistiken
 */
export async function calculateAnalysisStats(analysisId: number) {
  const db = await getDb();
  if (!db) return null;

  const sigs = await db
    .select()
    .from(signatures)
    .where(eq(signatures.analysisId, analysisId));

  const byType: Record<string, number> = {};
  for (const sig of sigs) {
    byType[sig.signatureType] = (byType[sig.signatureType] || 0) + 1;
  }

  return {
    totalSignatures: sigs.length,
    byType,
    uniqueFiles: new Set(sigs.map((s) => s.filePath)).size,
  };
}

/**
 * Exportiere Analyse als JSON-Report
 */
export async function exportAnalysisReport(analysisId: number) {
  const db = await getDb();
  if (!db) return null;

  const analysis = await db
    .select()
    .from(analyses)
    .where(eq(analyses.id, analysisId))
    .limit(1);

  if (!analysis.length) return null;

  const sigs = await db
    .select()
    .from(signatures)
    .where(eq(signatures.analysisId, analysisId));

  const stats = await calculateAnalysisStats(analysisId);

  return {
    analysisId,
    linkId: analysis[0].linkId,
    status: analysis[0].status,
    analysisType: analysis[0].analysisType,
    totalFiles: analysis[0].totalFiles,
    selectedCodeFiles: analysis[0].selectedCodeFiles,
    analyzedFiles: analysis[0].analyzedFiles,
    signatureCount: analysis[0].signatureCount,
    importCount: analysis[0].importCount,
    riskTermsFound: analysis[0].riskTermsFound ? JSON.parse(analysis[0].riskTermsFound) : [],
    aiSummary: analysis[0].aiSummary,
    generatedModulePath: analysis[0].generatedModulePath,
    startedAt: analysis[0].startedAt,
    completedAt: analysis[0].completedAt,
    signatures: sigs.map((s) => ({
      type: s.signatureType,
      name: s.name,
      params: s.params,
      file: s.filePath,
    })),
    statistics: stats,
  };
}

/**
 * Vergleiche zwei Analysen
 */
export async function compareAnalyses(analysisId1: number, analysisId2: number) {
  const report1 = await exportAnalysisReport(analysisId1);
  const report2 = await exportAnalysisReport(analysisId2);

  if (!report1 || !report2) return null;

  return {
    analysis1: report1,
    analysis2: report2,
    differences: {
      signatureCountDiff: (report1.signatureCount || 0) - (report2.signatureCount || 0),
      fileCountDiff: (report1.analyzedFiles || 0) - (report2.analyzedFiles || 0),
      statusChanged: report1.status !== report2.status,
    },
  };
}
