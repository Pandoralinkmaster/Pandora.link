import { protectedProcedure, router } from "./_core/trpc";
import { z } from "zod";
import { getDb } from "./db";
import { eq, and, desc, asc, like } from "drizzle-orm";
import { links, analyses, signatures, auditLines, generatedModules } from "../drizzle/schema";
import { analyzeGitHubRepo, extractSignatures, generatePythonModule, generateAISummary, analyzeFileContent } from "./analysis";
import { TRPCError } from "@trpc/server";

export const analysisRouter = router({
  /**
   * Get all links with their analysis status
   */
  listLinks: protectedProcedure
    .input(z.object({
      skip: z.number().default(0),
      take: z.number().default(50),
      search: z.string().optional(),
      kind: z.string().optional(),
    }))
    .query(async ({ input }) => {
      const db = await getDb();
      if (!db) throw new TRPCError({ code: "INTERNAL_SERVER_ERROR", message: "Database unavailable" });

      let query = db.select().from(links);

      if (input.search) {
        query = query.where(
          like(links.url, `%${input.search}%`)
        ) as any;
      }

      if (input.kind) {
        query = query.where(eq(links.kind, input.kind)) as any;
      }

      const results = await query.limit(input.take).offset(input.skip);
      return results;
    }),

  /**
   * Get link details with analysis status
   */
  getLink: protectedProcedure
    .input(z.object({ linkId: z.number() }))
    .query(async ({ input }) => {
      const db = await getDb();
      if (!db) throw new TRPCError({ code: "INTERNAL_SERVER_ERROR", message: "Database unavailable" });

      const link = await db.select().from(links).where(eq(links.id, input.linkId)).limit(1);
      if (!link.length) throw new TRPCError({ code: "NOT_FOUND", message: "Link not found" });

      const analysis = await db
        .select()
        .from(analyses)
        .where(eq(analyses.linkId, input.linkId))
        .orderBy(desc(analyses.createdAt))
        .limit(1);

      const sigs = analysis.length
        ? await db.select().from(signatures).where(eq(signatures.analysisId, analysis[0].id))
        : [];

      return {
        link: link[0],
        analysis: analysis[0] || null,
        signatures: sigs,
      };
    }),

  /**
   * Start analysis for a single link
   */
  analyzeLink: protectedProcedure
    .input(z.object({ linkId: z.number() }))
    .mutation(async ({ input }) => {
      const db = await getDb();
      if (!db) throw new TRPCError({ code: "INTERNAL_SERVER_ERROR", message: "Database unavailable" });

      const link = await db.select().from(links).where(eq(links.id, input.linkId)).limit(1);
      if (!link.length) throw new TRPCError({ code: "NOT_FOUND", message: "Link not found" });

      // Create analysis record
      const [analysis] = await db.insert(analyses).values({
        linkId: input.linkId,
        status: "läuft",
        startedAt: new Date(),
      });

      try {
        const url = link[0].url;
        const isGitHub = url.includes("github.com");

        let report: any;
        if (isGitHub) {
          report = await analyzeGitHubRepo(url);
        } else {
          report = { type: "web_page", url, ok: false, error: "Web page analysis not yet implemented" };
        }

        // Store signatures
        if (report.analyzedFiles) {
          for (const file of report.analyzedFiles) {
            for (const sig of file.signatures) {
              await db.insert(signatures).values({
                analysisId: analysis.insertId as number,
                linkId: input.linkId,
                filePath: file.path,
                signatureType: sig.type,
                name: sig.name,
                params: sig.params,
              });
            }
          }
        }

        // Generate AI summary
        let aiSummary = "";
        if (report.analyzedFiles && report.analyzedFiles.length > 0) {
          aiSummary = await generateAISummary(input.linkId, report.analyzedFiles);
        }

        // Generate module
        let modulePath = "";
        if (report.analyzedFiles) {
          const allSigs = report.analyzedFiles.flatMap((f: any) => f.signatures);
          if (allSigs.length > 0) {
            const moduleContent = await generatePythonModule(analysis.insertId as number, input.linkId, allSigs);
            modulePath = `module_${Date.now()}.py`;
          }
        }

        // Update analysis with results
        await db
          .update(analyses)
          .set({
            status: "fertig",
            analysisType: report.type,
            totalFiles: report.totalFiles,
            selectedCodeFiles: report.selectedCodeFiles,
            analyzedFiles: report.analyzedFiles?.length || 0,
            signatureCount: report.analyzedFiles?.reduce((sum: number, f: any) => sum + f.signatures.length, 0) || 0,
            aiSummary,
            generatedModulePath: modulePath,
            completedAt: new Date(),
          })
          .where(eq(analyses.id, analysis.insertId as number));

        return { success: true, analysisId: analysis.insertId };
      } catch (error) {
        await db
          .update(analyses)
          .set({
            status: "Fehler",
            errorMessage: error instanceof Error ? error.message : "Unknown error",
            completedAt: new Date(),
          })
          .where(eq(analyses.id, analysis.insertId as number));

        throw new TRPCError({
          code: "INTERNAL_SERVER_ERROR",
          message: error instanceof Error ? error.message : "Analysis failed",
        });
      }
    }),

  /**
   * Get statistics
   */
  getStats: protectedProcedure.query(async () => {
    const db = await getDb();
    if (!db) throw new TRPCError({ code: "INTERNAL_SERVER_ERROR", message: "Database unavailable" });

    const totalLinks = await db.select().from(links);
    const completedAnalyses = await db
      .select()
      .from(analyses)
      .where(eq(analyses.status, "fertig"));
    const generatedModuleCount = await db.select().from(generatedModules);

    const successRate =
      totalLinks.length > 0 ? Math.round((completedAnalyses.length / totalLinks.length) * 100) : 0;

    return {
      totalLinks: totalLinks.length,
      completedAnalyses: completedAnalyses.length,
      generatedModules: generatedModuleCount.length,
      successRate,
    };
  }),

  /**
   * Get audit lines
   */
  getAuditLines: protectedProcedure
    .input(z.object({
      skip: z.number().default(0),
      take: z.number().default(50),
    }))
    .query(async ({ input }) => {
      const db = await getDb();
      if (!db) throw new TRPCError({ code: "INTERNAL_SERVER_ERROR", message: "Database unavailable" });

      const lines = await db
        .select()
        .from(auditLines)
        .orderBy(asc(auditLines.id))
        .limit(input.take)
        .offset(input.skip);

      return lines;
    }),

  /**
   * Get link manifest (all links with metadata)
   */
  getLinkManifest: protectedProcedure
    .input(z.object({
      skip: z.number().default(0),
      take: z.number().default(50),
    }))
    .query(async ({ input }) => {
      const db = await getDb();
      if (!db) throw new TRPCError({ code: "INTERNAL_SERVER_ERROR", message: "Database unavailable" });

      const items = await db
        .select()
        .from(links)
        .limit(input.take)
        .offset(input.skip);

      return items;
    }),

  /**
   * Download generated module
   */
  getGeneratedModule: protectedProcedure
    .input(z.object({ moduleId: z.number() }))
    .query(async ({ input }) => {
      const db = await getDb();
      if (!db) throw new TRPCError({ code: "INTERNAL_SERVER_ERROR", message: "Database unavailable" });

      const module = await db
        .select()
        .from(generatedModules)
        .where(eq(generatedModules.id, input.moduleId))
        .limit(1);

      if (!module.length) throw new TRPCError({ code: "NOT_FOUND", message: "Module not found" });

      return module[0];
    }),
});
