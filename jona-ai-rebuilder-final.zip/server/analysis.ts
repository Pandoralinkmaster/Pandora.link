import { eq, and } from "drizzle-orm";
import { getDb } from "./db";
import { analyses, links, signatures, generatedModules, InsertAnalysis, InsertSignature } from "../drizzle/schema";
import { invokeLLM } from "./_core/llm";
import * as crypto from "crypto";
import * as https from "https";

const SAFE_EXTENSIONS = {
  ".py": true, ".js": true, ".ts": true, ".tsx": true, ".jsx": true,
  ".java": true, ".kt": true, ".kts": true, ".go": true, ".rs": true,
  ".c": true, ".h": true, ".cpp": true, ".hpp": true, ".cs": true,
  ".php": true, ".rb": true, ".sh": true, ".yml": true, ".yaml": true,
  ".json": true, ".xml": true, ".html": true, ".css": true, ".md": true,
};

const SIG_PATTERNS = [
  { name: "python_function", regex: /^\s*def\s+([A-Za-z_][\w]*)\s*\(([^)]*)\)\s*:/gm },
  { name: "python_class", regex: /^\s*class\s+([A-Za-z_][\w]*)\s*(?:\(([^)]*)\))?\s*:/gm },
  { name: "js_function", regex: /\bfunction\s+([A-Za-z_$][\w$]*)\s*\(([^)]*)\)/gm },
  { name: "arrow_function", regex: /\b(?:const|let|var)\s+([A-Za-z_$][\w$]*)\s*=\s*(?:async\s*)?\(([^)]*)\)\s*=>/gm },
  { name: "java_like_method", regex: /\b(?:public|private|protected|static|final|suspend|fun)\s+[\w<>,\[\]?]+\s+([A-Za-z_][\w]*)\s*\(([^)]*)\)/gm },
  { name: "kotlin_function", regex: /\bfun\s+([A-Za-z_][\w]*)\s*\(([^)]*)\)/gm },
  { name: "go_function", regex: /\bfunc\s+(?:\([^)]*\)\s*)?([A-Za-z_][\w]*)\s*\(([^)]*)\)/gm },
];

const RISK_WORDS = /exploit|payload|shellcode|meterpreter|ransom|keylogger|credential|steal|ddos|botnet|reverse shell|malware/gi;

interface FileAnalysis {
  path: string;
  sha256: string;
  bytes: number;
  lines: number;
  signatures: Array<{ type: string; name: string; params: string }>;
  imports: string[];
  riskTerms: string[];
}

export async function extractSignatures(content: string): Promise<Array<{ type: string; name: string; params: string }>> {
  const results: Array<{ type: string; name: string; params: string }> = [];
  
  for (const pattern of SIG_PATTERNS) {
    let match;
    const regex = new RegExp(pattern.regex.source, pattern.regex.flags);
    while ((match = regex.exec(content)) !== null) {
      results.push({
        type: pattern.name,
        name: match[1] || "unknown",
        params: match[2] || "",
      });
    }
  }
  
  return results;
}

export async function analyzeFileContent(filePath: string, content: string): Promise<FileAnalysis> {
  const signatures = await extractSignatures(content);
  const imports = (content.match(/^\s*(?:import|from|require\(|include|using)\b.*$/gm) || []).slice(0, 40);
  const riskTerms = Array.from(new Set(content.match(RISK_WORDS) || []));
  
  return {
    path: filePath,
    sha256: crypto.createHash("sha256").update(content).digest("hex"),
    bytes: Buffer.byteLength(content),
    lines: content.split("\n").length,
    signatures,
    imports,
    riskTerms,
  };
}

export async function analyzeGitHubRepo(url: string): Promise<{
  type: string;
  url: string;
  ok: boolean;
  repo?: string;
  totalFiles?: number;
  selectedCodeFiles?: number;
  analyzedFiles?: FileAnalysis[];
  error?: string;
}> {
  try {
    const urlObj = new URL(url);
    if (urlObj.hostname !== "github.com") {
      return { type: "not_repo", url, ok: false, error: "Not a GitHub URL" };
    }

    const parts = urlObj.pathname.split("/").filter(Boolean);
    if (parts.length < 2) {
      return { type: "not_repo", url, ok: false, error: "Invalid GitHub URL" };
    }

    const owner = parts[0];
    const repo = parts[1].replace(".git", "");
    const apiUrl = `https://api.github.com/repos/${owner}/${repo}/git/trees/HEAD?recursive=1`;

    const treeData = await fetchJson(apiUrl, {
      "Accept": "application/vnd.github+json",
      "User-Agent": "LinkAnalyzer",
    });

    if (!treeData.tree) {
      return { type: "github_repo", url, ok: false, repo: `${owner}/${repo}`, error: "No tree data" };
    }

    const files = treeData.tree.filter((f: any) => f.type === "blob");
    const codeFiles = files.filter((f: any) => {
      const ext = f.path?.substring(f.path.lastIndexOf(".")).toLowerCase() || "";
      return SAFE_EXTENSIONS[ext as keyof typeof SAFE_EXTENSIONS];
    }).slice(0, 400);

    const analyzedFiles: FileAnalysis[] = [];

    for (const file of codeFiles) {
      try {
        const rawUrl = `https://raw.githubusercontent.com/${owner}/${repo}/HEAD/${file.path}`;
        const content = await fetchText(rawUrl, { "User-Agent": "LinkAnalyzer" });

        if (content && Buffer.byteLength(content) <= 300_000) {
          const analysis = await analyzeFileContent(file.path, content);
          analyzedFiles.push(analysis);
        }
      } catch (e) {
        // Skip files that can't be fetched
      }
    }

    return {
      type: "github_repo",
      url,
      ok: true,
      repo: `${owner}/${repo}`,
      totalFiles: files.length,
      selectedCodeFiles: codeFiles.length,
      analyzedFiles,
    };
  } catch (error) {
    return {
      type: "github_repo",
      url,
      ok: false,
      error: error instanceof Error ? error.message : "Unknown error",
    };
  }
}

async function fetchJson(url: string, headers: Record<string, string> = {}): Promise<any> {
  return new Promise((resolve, reject) => {
    const urlObj = new URL(url);
    const options = {
      hostname: urlObj.hostname,
      path: urlObj.pathname + urlObj.search,
      method: "GET",
      headers: { ...headers, "Accept-Encoding": "gzip" },
      timeout: 15000,
    };

    https.get(options, (res) => {
      let data = "";
      res.on("data", (chunk) => (data += chunk));
      res.on("end", () => {
        try {
          resolve(JSON.parse(data));
        } catch {
          reject(new Error("Invalid JSON"));
        }
      });
    }).on("error", reject);
  });
}

async function fetchText(url: string, headers: Record<string, string> = {}): Promise<string> {
  return new Promise((resolve, reject) => {
    const urlObj = new URL(url);
    const options = {
      hostname: urlObj.hostname,
      path: urlObj.pathname + urlObj.search,
      method: "GET",
      headers: { ...headers, "Accept-Encoding": "gzip" },
      timeout: 15000,
    };

    https.get(options, (res) => {
      let data = "";
      res.on("data", (chunk) => (data += chunk));
      res.on("end", () => resolve(data));
    }).on("error", reject);
  });
}

export async function generatePythonModule(
  analysisId: number,
  linkId: number,
  sigs: Array<{ type: string; name: string }>
): Promise<string> {
  const moduleHash = crypto.createHash("sha256").update(`${linkId}-${Date.now()}`).digest("hex").slice(0, 12);
  const modulePath = `module_${moduleHash}.py`;

  const seen = new Set<string>();
  const lines = [
    '"""Generated safe module. Function-equivalent scaffolding derived from signatures/structures."""',
    "from typing import Any, Dict, List",
    "",
    "",
  ];

  for (const sig of sigs.slice(0, 50)) {
    const name = sig.name.replace(/\W+/g, "_");
    if (name.startsWith("_")) continue;
    if (seen.has(name)) continue;
    seen.add(name);

    lines.push(`def ${name}(*args: Any, **kwargs: Any) -> Dict[str, Any]:`);
    lines.push(`    """Safe rebuilt placeholder for discovered ${sig.type}."""`);
    lines.push(`    return {"ok": True, "function": "${name}", "args_count": len(args), "kwargs": sorted(kwargs.keys())}`);
    lines.push("");
  }

  const content = lines.join("\n");
  const db = await getDb();
  if (!db) throw new Error("Database not available");

  await db.insert(generatedModules).values({
    analysisId,
    linkId,
    moduleHash,
    modulePath,
    functionCount: seen.size,
    classCount: 0,
    content,
  });

  return content;
}

export async function generateAISummary(_linkId: number, fileAnalyses: FileAnalysis[]): Promise<string> {
  try {
    const imports = fileAnalyses.flatMap((f) => f.imports).slice(0, 20);
    const sigCount = fileAnalyses.reduce((sum, f) => sum + f.signatures.length, 0);
    const topSigs = fileAnalyses
      .flatMap((f) => f.signatures.map((s) => `${s.type}: ${s.name}`))
      .slice(0, 15);

    const prompt = `Based on the following code analysis, provide a brief 2-3 sentence summary of what this repository does:

Imports: ${imports.join(", ")}
Signatures found: ${sigCount}
Top functions/classes: ${topSigs.join(", ")}

Focus on the repository's purpose and main functionality.`;

    const response = await invokeLLM({
      messages: [{ role: "user", content: prompt }],
    });

    const content = response.choices?.[0]?.message?.content;
    const summary = typeof content === "string" ? content : "Unable to generate summary";
    return summary;
  } catch (error) {
    return "AI summary generation failed";
  }
}
