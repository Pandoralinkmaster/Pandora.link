import { publicProcedure, router } from "./_core/trpc";
import { z } from "zod";
import { getDb } from "./db";
import { eq, like } from "drizzle-orm";

// Signatur-Patterns aus Original-Backend
const SIG_PATTERNS = [
  { type: "python_function", pattern: /^\s*def\s+([A-Za-z_][\w]*)\s*\(([^)]*)\)\s*:/gm },
  { type: "python_class", pattern: /^\s*class\s+([A-Za-z_][\w]*)\s*(?:\(([^)]*)\))?\s*:/gm },
  { type: "js_function", pattern: /\bfunction\s+([A-Za-z_$][\w$]*)\s*\(([^)]*)\)/gm },
  { type: "arrow_function", pattern: /\b(?:const|let|var)\s+([A-Za-z_$][\w$]*)\s*=\s*(?:async\s*)?\(([^)]*)\)\s*=>/gm },
  { type: "java_like_method", pattern: /\b(?:public|private|protected|static|final|suspend|fun)\s+[\w<>,\[\]?]+\s+([A-Za-z_][\w]*)\s*\(([^)]*)\)/gm },
  { type: "kotlin_function", pattern: /\bfun\s+([A-Za-z_][\w]*)\s*\(([^)]*)\)/gm },
  { type: "go_function", pattern: /\bfunc\s+(?:\([^)]*\)\s*)?([A-Za-z_][\w]*)\s*\(([^)]*)\)/gm },
];

const RISK_WORDS = /exploit|payload|shellcode|meterpreter|ransom|keylogger|credential|steal|ddos|botnet|reverse shell|malware/gi;

export function extractSignatures(content: string) {
  const signatures: any[] = [];
  
  for (const { type, pattern } of SIG_PATTERNS) {
    let match;
    const regex = new RegExp(pattern.source, pattern.flags);
    while ((match = regex.exec(content)) !== null) {
      signatures.push({
        type,
        name: match[1],
        params: match[2] || "",
        position: match.index,
      });
    }
  }
  
  return signatures;
}

export function extractImports(content: string) {
  const imports = content.match(/^\s*(?:import|from|require\(|include|using)\b.*$/gm) || [];
  return imports.slice(0, 40);
}

export function extractRiskTerms(content: string) {
  const matches = content.match(RISK_WORDS) || [];
  return Array.from(new Set(matches.map(m => m.toLowerCase())));
}

export function summarizeCode(content: string) {
  const signatures = extractSignatures(content);
  const imports = extractImports(content);
  const riskTerms = extractRiskTerms(content);
  
  return {
    signatures,
    imports,
    riskTerms,
    lines: content.split("\n").length,
    bytes: Buffer.byteLength(content),
  };
}

export function generatePythonModule(linkId: number, signatures: any[]) {
  const lines: string[] = [
    '"""Generated safe module. It is function-equivalent scaffolding derived from signatures/structures, not copied source."""',
    "from typing import Any, Dict, List",
    "",
    "",
  ];

  const seen: Set<string> = new Set();
  
  for (const sig of signatures.slice(0, 50)) {
    let name = sig.name.replace(/\W+/g, "_");
    if (name.startsWith("_")) name = "fn" + name;
    
    if (seen.has(name)) continue;
    seen.add(name);
    
    lines.push(`def ${name}(*args: Any, **kwargs: Any) -> Dict[str, Any]:`);
    lines.push(`    """Safe rebuilt placeholder for discovered ${sig.type}."""`);
    lines.push(`    return {"ok": True, "function": "${name}", "args_count": len(args), "kwargs": sorted(kwargs.keys())}`);
    lines.push("");
  }
  
  if (lines.length <= 4) {
    lines.push("def analyze_source(*args: Any, **kwargs: Any) -> Dict[str, Any]:");
    lines.push('    """Default safe placeholder."""');
    lines.push('    return {"ok": True, "function": "analyze_source"}');
  }
  
  return lines.join("\n");
}

export const codeRouter = router({
  // Extrahiere Signaturen aus Code-Inhalt
  extractSignatures: publicProcedure
    .input(z.object({ content: z.string() }))
    .query(({ input }) => extractSignatures(input.content)),

  // Extrahiere Imports aus Code-Inhalt
  extractImports: publicProcedure
    .input(z.object({ content: z.string() }))
    .query(({ input }) => extractImports(input.content)),

  // Extrahiere Risk-Terms aus Code-Inhalt
  extractRiskTerms: publicProcedure
    .input(z.object({ content: z.string() }))
    .query(({ input }) => extractRiskTerms(input.content)),

  // Zusammenfassung eines Code-Inhalts
  summarizeCode: publicProcedure
    .input(z.object({ content: z.string() }))
    .query(({ input }) => summarizeCode(input.content)),

  // Generiere Python-Modul aus Signaturen
  generateModule: publicProcedure
    .input(z.object({ linkId: z.number(), signatures: z.array(z.any()) }))
    .query(({ input }) => ({
      module: generatePythonModule(input.linkId, input.signatures),
      filename: `module_link_${input.linkId}.py`,
    })),

  // Batch-Signatur-Extraktion für mehrere Links
  batchExtractSignatures: publicProcedure
    .input(z.object({ 
      links: z.array(z.object({ 
        id: z.number(), 
        content: z.string() 
      })) 
    }))
    .query(({ input }) => {
      return input.links.map(link => ({
        linkId: link.id,
        signatures: extractSignatures(link.content),
        imports: extractImports(link.content),
        riskTerms: extractRiskTerms(link.content),
      }));
    }),

  // Vergleiche zwei Code-Inhalte
  compareCode: publicProcedure
    .input(z.object({ 
      content1: z.string(), 
      content2: z.string() 
    }))
    .query(({ input }) => {
      const sigs1 = extractSignatures(input.content1);
      const sigs2 = extractSignatures(input.content2);
      const imports1 = extractImports(input.content1);
      const imports2 = extractImports(input.content2);
      
      return {
        signatures: {
          count1: sigs1.length,
          count2: sigs2.length,
          diff: sigs1.length - sigs2.length,
        },
        imports: {
          count1: imports1.length,
          count2: imports2.length,
          diff: imports1.length - imports2.length,
        },
        lines: {
          count1: input.content1.split("\n").length,
          count2: input.content2.split("\n").length,
        },
      };
    }),

  // Finde ähnliche Funktionen zwischen zwei Code-Inhalten
  findSimilarFunctions: publicProcedure
    .input(z.object({ 
      content1: z.string(), 
      content2: z.string() 
    }))
    .query(({ input }) => {
      const sigs1 = extractSignatures(input.content1);
      const sigs2 = extractSignatures(input.content2);
      
      const names1: Set<string> = new Set(sigs1.map(s => s.name));
      const names2: Set<string> = new Set(sigs2.map(s => s.name));
      
      const common = Array.from(names1).filter(n => names2.has(n));
      const unique1 = Array.from(names1).filter(n => !names2.has(n));
      const unique2 = Array.from(names2).filter(n => !names1.has(n));
      
      return {
        commonFunctions: common,
        uniqueInFirst: unique1,
        uniqueInSecond: unique2,
        similarity: names1.size > 0 || names2.size > 0 ? common.length / Math.max(names1.size, names2.size) : 0,
      };
    }),

  // Syntax-Highlighting Vorbereitung
  getCodeLanguage: publicProcedure
    .input(z.object({ filePath: z.string() }))
    .query(({ input }) => {
      const ext = input.filePath.split(".").pop()?.toLowerCase();
      const languageMap: Record<string, string> = {
        py: "python",
        js: "javascript",
        jsx: "jsx",
        ts: "typescript",
        tsx: "tsx",
        java: "java",
        kt: "kotlin",
        go: "go",
        rs: "rust",
        c: "c",
        cpp: "cpp",
        cs: "csharp",
        php: "php",
        rb: "ruby",
        sh: "bash",
        yml: "yaml",
        yaml: "yaml",
        json: "json",
        xml: "xml",
        html: "html",
        css: "css",
        md: "markdown",
      };
      return { language: languageMap[ext || ""] || "plaintext" };
    }),

  // Formatiere Code für Anzeige
  formatCode: publicProcedure
    .input(z.object({ 
      content: z.string(),
      maxLines: z.number().optional(),
      highlight: z.boolean().optional(),
    }))
    .query(({ input }) => {
      let lines = input.content.split("\n");
      
      if (input.maxLines && lines.length > input.maxLines) {
        lines = lines.slice(0, input.maxLines);
        lines.push(`... (${input.content.split("\n").length - input.maxLines} weitere Zeilen)`);
      }
      
      return {
        formatted: lines.join("\n"),
        lineCount: lines.length,
        truncated: input.maxLines ? lines.length > input.maxLines : false,
      };
    }),
});
