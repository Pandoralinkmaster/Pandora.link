import { protectedProcedure, router } from "./_core/trpc";
import { z } from "zod";
import { getDb } from "./db";
import { eq, desc } from "drizzle-orm";
import { analyses, links, signatures } from "../drizzle/schema";
import { TRPCError } from "@trpc/server";

export const reportsRouter = router({
  /**
   * Get all reports with pagination
   */
  listReports: protectedProcedure
    .input(z.object({
      skip: z.number().default(0),
      take: z.number().default(50),
      status: z.string().optional(),
    }))
    .query(async ({ input }) => {
      const db = await getDb();
      if (!db) throw new TRPCError({ code: "INTERNAL_SERVER_ERROR", message: "Database unavailable" });

      let query = db
        .select()
        .from(analyses)
        .orderBy(desc(analyses.completedAt));

      if (input.status) {
        query = query.where(eq(analyses.status, input.status as any)) as any;
      }

      const results = await query.limit(input.take).offset(input.skip);
      return results;
    }),

  /**
   * Get detailed report for a single analysis
   */
  getReport: protectedProcedure
    .input(z.object({ analysisId: z.number() }))
    .query(async ({ input }) => {
      const db = await getDb();
      if (!db) throw new TRPCError({ code: "INTERNAL_SERVER_ERROR", message: "Database unavailable" });

      const analysis = await db
        .select()
        .from(analyses)
        .where(eq(analyses.id, input.analysisId))
        .limit(1);

      if (!analysis.length) {
        throw new TRPCError({ code: "NOT_FOUND", message: "Report not found" });
      }

      const link = await db
        .select()
        .from(links)
        .where(eq(links.id, analysis[0].linkId))
        .limit(1);

      const sigs = await db
        .select()
        .from(signatures)
        .where(eq(signatures.analysisId, input.analysisId));

      const sigsByType: Record<string, number> = {};
      for (const sig of sigs) {
        sigsByType[sig.signatureType] = (sigsByType[sig.signatureType] || 0) + 1;
      }

      return {
        analysis: analysis[0],
        link: link[0],
        signatures: sigs,
        statistics: {
          totalSignatures: sigs.length,
          byType: sigsByType,
          uniqueFiles: new Set(sigs.map((s) => s.filePath)).size,
        },
      };
    }),

  /**
   * Get analytics summary
   */
  getAnalyticsSummary: protectedProcedure.query(async () => {
    const db = await getDb();
    if (!db) throw new TRPCError({ code: "INTERNAL_SERVER_ERROR", message: "Database unavailable" });

    const allAnalyses = await db.select().from(analyses);
    const allLinks = await db.select().from(links);
    const allSignatures = await db.select().from(signatures);

    const byStatus: Record<string, number> = {};
    for (const analysis of allAnalyses) {
      byStatus[analysis.status] = (byStatus[analysis.status] || 0) + 1;
    }

    const byLinkType: Record<string, number> = {};
    for (const link of allLinks) {
      byLinkType[link.kind] = (byLinkType[link.kind] || 0) + 1;
    }

    const sigsByType: Record<string, number> = {};
    for (const sig of allSignatures) {
      sigsByType[sig.signatureType] = (sigsByType[sig.signatureType] || 0) + 1;
    }

    const completedAnalyses = allAnalyses.filter((a) => a.status === "fertig");
    const totalSignatures = completedAnalyses.reduce((sum, a) => sum + (a.signatureCount || 0), 0);
    const avgSignaturesPerAnalysis = completedAnalyses.length > 0 ? totalSignatures / completedAnalyses.length : 0;

    return {
      summary: {
        totalLinks: allLinks.length,
        totalAnalyses: allAnalyses.length,
        completedAnalyses: completedAnalyses.length,
        totalSignatures,
        averageSignaturesPerAnalysis: Math.round(avgSignaturesPerAnalysis),
        completionRate: allLinks.length > 0 ? Math.round((completedAnalyses.length / allLinks.length) * 100) : 0,
      },
      byStatus,
      byLinkType,
      bySignatureType: sigsByType,
    };
  }),

  /**
   * Export report as JSON
   */
  exportReport: protectedProcedure
    .input(z.object({ analysisId: z.number() }))
    .query(async ({ input }) => {
      const db = await getDb();
      if (!db) throw new TRPCError({ code: "INTERNAL_SERVER_ERROR", message: "Database unavailable" });

      const analysis = await db
        .select()
        .from(analyses)
        .where(eq(analyses.id, input.analysisId))
        .limit(1);

      if (!analysis.length) {
        throw new TRPCError({ code: "NOT_FOUND", message: "Report not found" });
      }

      const link = await db
        .select()
        .from(links)
        .where(eq(links.id, analysis[0].linkId))
        .limit(1);

      const sigs = await db
        .select()
        .from(signatures)
        .where(eq(signatures.analysisId, input.analysisId));

      return {
        exportedAt: new Date().toISOString(),
        link: link[0],
        analysis: analysis[0],
        signatures: sigs.map((s) => ({
          type: s.signatureType,
          name: s.name,
          params: s.params,
          file: s.filePath,
        })),
      };
    }),

  /**
   * Get top signatures by frequency
   */
  getTopSignatures: protectedProcedure
    .input(z.object({ limit: z.number().default(20) }))
    .query(async ({ input }) => {
      const db = await getDb();
      if (!db) throw new TRPCError({ code: "INTERNAL_SERVER_ERROR", message: "Database unavailable" });

      const allSigs = await db.select().from(signatures);

      const nameFrequency: Record<string, number> = {};
      for (const sig of allSigs) {
        nameFrequency[sig.name] = (nameFrequency[sig.name] || 0) + 1;
      }

      return Object.entries(nameFrequency)
        .sort(([, a], [, b]) => b - a)
        .slice(0, input.limit)
        .map(([name, count]) => ({ name, count }));
    }),

  /**
   * Get analysis timeline
   */
  getAnalysisTimeline: protectedProcedure.query(async () => {
    const db = await getDb();
    if (!db) throw new TRPCError({ code: "INTERNAL_SERVER_ERROR", message: "Database unavailable" });

    const allAnalyses = await db
      .select()
      .from(analyses)
      .orderBy(desc(analyses.completedAt));

    const timeline = allAnalyses
      .filter((a) => a.completedAt)
      .map((a) => ({
        date: a.completedAt?.toISOString().split("T")[0],
        linkId: a.linkId,
        status: a.status,
        signatureCount: a.signatureCount,
      }))
      .slice(0, 30);

    return timeline;
  }),
});
