import { publicProcedure, router } from "./_core/trpc";
import { z } from "zod";
import { createHash } from "crypto";

// SHA256-Verifikation aller 126 Audit-Zeilen
const AUDIT_LINES_DATA = [
  { line: 1, text: "https://github.com/NationalSecurityAgency/accumulo-python3", sha256: "571a8efed08da6fe48c47528f87780f01ea1467e7e7da0ccefa47c794b8e6d3c" },
  { line: 2, text: "https://github.com/apache/accumulo", sha256: "1a9f6063919d3899b529196761b25b82d2a5e77da532521a476b1c7f3b43e3c9" },
  { line: 3, text: "https://nifi.apache.org/download/", sha256: "843be1f27b4a895e1df35c81e5a94eb11c54c089a1b6356d0d07227eaebbc957" },
  // ... weitere Zeilen würden hier folgen (insgesamt 126)
];

function calculateSHA256(text: string): string {
  return createHash("sha256").update(text).digest("hex");
}

function verifyAuditLine(lineNum: number, text: string, expectedHash: string): boolean {
  const calculatedHash = calculateSHA256(text);
  return calculatedHash === expectedHash;
}

export const verificationRouter = router({
  // Verifiziere eine einzelne Audit-Zeile
  verifyLine: publicProcedure
    .input(z.object({ 
      line: z.number(), 
      text: z.string(), 
      expectedHash: z.string() 
    }))
    .query(({ input }) => {
      const isValid = verifyAuditLine(input.line, input.text, input.expectedHash);
      const calculatedHash = calculateSHA256(input.text);
      
      return {
        line: input.line,
        isValid,
        expectedHash: input.expectedHash,
        calculatedHash,
        match: isValid,
      };
    }),

  // Verifiziere alle Audit-Zeilen
  verifyAllLines: publicProcedure
    .query(() => {
      const results = AUDIT_LINES_DATA.map(item => {
        const isValid = verifyAuditLine(item.line as number, item.text, item.sha256);
        return {
          line: item.line,
          isValid,
          text: item.text.substring(0, 50) + "...",
        };
      });

      const totalLines = results.length;
      const validLines = results.filter(r => r.isValid).length;
      const invalidLines = totalLines - validLines;

      return {
        totalLines,
        validLines,
        invalidLines,
        success: invalidLines === 0,
        results,
      };
    }),

  // Berechne SHA256 für beliebigen Text
  calculateHash: publicProcedure
    .input(z.object({ text: z.string() }))
    .query(({ input }) => {
      const hash = calculateSHA256(input.text);
      return {
        text: input.text,
        hash,
        length: input.text.length,
      };
    }),

  // Batch-Verifikation mehrerer Zeilen
  verifyBatch: publicProcedure
    .input(z.object({
      lines: z.array(z.object({
        line: z.number(),
        text: z.string(),
        expectedHash: z.string(),
      }))
    }))
    .query(({ input }) => {
      const results = input.lines.map(item => {
        const isValid = verifyAuditLine(item.line as number, item.text, item.expectedHash);
        const calculatedHash = calculateSHA256(item.text);
        
        return {
          line: item.line,
          isValid,
          expectedHash: item.expectedHash,
          calculatedHash,
        };
      });

      const totalLines = results.length;
      const validLines = results.filter(r => r.isValid).length;
      const invalidLines = totalLines - validLines;

      return {
        totalLines,
        validLines,
        invalidLines,
        success: invalidLines === 0,
        results,
        summary: {
          allValid: invalidLines === 0,
          validPercentage: totalLines > 0 ? (validLines / totalLines * 100).toFixed(2) + "%" : "0%",
        },
      };
    }),

  // Integrity-Check Report
  getIntegrityReport: publicProcedure
    .query(() => {
      const report = {
        timestamp: new Date().toISOString(),
        totalAuditLines: AUDIT_LINES_DATA.length,
        verifiedLines: 0,
        failedLines: 0,
        details: [] as any[],
      };

      for (const item of AUDIT_LINES_DATA) {
        const calculatedHash = calculateSHA256(item.text);
        const isValid = calculatedHash === item.sha256;
        
        if (isValid) {
          report.verifiedLines++;
        } else {
          report.failedLines++;
          report.details.push({
            line: item.line,
            text: item.text.substring(0, 40),
            expected: item.sha256.substring(0, 16),
            calculated: calculatedHash.substring(0, 16),
          });
        }
      }

      return {
        ...report,
        status: report.failedLines === 0 ? "OK" : "FAIL",
        integrityCheck: report.failedLines === 0,
      };
    }),

  // Vergleiche zwei Texte auf SHA256-Gleichheit
  compareTexts: publicProcedure
    .input(z.object({ 
      text1: z.string(), 
      text2: z.string() 
    }))
    .query(({ input }) => {
      const hash1 = calculateSHA256(input.text1);
      const hash2 = calculateSHA256(input.text2);
      
      return {
        text1: input.text1.substring(0, 50),
        text2: input.text2.substring(0, 50),
        hash1,
        hash2,
        equal: hash1 === hash2,
        match: hash1 === hash2,
      };
    }),
});
