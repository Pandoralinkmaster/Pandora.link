# Pandora Android

## Build-Anleitung via GitHub Actions

1. GitHub-Account erstellen (falls nicht vorhanden)
2. Neues Repository erstellen: `pandora-android`
3. Alle Dateien aus diesem Projekt hochladen
4. GitHub Actions → Workflows → Build APK ausführen
5. APK herunterladen und auf Samsung Galaxy S24 Ultra installieren

## Erstinstallation

1. APK installieren
2. App starten → Setup durchführen
3. CEO Host Mode wählen
4. M.2 SSD (exFAT) via USB-C OTG anschließen
5. JayJay KI einlernen (3+ Stimm-Samples)
6. Host aktivieren

## Features

- JayJay KI (GPT-4o-mini, Whisper, Voice-Print)
- Bluetooth Mesh + WiFi Mesh + Onion Routing + WireGuard
- Bitcoin Hardware Wallet (Ledger Nano S/X)
- 3D Gebäude-Overlay mit Heatmap
- Verteiltes Computing über Mesh-Netzwerk
- Zero-Trust Security (AES-256-GCM, JWT)
