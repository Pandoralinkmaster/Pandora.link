package com.pandora

import android.content.Intent
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.runtime.*
import com.pandora.core.ConfigManager
import com.pandora.core.SetupStatus
import com.pandora.database.SsdStorageManager
import com.pandora.jayjay.VoicePrintManager
import com.pandora.ui.screens.PandoraNavHost
import com.pandora.ui.screens.SetupScreen
import com.pandora.ui.theme.PandoraTheme
import org.koin.android.ext.android.inject

class MainActivity : ComponentActivity() {

 private val config: ConfigManager by inject()
 private val ssd: SsdStorageManager by inject()
 private val voicePrint: VoicePrintManager by inject()

 private val ssdPickerLauncher = registerForActivityResult(
 ActivityResultContracts.OpenDocumentTree()
 ) { uri ->
 uri?.let {
 contentResolver.takePersistableUriPermission(
 it, Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION
 )
 config.ssdUriString = it.toString()
 ssd.initialize(it)
 config.updateSetupStatus(SetupStatus.SSD_SELECTED)
 }
 }

 override fun onCreate(savedInstanceState: Bundle?) {
 super.onCreate(savedInstanceState)

 // Start Host Service
 startService(Intent(this, com.pandora.core.PandoraHostService::class.java))

 // Load voice print
 voicePrint.loadVoicePrint("finn.jona.lischke")

 setContent {
 PandoraTheme {
 var showSetup by remember { mutableStateOf(config.isFirstSetup()) }

 if (showSetup) {
 SetupScreen(
 config = config,
 onRequestSsdPicker = { ssdPickerLauncher.launch(null) },
 onSetupComplete = {
 config.updateSetupStatus(SetupStatus.SETUP_COMPLETE)
 showSetup = false
 }
 )
 } else {
 PandoraNavHost()
 }
 }
 }
 }
}
