package com.pandora

import android.app.Application
import com.pandora.di.appModule
import org.koin.android.ext.koin.androidContext
import org.koin.core.context.startKoin

class PandoraApplication : Application() {
 override fun onCreate() {
 super.onCreate()
 startKoin {
 androidContext(this@PandoraApplication)
 modules(appModule)
 }
 }
}
