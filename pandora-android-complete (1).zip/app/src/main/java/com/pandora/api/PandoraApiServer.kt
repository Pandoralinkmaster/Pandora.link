package com.pandora.api

import com.pandora.core.ConfigManager
import com.pandora.database.PandoraDatabase
import com.pandora.mesh.BluetoothMeshManager
import com.pandora.security.SecurityModule
import io.ktor.http.*
import io.ktor.serialization.kotlinx.json.*
import io.ktor.server.application.*
import io.ktor.server.engine.*
import io.ktor.server.netty.*
import io.ktor.server.plugins.contentnegotiation.*
import io.ktor.server.plugins.cors.routing.*
import io.ktor.server.request.*
import io.ktor.server.response.*
import io.ktor.server.routing.*
import io.ktor.server.websocket.*
import io.ktor.websocket.*
import kotlinx.coroutines.*
import kotlinx.serialization.Serializable
import kotlinx.serialization.json.Json
import java.util.concurrent.TimeUnit

@Serializable
data class ApiResponse(val success: Boolean, val message: String = "", val data: String = "")

@Serializable
data class RegisterRequest(val deviceId: String, val name: String, val model: String, val role: String = "client")

@Serializable
data class AuthRequest(val deviceId: String, val token: String)

@Serializable
data class ProductResponse(val products: List<com.pandora.database.entity.Product> = emptyList())

class PandoraApiServer(
 private val config: ConfigManager,
 private val db: PandoraDatabase,
 private val security: SecurityModule,
 private val btMesh: BluetoothMeshManager,
) {

 private var server: NettyApplicationEngine? = null
 private val scope = CoroutineScope(Dispatchers.IO + SupervisorJob())
 private val json = Json { ignoreUnknownKeys = true }

 fun start() {
 server = embeddedServer(Netty, port = config.config.apiPort) {
 install(ContentNegotiation) { json(json) }
 install(CORS) {
 anyHost()
 allowMethod(HttpMethod.Get)
 allowMethod(HttpMethod.Post)
 allowHeader(HttpHeaders.ContentType)
 }
 install(WebSockets)

 routing {
 get("/") {
 call.respond(ApiResponse(true, "Pandora API v1.0.0"))
 }
 get("/status") {
 call.respond(ApiResponse(true, "Host aktiv", "${config.ceoName} | ${config.appMode.name}"))
 }
 post("/register") {
 val req = call.receive<RegisterRequest>()
 val device = com.pandora.database.entity.Device(
 deviceId = req.deviceId,
 name = req.name,
 model = req.model,
 role = req.role,
 )
 db.deviceDao().upsert(device)
 val token = security.generateToken(req.deviceId, req.role)
 call.respond(ApiResponse(true, "Registriert", token))
 }
 post("/auth") {
 val req = call.receive<AuthRequest>()
 val valid = security.validateToken(req.token)
 call.respond(ApiResponse(valid, if (valid) "Autorisiert" else "Ungültig"))
 }
 get("/products") {
 val products = db.productDao().visibleTo(0)
 call.respond(ProductResponse(products))
 }
 post("/orders") {
 call.respond(ApiResponse(true, "Bestellung eingegangen"))
 }
 post("/mesh/heartbeat") {
 val params = call.receiveParameters()
 val nodeId = params["nodeId"] ?: ""
 btMesh.state.value.peers.find { it == nodeId }
 call.respond(ApiResponse(true, "Heartbeat empfangen"))
 }
 webSocket("/ws") {
 for (frame in incoming) {
 when (frame) {
 is Frame.Text -> {
 val text = frame.readText()
 send("Echo: $text")
 }
 else -> {}
 }
 }
 }
 get("/admin/devices") {
 val devices = db.deviceDao().authorized()
 call.respond(ApiResponse(true, "${devices.size} Geräte", devices.toString()))
 }
 post("/compute/register") {
 call.respond(ApiResponse(true, "Compute-Node registriert"))
 }
 }
 }.start(wait = false)
 }

 fun stop() {
 server?.stop(1, 5, TimeUnit.SECONDS)
 scope.cancel()
 }
}
