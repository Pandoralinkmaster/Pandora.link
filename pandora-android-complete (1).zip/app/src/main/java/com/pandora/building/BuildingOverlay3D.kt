package com.pandora.building

import android.util.Log
import com.pandora.database.BuildingDao
import com.pandora.database.entity.Building
import com.pandora.database.entity.Floor
import com.pandora.database.entity.Room
import com.pandora.scan.ScanModule
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow

class BuildingOverlay3D(
 private val buildingDao: BuildingDao,
 private val scanModule: ScanModule,
) {

 private val _state = MutableStateFlow<Building?>(null)
 val state: StateFlow<Building?> = _state
 private val scope = CoroutineScope(Dispatchers.IO + SupervisorJob())

 fun registerBuilding(buildingId: String, name: String, floors: Int, address: String = "") {
 val building = Building(
 buildingId = buildingId,
 name = name,
 floors = floors,
 address = address,
 )
 scope.launch {
 buildingDao.upsert(building)
 }
 _state.value = building
 Log.i("Building3D", "Building registriert: $name, $floors Etagen")
 }

 fun addFloor(buildingId: String, floorNumber: Int, name: String = "") {
 val floor = Floor(
 buildingId = buildingId,
 floorNumber = floorNumber,
 name = name,
 )
 scope.launch {
 buildingDao.upsertFloor(floor)
 }
 Log.i("Building3D", "Etage hinzugefügt: $floorNumber")
 }

 fun addRoom(floorId: Int, roomId: String, name: String, type: String = "room") {
 val room = Room(
 floorId = floorId,
 roomId = roomId,
 buildingId = _state.value?.buildingId ?: "",
 name = name,
 type = type,
 )
 scope.launch {
 buildingDao.upsertRoom(room)
 }
 Log.i("Building3D", "Raum hinzugefügt: $name")
 }

 fun detectPresence(buildingId: String): Boolean {
 // BEFEHL: Implementiere Anwesenheitserkennung basierend auf Scan-Daten
 val scanResult = scanModule.state.value
 return if (scanResult != null) {
 scanResult.presenceScore > 0.5f
 } else {
 false
 }
 }

 fun destroy() { scope.cancel() }
}
