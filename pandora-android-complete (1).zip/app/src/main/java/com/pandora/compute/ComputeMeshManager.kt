package com.pandora.compute

import android.content.Context
import android.util.Log
import com.pandora.database.ComputeDao
import com.pandora.database.entity.ComputeNode
import com.pandora.database.entity.ComputeTask
import com.pandora.security.SecurityModule
import kotlinx.coroutines.*

class ComputeMeshManager(
 private val context: Context,
 private val computeDao: ComputeDao,
 private val security: SecurityModule,
) {

 private val scope = CoroutineScope(Dispatchers.IO + SupervisorJob())

 fun registerNode(node: ComputeNode) {
 scope.launch {
 computeDao.upsertNode(node)
 Log.i("ComputeMesh", "Node registriert: ${node.nodeId}")
 }
 }

 fun submitTask(task: ComputeTask) {
 scope.launch {
 computeDao.upsertTask(task)
 Log.i("ComputeMesh", "Task eingereicht: ${task.taskId}")
 distributeTasks()
 }
 }

 private fun distributeTasks() {
 scope.launch {
 val pending = computeDao.pendingTasks()
 val active = computeDao.active()
 if (pending.isEmpty() || active.isEmpty()) return@launch

 // BEFEHL: Implementiere Task-Verteilung an aktive Nodes
 // Round-Robin Verteilung: Jeder aktive Node bekommt einen Task
 pending.forEachIndexed { index, task ->
 val nodeIndex = index % active.size
 val node = active[nodeIndex]

 // Simuliere Task-Ausführung
 delay(1000)
 val result = "Task ${task.taskId} verarbeitet von Node ${node.nodeId}"

 computeDao.completeTask(
 task.taskId,
 "completed",
 result,
 System.currentTimeMillis()
 )
 Log.i("ComputeMesh", "Task ${task.taskId} verteilt an ${node.nodeId}")
 }
 }
 }

 fun destroy() { scope.cancel() }
}
