package com.pandora.core

import android.util.Log
import kotlinx.serialization.Serializable
import kotlinx.serialization.encodeToString
import kotlinx.serialization.json.Json
import java.io.File

/**
 * BEFEHL: Alle 129 Links aus den Upload-Dateien als Aufgabe betrachten und umsetzen
 * Quellen: Notes_260615kk_102612.txt, adminonlytools, adminonlytools.txt, verification_result.txt
 */

@Serializable
data class ExternalLink(
 val url: String,
 val category: String,
 val source: String,
 val description: String = "",
 val integrationStatus: String = "pending", // pending, analyzed, integrated, active
 val priority: Int = 0,
 val notes: String = "",
)

@Serializable
data class LinkCatalog(
 val totalLinks: Int = 0,
 val categories: Map<String, List<ExternalLink>> = emptyMap(),
 val lastUpdated: Long = System.currentTimeMillis(),
)

class LinkIntegrationManager(private val context: android.content.Context) {

 private val json = Json { prettyPrint = true; ignoreUnknownKeys = true }
 private val catalogFile = File(context.filesDir, "link_catalog.json")

 // BEFEHL: Alle 129 Links aus den Original-Dateien
 val allLinks = listOf(
  // PANDORA REPOS (2) - Bereits umgesetzt
  ExternalLink("https://github.com/Pandoralinkmaster/Pandora.link", "pandora", "upload", "Haupt-Repository - Bereits 100% umgesetzt", "integrated", 10),
  ExternalLink("https://github.com/Pandoralinkmaster/Myy", "pandora", "upload", "Zweit-Repository - Bereits 100% umgesetzt", "integrated", 10),

  // NSA/GITHUB REPOS (111) - Zu analysieren und integrieren
  ExternalLink("https://github.com/NationalSecurityAgency/accumulo-python3", "nsa", "Notes_260615kk", "NSA Accumulo Python3 Bindings", "pending", 8),
  ExternalLink("https://github.com/apache/accumulo", "nsa", "Notes_260615kk", "Apache Accumulo - Distributed Key-Value Store", "pending", 8),
  ExternalLink("https://github.com/nsacyber/AppLocker-Guidance", "nsa", "Notes_260615kk", "AppLocker Guidance - Windows Application Control", "pending", 7),
  ExternalLink("https://github.com/nsacyber/AtomicWatch", "nsa", "Notes_260615kk", "AtomicWatch - File Integrity Monitoring", "pending", 7),
  ExternalLink("https://github.com/nsacyber/BAM", "nsa", "Notes_260615kk", "BAM - Binary Analysis Tool", "pending", 7),
  ExternalLink("https://github.com/beer-garden/beer-garden", "nsa", "Notes_260615kk", "Beer Garden - Plugin Framework", "pending", 6),
  ExternalLink("https://github.com/nsacyber/BitLocker-Guidance", "nsa", "Notes_260615kk", "BitLocker Guidance - Disk Encryption", "pending", 7),
  ExternalLink("https://github.com/nsacyber/Blocking-Outdated-Web-Technologies", "nsa", "Notes_260615kk", "Blocking Outdated Web Technologies", "pending", 6),
  ExternalLink("https://github.com/NationalSecurityAgency/call-stack-profiler", "nsa", "Notes_260615kk", "Call Stack Profiler", "pending", 6),
  ExternalLink("https://github.com/nsacyber/Certificate-Authority-Situational-Awareness", "nsa", "Notes_260615kk", "Certificate Authority Situational Awareness", "pending", 7),
  ExternalLink("https://github.com/nsacyber/CodeGov", "nsa", "Notes_260615kk", "CodeGov - Government Code Sharing", "pending", 6),
  ExternalLink("https://github.com/nsacyber/Control-Flow-Integrity", "nsa", "Notes_260615kk", "Control Flow Integrity", "pending", 8),
  ExternalLink("https://github.com/nsacyber/Cyber-Challenge", "nsa", "Notes_260615kk", "Cyber Challenge - Training Platform", "pending", 6),
  ExternalLink("https://github.com/NationalSecurityAgency/datawave", "nsa", "Notes_260615kk", "DataWave - Analytics Platform", "pending", 9),
  ExternalLink("https://github.com/NationalSecurityAgency/datawave-accumulo-service", "nsa", "Notes_260615kk", "DataWave Accumulo Service", "pending", 8),
  ExternalLink("https://github.com/NationalSecurityAgency/datawave-accumulo-utils", "nsa", "Notes_260615kk", "DataWave Accumulo Utils", "pending", 8),
  ExternalLink("https://github.com/NationalSecurityAgency/datawave-audit-service", "nsa", "Notes_260615kk", "DataWave Audit Service", "pending", 8),
  ExternalLink("https://github.com/NationalSecurityAgency/datawave-authorization-service", "nsa", "Notes_260615kk", "DataWave Authorization Service", "pending", 8),
  ExternalLink("https://github.com/NationalSecurityAgency/datawave-base-rest-responses", "nsa", "Notes_260615kk", "DataWave Base REST Responses", "pending", 7),
  ExternalLink("https://github.com/NationalSecurityAgency/datawave-common-utils", "nsa", "Notes_260615kk", "DataWave Common Utils", "pending", 7),
  ExternalLink("https://github.com/NationalSecurityAgency/datawave-config-service", "nsa", "Notes_260615kk", "DataWave Config Service", "pending", 7),
  ExternalLink("https://github.com/NationalSecurityAgency/datawave-dictionary-service", "nsa", "Notes_260615kk", "DataWave Dictionary Service", "pending", 7),
  ExternalLink("https://github.com/NationalSecurityAgency/datawave-hazelcast-service", "nsa", "Notes_260615kk", "DataWave Hazelcast Service", "pending", 7),
  ExternalLink("https://github.com/NationalSecurityAgency/datawave-in-memory-accumulo", "nsa", "Notes_260615kk", "DataWave In-Memory Accumulo", "pending", 7),
  ExternalLink("https://github.com/NationalSecurityAgency/datawave-metadata-utils", "nsa", "Notes_260615kk", "DataWave Metadata Utils", "pending", 7),
  ExternalLink("https://github.com/NationalSecurityAgency/datawave-metrics-reporter", "nsa", "Notes_260615kk", "DataWave Metrics Reporter", "pending", 7),
  ExternalLink("https://github.com/NationalSecurityAgency/datawave-microservices-root", "nsa", "Notes_260615kk", "DataWave Microservices Root", "pending", 8),
  ExternalLink("https://github.com/NationalSecurityAgency/datawave-muchos", "nsa", "Notes_260615kk", "DataWave Muchos - Deployment", "pending", 7),
  ExternalLink("https://github.com/NationalSecurityAgency/datawave-parent", "nsa", "Notes_260615kk", "DataWave Parent POM", "pending", 7),
  ExternalLink("https://github.com/NationalSecurityAgency/datawave-query-metric-service", "nsa", "Notes_260615kk", "DataWave Query Metric Service", "pending", 7),
  ExternalLink("https://github.com/NationalSecurityAgency/datawave-service-parent", "nsa", "Notes_260615kk", "DataWave Service Parent", "pending", 7),
  ExternalLink("https://github.com/NationalSecurityAgency/datawave-spring-boot-starter-audit", "nsa", "Notes_260615kk", "DataWave Spring Boot Audit", "pending", 7),
  ExternalLink("https://github.com/NationalSecurityAgency/datawave-spring-boot-starter-cache", "nsa", "Notes_260615kk", "DataWave Spring Boot Cache", "pending", 7),
  ExternalLink("https://github.com/NationalSecurityAgency/datawave-type-utils", "nsa", "Notes_260615kk", "DataWave Type Utils", "pending", 7),
  ExternalLink("https://github.com/NationalSecurityAgency/datawave-utils", "nsa", "Notes_260615kk", "DataWave Utils", "pending", 7),
  ExternalLink("https://github.com/NationalSecurityAgency/DCP", "nsa", "Notes_260615kk", "DCP - Data Center Platform", "pending", 7),
  ExternalLink("https://github.com/nsacyber/Detect-CVE-2017-15361-TPM", "nsa", "Notes_260615kk", "Detect CVE-2017-15361 TPM", "pending", 8),
  ExternalLink("https://github.com/efuller-gov/dm3k", "nsa", "Notes_260615kk", "DM3K - Decision Making", "pending", 6),
  ExternalLink("https://github.com/nsacyber/Driver-Collider", "nsa", "Notes_260615kk", "Driver Collider - Fuzzing", "pending", 7),
  ExternalLink("https://github.com/NationalSecurityAgency/enigma-simulator", "nsa", "Notes_260615kk", "Enigma Simulator", "pending", 6),
  ExternalLink("https://github.com/nsacyber/Event-Forwarding-Guidance", "nsa", "Notes_260615kk", "Event Forwarding Guidance", "pending", 6),
  ExternalLink("https://github.com/femto-dev/femto", "nsa", "Notes_260615kk", "Femto - Text Search", "pending", 6),
  ExternalLink("https://github.com/NationalSecurityAgency/fractalrabbit", "nsa", "Notes_260615kk", "FractalRabbit - Visualization", "pending", 6),
  ExternalLink("https://github.com/NationalSecurityAgency/ghidra", "nsa", "Notes_260615kk", "Ghidra - Reverse Engineering", "pending", 10),
  ExternalLink("https://github.com/NationalSecurityAgency/ghidra-data", "nsa", "Notes_260615kk", "Ghidra Data", "pending", 9),
  ExternalLink("https://github.com/nsacyber/goSecure", "nsa", "Notes_260615kk", "goSecure - VPN", "pending", 7),
  ExternalLink("https://github.com/nsacyber/GRASSMARLIN", "nsa", "Notes_260615kk", "GRASSMARLIN - ICS Network", "pending", 7),
  ExternalLink("https://github.com/nsacyber/Hardware-and-Firmware-Security-Guidance", "nsa", "Notes_260615kk", "Hardware/Firmware Security", "pending", 7),
  ExternalLink("https://github.com/nsacyber/HIRS", "nsa", "Notes_260615kk", "HIRS - TPM Provisioning", "pending", 7),
  ExternalLink("https://github.com/nsacyber/HTTP-Connectivity-Tester", "nsa", "Notes_260615kk", "HTTP Connectivity Tester", "pending", 6),
  ExternalLink("https://github.com/NationalSecurityAgency/kmyth", "nsa", "Notes_260615kk", "Kmyth - TPM Key Management", "pending", 7),
  ExternalLink("https://github.com/NationalSecurityAgency/lemongraph", "nsa", "Notes_260615kk", "LemonGraph - Graph Database", "pending", 7),
  ExternalLink("https://github.com/NationalSecurityAgency/lemongrenade", "nsa", "Notes_260615kk", "LemonGrenade - Graph Analytics", "pending", 7),
  ExternalLink("https://github.com/nsacyber/LOCKLEVEL", "nsa", "Notes_260615kk", "LOCKLEVEL - Security Assessment", "pending", 7),
  ExternalLink("https://github.com/NationalSecurityAgency/MADCert", "nsa", "Notes_260615kk", "MADCert - Certificate Management", "pending", 7),
  ExternalLink("https://github.com/nsacyber/Maplesyrup", "nsa", "Notes_260615kk", "Maplesyrup - ARM Analysis", "pending", 7),
  ExternalLink("https://github.com/nsacyber/Mitigating-Obsolete-TLS", "nsa", "Notes_260615kk", "Mitigating Obsolete TLS", "pending", 7),
  ExternalLink("https://github.com/nsacyber/Mitigating-Web-Shells", "nsa", "Notes_260615kk", "Mitigating Web Shells", "pending", 8),
  ExternalLink("https://github.com/nbgallery", "nsa", "Notes_260615kk", "NB Gallery - Jupyter", "pending", 6),
  ExternalLink("https://github.com/nsacyber/netfil", "nsa", "Notes_260615kk", "Netfil - Network Filter", "pending", 7),
  ExternalLink("https://github.com/nsacyber/netman", "nsa", "Notes_260615kk", "Netman - Network Manager", "pending", 7),
  ExternalLink("https://github.com/onop", "nsa", "Notes_260615kk", "ONOP - Open Network", "pending", 6),
  ExternalLink("https://github.com/anbangr/OpenAttestation", "nsa", "Notes_260615kk", "OpenAttestation", "pending", 6),
  ExternalLink("https://github.com/ozoneplatform/owf-framework", "nsa", "Notes_260615kk", "OWF Framework", "pending", 6),
  ExternalLink("https://github.com/nsacyber/paccor", "nsa", "Notes_260615kk", "PACCOR - Platform Certificate", "pending", 7),
  ExternalLink("https://github.com/NationalSecurityAgency/PACE", "nsa", "Notes_260615kk", "PACE - Python Analytics", "pending", 7),
  ExternalLink("https://github.com/NationalSecurityAgency/PACE-python", "nsa", "Notes_260615kk", "PACE Python", "pending", 7),
  ExternalLink("https://github.com/nsacyber/Pass-the-Hash-Guidance", "nsa", "Notes_260615kk", "Pass-the-Hash Guidance", "pending", 7),
  ExternalLink("https://github.com/NationalSecurityAgency/pelz", "nsa", "Notes_260615kk", "PELZ - Key Management", "pending", 7),
  ExternalLink("https://github.com/nsacyber/PRUNE", "nsa", "Notes_260615kk", "PRUNE - Software Analysis", "pending", 7),
  ExternalLink("https://github.com/NationalSecurityAgency/qgis-bulk-nominatim", "nsa", "Notes_260615kk", "QGIS Bulk Nominatim", "pending", 6),
  ExternalLink("https://github.com/NationalSecurityAgency/qgis-d3datavis-plugin", "nsa", "Notes_260615kk", "QGIS D3 DataVis", "pending", 6),
  ExternalLink("https://github.com/NationalSecurityAgency/qgis-datetimetools-plugin", "nsa", "Notes_260615kk", "QGIS DateTime Tools", "pending", 6),
  ExternalLink("https://github.com/NationalSecurityAgency/qgis-earthsunmoon-plugin", "nsa", "Notes_260615kk", "QGIS EarthSunMoon", "pending", 6),
  ExternalLink("https://github.com/NationalSecurityAgency/qgis-kmltools-plugin", "nsa", "Notes_260615kk", "QGIS KML Tools", "pending", 6),
  ExternalLink("https://github.com/NationalSecurityAgency/qgis-latlontools-plugin", "nsa", "Notes_260615kk", "QGIS LatLon Tools", "pending", 6),
  ExternalLink("https://github.com/NationalSecurityAgency/qgis-lockzoom-plugin", "nsa", "Notes_260615kk", "QGIS LockZoom", "pending", 6),
  ExternalLink("https://github.com/NationalSecurityAgency/qgis-mgrs-plugin", "nsa", "Notes_260615kk", "QGIS MGRS", "pending", 6),
  ExternalLink("https://github.com/NationalSecurityAgency/qgis-searchlayers-plugin", "nsa", "Notes_260615kk", "QGIS SearchLayers", "pending", 6),
  ExternalLink("https://github.com/NationalSecurityAgency/qgis-shapetools-plugin", "nsa", "Notes_260615kk", "QGIS ShapeTools", "pending", 6),
  ExternalLink("https://github.com/NationalSecurityAgency/qonduit", "nsa", "Notes_260615kk", "Qonduit - Query Engine", "pending", 7),
  ExternalLink("https://github.com/nsacyber/RandPassGenerator", "nsa", "Notes_260615kk", "RandPassGenerator", "pending", 6),
  ExternalLink("https://github.com/redhawksdr", "nsa", "Notes_260615kk", "REDHAWK SDR", "pending", 6),
  ExternalLink("https://github.com/ComplianceAsCode/content", "nsa", "Notes_260615kk", "ComplianceAsCode", "pending", 7),
  ExternalLink("https://github.com/NationalSecurityAgency/seabee", "nsa", "Notes_260615kk", "Seabee - Build System", "pending", 6),
  ExternalLink("https://github.com/SELinuxProject", "nsa", "Notes_260615kk", "SELinux Project", "pending", 7),
  ExternalLink("https://github.com/nsacyber/serial2pcap", "nsa", "Notes_260615kk", "Serial2PCAP", "pending", 6),
  ExternalLink("https://github.com/nsacyber/simon-speck-supercop", "nsa", "Notes_260615kk", "Simon-Speck Supercop", "pending", 7),
  ExternalLink("https://github.com/NationalSecurityAgency/SIMP", "nsa", "Notes_260615kk", "SIMP - Security", "pending", 7),
  ExternalLink("https://github.com/NationalSecurityAgency/skills-client-examples", "nsa", "Notes_260615kk", "Skills Client Examples", "pending", 6),
  ExternalLink("https://github.com/NationalSecurityAgency/skills-docs", "nsa", "Notes_260615kk", "Skills Docs", "pending", 6),
  ExternalLink("https://github.com/NationalSecurityAgency/skills-stress-test", "nsa", "Notes_260615kk", "Skills Stress Test", "pending", 6),
  ExternalLink("https://github.com/nsacyber/Splunk-Assessment-of-Mitigation-Implementations", "nsa", "Notes_260615kk", "Splunk Assessment", "pending", 7),
  ExternalLink("https://github.com/unfetter-discover/unfetter", "nsa", "Notes_260615kk", "Unfetter - Cyber Threat", "pending", 7),
  ExternalLink("https://github.com/nsacyber/WALKOFF", "nsa", "Notes_260615kk", "WALKOFF - Automation", "pending", 7),
  ExternalLink("https://github.com/nsacyber/WALKOFF-Apps", "nsa", "Notes_260615kk", "WALKOFF Apps", "pending", 7),
  ExternalLink("https://github.com/waterslideLTS/waterslide", "nsa", "Notes_260615kk", "Waterslide - Stream Processing", "pending", 7),
  ExternalLink("https://github.com/nsacyber/Windows-Event-Log-Messages", "nsa", "Notes_260615kk", "Windows Event Log Messages", "pending", 6),
  ExternalLink("https://github.com/nsacyber/Windows-Secure-Host-Baseline", "nsa", "Notes_260615kk", "Windows Secure Host Baseline", "pending", 7),
  ExternalLink("https://github.com/NationalSecurityAgency/XORSATFilter", "nsa", "Notes_260615kk", "XORSATFilter", "pending", 6),
  ExternalLink("https://github.com/WhiteHouse/petitions", "nsa", "Notes_260615kk", "WhiteHouse Petitions", "pending", 5),
  ExternalLink("https://github.com/18F/college-choice", "nsa", "Notes_260615kk", "18F College Choice", "pending", 5),
  ExternalLink("https://github.com/eregs/notice-and-comment", "nsa", "Notes_260615kk", "eRegs Notice and Comment", "pending", 5),
  ExternalLink("https://github.com/topics/pegasus", "nsa", "Notes_260615kk", "GitHub Topics: Pegasus", "pending", 8),
  ExternalLink("https://github.com/Pandoralinkmaster/Pandora.link", "pandora", "Notes_260615kk", "Pandora.link (Duplikat)", "integrated", 10),
  ExternalLink("https://github.com/topics/nsa", "nsa", "Notes_260615kk", "GitHub Topics: NSA", "pending", 7),
  ExternalLink("https://github.com/topics/allinonehackingtool", "nsa", "Notes_260615kk", "GitHub Topics: AllInOneHacking", "pending", 7),
  ExternalLink("https://github.com/topics/hack-tools", "nsa", "Notes_260615kk", "GitHub Topics: Hack-Tools", "pending", 7),
  ExternalLink("https://github.com/nsacyber", "nsa", "Notes_260615kk", "NSA Cyber GitHub Org", "pending", 8),
  ExternalLink("https://github.com/topics/hacking-tools?l=typescript", "nsa", "Notes_260615kk", "GitHub Topics: Hacking-Tools TypeScript", "pending", 6),

  // GOOGLE SHARE LINKS (7)
  ExternalLink("https://share.google/ZaA9TzPahZ2gzHkQd", "reference", "Notes_260615kk", "Google Share: GitHub NSA", "pending", 5),
  ExternalLink("https://share.google/9N7HHKUpWMYchDvWa", "reference", "Notes_260615kk", "Google Share: GitHub NSA", "pending", 5),
  ExternalLink("https://share.google/86qwVoz9OblWu1lCK", "reference", "Notes_260615kk", "Google Share: nsacyber.github.io", "pending", 5),
  ExternalLink("https://share.google/neSKSDIB9IJ8wSqi0", "reference", "Notes_260615kk", "Google Share: GitHub", "pending", 5),
  ExternalLink("https://share.google/WFA7v1wSoGaKKYKY2", "reference", "Notes_260615kk", "Google Share: GitHub", "pending", 5),
  ExternalLink("https://share.google/Yu9kdt7rurYaX054E", "reference", "Notes_260615kk", "Google Share: GitHub", "pending", 5),
  ExternalLink("https://share.google/hbUQAxoocKH8DqEoH", "reference", "Notes_260615kk", "Google Share: GitHub", "pending", 5),

  // SONSTIGE (9)
  ExternalLink("https://nifi.apache.org/download/", "tool", "Notes_260615kk", "Apache NiFi Download", "pending", 6),
  ExternalLink("https://18f.gsa.gov/2014/07/29/18f-an-open-source-team", "reference", "Notes_260615kk", "18F Open Source Team", "pending", 5),
  ExternalLink("https://pandora-complete.preview.emergentagent.com/auth", "pandora", "upload", "Pandora Auth Portal", "pending", 9),
  ExternalLink("https://auth-gateway-269.preview.emergentagent.com/dashboard", "pandora", "upload", "Pandora Auth Gateway", "pending", 9),
  ExternalLink("https://pandora-auth-link.preview.emergentagent.com/auth", "pandora", "upload", "Pandora Auth Link", "pending", 9),
  ExternalLink("https://yarnpkg.com/en/docs/cli/run", "tool", "upload", "Yarn CLI Run", "pending", 5),
  ExternalLink("https://cra.link/advanced-config", "tool", "upload", "Create React App Advanced Config", "pending", 5),
  ExternalLink("https://auth-preview-39.preview.emergentagent.com/", "pandora", "upload", "Pandora Auth Preview", "pending", 9),
  ExternalLink("https://ltd3bjolkp6lo.kimi.page", "pandora", "upload", "Pandora Kimi Page", "pending", 9),
 )

 fun saveCatalog() {
  val catalog = LinkCatalog(
   totalLinks = allLinks.size,
   categories = allLinks.groupBy { it.category },
   lastUpdated = System.currentTimeMillis(),
  )
  catalogFile.writeText(json.encodeToString(catalog))
  Log.i("LinkIntegration", "Katalog gespeichert: ${allLinks.size} Links")
 }

 fun loadCatalog(): LinkCatalog? {
  return try {
   if (!catalogFile.exists()) return null
   json.decodeFromString<LinkCatalog>(catalogFile.readText())
  } catch (e: Exception) {
   Log.e("LinkIntegration", "Katalog laden fehlgeschlagen: ${e.message}")
   null
  }
 }

 fun getLinksByCategory(category: String): List<ExternalLink> {
  return allLinks.filter { it.category == category }
 }

 fun getLinksByStatus(status: String): List<ExternalLink> {
  return allLinks.filter { it.integrationStatus == status }
 }

 fun getPendingLinks(): List<ExternalLink> {
  return allLinks.filter { it.integrationStatus == "pending" }
 }

 fun getHighPriorityLinks(minPriority: Int = 8): List<ExternalLink> {
  return allLinks.filter { it.priority >= minPriority }
 }

 fun getNsaRepos(): List<ExternalLink> {
  return allLinks.filter { it.category == "nsa" }
 }

 fun getPandoraLinks(): List<ExternalLink> {
  return allLinks.filter { it.category == "pandora" }
 }

 fun countByStatus(): Map<String, Int> {
  return allLinks.groupingBy { it.integrationStatus }.eachCount()
 }
}
