package com.pandora.core

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Intent
import android.os.IBinder
import android.util.Log
import androidx.core.app.NotificationCompat
import com.pandora.api.PandoraApiServer
import com.pandora.database.SsdStorageManager
import com.pandora.mesh.BluetoothMeshManager
import com.pandora.mesh.WifiMeshManager
import kotlinx.coroutines.*
import org.koin.android.ext.android.inject

class PandoraHostService : Service() {

 companion object {
 const val CHANNEL_ID = "pandora_host_channel"
 const val NOTIFICATION_ID = 1000
 }

 private val apiServer: PandoraApiServer by inject()
 private val btMesh: BluetoothMeshManager by inject()
 private val wifiMesh: WifiMeshManager by inject()
 private val ssd: SsdStorageManager by inject()

 private val scope = CoroutineScope(Dispatchers.IO + SupervisorJob())

 override fun onCreate() {
 super.onCreate()
 createNotificationChannel()
 Log.i("PandoraHost", "Host Service erstellt")
 }

 override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
 startForeground(NOTIFICATION_ID, buildNotification())

 // Start API Server
 scope.launch { apiServer.start() }

 // Start Mesh Networks
 btMesh.initialize()
 wifiMesh.initialize()

 // DB Backup every 15 minutes
 scope.launch {
 while (isActive) {
 delay(15 * 60 * 1000L)
 ssd.backupDatabase()
 Log.i("PandoraHost", "DB-Backup durchgeführt")
 }
 }

 Log.i("PandoraHost", "Host Service gestartet - API, Mesh, Backup aktiv")
 return START_STICKY
 }

 override fun onBind(intent: Intent?): IBinder? = null

 private fun createNotificationChannel() {
 val channel = NotificationChannel(
 CHANNEL_ID,
 "Pandora Host",
 NotificationManager.IMPORTANCE_LOW
 ).apply {
 description = "Pandora CEO Host Service"
 }
 val manager = getSystemService(NotificationManager::class.java)
 manager.createNotificationChannel(channel)
 }

 private fun buildNotification(): Notification {
 return NotificationCompat.Builder(this, CHANNEL_ID)
 .setContentTitle("Pandora Host")
 .setContentText("CEO Host aktiv · API · Mesh · Backup")
 .setSmallIcon(android.R.drawable.ic_dialog_info)
 .setOngoing(true)
 .build()
 }

 override fun onDestroy() {
 scope.cancel()
 apiServer.stop()
 btMesh.stopAll()
 super.onDestroy()
 Log.i("PandoraHost", "Host Service beendet")
 }
}
