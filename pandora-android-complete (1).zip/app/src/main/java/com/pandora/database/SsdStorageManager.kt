package com.pandora.database

import android.content.Context
import android.net.Uri
import android.util.Log
import androidx.documentfile.provider.DocumentFile
import com.pandora.core.ConfigManager
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream

class SsdStorageManager(
 private val context: Context,
 private val config: ConfigManager,
) {

 private var ssdRoot: DocumentFile? = null
 private val internalDbPath = File(context.getDatabasePath("pandora.db").parent ?: "", "pandora.db")

 companion object {
 val FOLDERS = listOf(
 "backups", "exports", "logs", "voice_prints", "memory",
 "products", "orders", "receipts", "chat", "mesh",
 "security", "compute", "scan", "building", "overlays",
 "onion", "wireguard", "temp"
 )
 }

 fun initialize(uri: Uri) {
 ssdRoot = DocumentFile.fromTreeUri(context, uri)
 ssdRoot?.let { root ->
 FOLDERS.forEach { folderName ->
 if (root.findFile(folderName) == null) {
 root.createDirectory(folderName)
 Log.i("SsdStorage", "Ordner erstellt: $folderName")
 }
 }
 }
 Log.i("SsdStorage", "SSD initialisiert: ${ssdRoot?.uri}")
 }

 fun getFolder(name: String): DocumentFile? {
 return ssdRoot?.findFile(name)
 }

 fun getDatabasePath(): String = internalDbPath.absolutePath

 fun getBackupsDir(): File = File(context.filesDir, "backups").also { it.mkdirs() }
 fun getVoicePrintsDir(): File = File(context.filesDir, "voice_prints").also { it.mkdirs() }
 fun getMemoryDir(): File = File(context.filesDir, "memory").also { it.mkdirs() }
 fun getLogsDir(): File = File(context.filesDir, "logs").also { it.mkdirs() }
 fun getExportsDir(): File = File(context.filesDir, "exports").also { it.mkdirs() }
 fun getMeshDir(): File = File(context.filesDir, "mesh").also { it.mkdirs() }
 fun getSecurityDir(): File = File(context.filesDir, "security").also { it.mkdirs() }
 fun getComputeDir(): File = File(context.filesDir, "compute").also { it.mkdirs() }
 fun getScanDir(): File = File(context.filesDir, "scan").also { it.mkdirs() }
 fun getBuildingDir(): File = File(context.filesDir, "building").also { it.mkdirs() }
 fun getOverlaysDir(): File = File(context.filesDir, "overlays").also { it.mkdirs() }
 fun getOnionDir(): File = File(context.filesDir, "onion").also { it.mkdirs() }
 fun getWireguardDir(): File = File(context.filesDir, "wireguard").also { it.mkdirs() }
 fun getTempDir(): File = File(context.filesDir, "temp").also { it.mkdirs() }

 suspend fun backupDatabase(): Boolean = withContext(Dispatchers.IO) {
 try {
 val dbFile = File(context.getDatabasePath("pandora.db").path)
 val backupFile = File(getBackupsDir(), "pandora_backup_${System.currentTimeMillis()}.db")
 FileInputStream(dbFile).use { input ->
 FileOutputStream(backupFile).use { output ->
 input.copyTo(output)
 }
 }
 Log.i("SsdStorage", "DB-Backup erstellt: ${backupFile.name}")
 true
 } catch (e: Exception) {
 Log.e("SsdStorage", "Backup fehlgeschlagen: ${e.message}")
 false
 }
 }

 suspend fun restoreDatabase(backupFile: File): Boolean = withContext(Dispatchers.IO) {
 try {
 val dbFile = File(context.getDatabasePath("pandora.db").path)
 FileInputStream(backupFile).use { input ->
 FileOutputStream(dbFile).use { output ->
 input.copyTo(output)
 }
 }
 Log.i("SsdStorage", "DB-Restore erfolgreich")
 true
 } catch (e: Exception) {
 Log.e("SsdStorage", "Restore fehlgeschlagen: ${e.message}")
 false
 }
 }

 fun writeFile(folderName: String, fileName: String, content: String) {
 getFolder(folderName)?.let { folder ->
 folder.findFile(fileName)?.delete()
 folder.createFile("text/plain", fileName)?.let { file ->
 context.contentResolver.openOutputStream(file.uri)?.use { stream ->
 stream.write(content.toByteArray())
 }
 }
 }
 }

 fun readFile(folderName: String, fileName: String): String? {
 return getFolder(folderName)?.findFile(fileName)?.let { file ->
 context.contentResolver.openInputStream(file.uri)?.use { stream ->
 stream.readBytes().toString(Charsets.UTF_8)
 }
 }
 }
}
