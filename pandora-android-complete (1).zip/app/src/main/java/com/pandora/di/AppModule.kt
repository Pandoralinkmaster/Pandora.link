package com.pandora.di

import com.pandora.api.PandoraApiServer
import com.pandora.building.BuildingOverlay3D
import com.pandora.compute.ComputeMeshManager
import com.pandora.core.ConfigManager
import com.pandora.core.InfiltrationService
import com.pandora.core.LinkIntegrationManager
import com.pandora.database.PandoraDatabase
import com.pandora.database.SsdStorageManager
import com.pandora.jayjay.JayJayEngine
import com.pandora.jayjay.JayJayLearningEngine
import com.pandora.jayjay.VoicePrintManager
import com.pandora.mesh.BluetoothMeshManager
import com.pandora.mesh.MeshOnionRouter
import com.pandora.mesh.WifiMeshManager
import com.pandora.onion.OnionModule
import com.pandora.scan.ScanModule
import com.pandora.security.SecurityModule
import com.pandora.visibility.HostVisibilityGate
import com.pandora.wireguard.WireGuardModule
import org.koin.android.ext.koin.androidContext
import org.koin.dsl.module

val appModule = module {

 // BEFEHL: Core - Registriere alle Kernkomponenten
 single { ConfigManager.getInstance(androidContext()) }
 single { SecurityModule() }

 // BEFEHL: Storage – M.2 SSD (exFAT) via SAF - Registriere SSD-Storage
 single { SsdStorageManager(androidContext(), get()) }
 single { PandoraDatabase.getInstance(androidContext(), get().getDatabasePath()) }

 // BEFEHL: Visibility Gate - Registriere Host-Sperre
 single { HostVisibilityGate(get()) }

 // BEFEHL: Network - Registriere alle Netzwerk-Module
 single { BluetoothMeshManager(androidContext()) }
 single { WifiMeshManager(androidContext()) }
 single { MeshOnionRouter(get()) }
 single { OnionModule(androidContext()) }
 single { WireGuardModule(androidContext()) }

 // BEFEHL: JayJay AI - Registriere KI-System
 single { VoicePrintManager(androidContext(), get()) }
 single { JayJayLearningEngine(get()) }
 single { JayJayEngine(androidContext(), get(), get(), get(), get(), get()) }

 // BEFEHL: API Server - Registriere REST/WebSocket API
 single { PandoraApiServer(get(), get(), get(), get()) }

 // BEFEHL: Features - Registriere alle Feature-Module
 single { ScanModule(androidContext(), get(), get()) }
 single { BuildingOverlay3D(get(), get()) }
 single { ComputeMeshManager(androidContext(), get(), get()) }

 // BEFEHL: AdminScreen.kt:22 - "Kontrolle über wirklich alles"
 // Registriere InfiltrationService für zentrale Systemkontrolle
 single { 
     InfiltrationService(
         get(), get(), get(), get(), get(), get(), get(), get(), get(), get(), get(), get()
     )
 }

 // BEFEHL: Alle 129 Links aus Upload-Dateien als Aufgabe betrachten
 // Registriere LinkIntegrationManager für Link-Verwaltung
 single { LinkIntegrationManager(androidContext()) }
}
