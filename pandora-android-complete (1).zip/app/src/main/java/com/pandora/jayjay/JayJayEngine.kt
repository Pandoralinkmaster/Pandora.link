package com.pandora.jayjay

import android.content.Context
import android.util.Log
import com.pandora.core.ConfigManager
import com.pandora.database.SsdStorageManager
import com.pandora.security.SecurityModule
import com.pandora.visibility.HostVisibilityGate
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.serialization.Serializable
import kotlinx.serialization.encodeToString
import kotlinx.serialization.json.Json
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONObject
import java.io.File
import java.io.FileInputStream
import java.util.concurrent.TimeUnit

@Serializable
data class JayJayState(
 val isListening: Boolean = false,
 val isProcessing: Boolean = false,
 val lastCommand: String = "",
 val chatHistory: List<ChatEntry> = emptyList(),
 val voicePrintStatus: String = "not_enrolled",
 val isCeoRecognized: Boolean = false,
)

@Serializable
data class ChatEntry(
 val text: String,
 val isUser: Boolean,
 val timestamp: Long = System.currentTimeMillis(),
)

class JayJayEngine(
 private val context: Context,
 private val config: ConfigManager,
 private val gate: HostVisibilityGate,
 private val voicePrint: VoicePrintManager,
 private val learning: JayJayLearningEngine,
 private val ssd: SsdStorageManager,
) {

 private val _state = MutableStateFlow(JayJayState())
 val state: StateFlow<JayJayState> = _state

 private val scope = CoroutineScope(Dispatchers.IO + SupervisorJob())
 private val json = Json { ignoreUnknownKeys = true }
 private val httpClient = OkHttpClient.Builder()
 .connectTimeout(30, TimeUnit.SECONDS)
 .readTimeout(60, TimeUnit.SECONDS)
 .build()

 companion object {
 const val WAKE_WORD = "pandemonium"
 const val OPENAI_API_KEY_ENV = "OPENAI_API_KEY"
 const val GPT_MODEL = "gpt-4o-mini"
 const val WHISPER_MODEL = "whisper-1"
 }

 fun processText(text: String) {
 val userEntry = ChatEntry(text, isUser = true)
 _state.value = _state.value.copy(
 chatHistory = _state.value.chatHistory + userEntry,
 isProcessing = true,
 )

 scope.launch {
 val response = when {
 text.startsWith("JayJay, lerne:", ignoreCase = true) -> {
 handleLearnCommand(text.removePrefix("JayJay, lerne:").trim())
 }
 text.startsWith("JayJay, recherchiere:", ignoreCase = true) -> {
 handleResearchCommand(text.removePrefix("JayJay, recherchiere:").trim())
 }
 text.startsWith("JayJay, lerne Befehl:", ignoreCase = true) -> {
 handleLearnCommandCommand(text.removePrefix("JayJay, lerne Befehl:").trim())
 }
 else -> handleGeneralChat(text)
 }
 val botEntry = ChatEntry(response, isUser = false)
 _state.value = _state.value.copy(
 chatHistory = _state.value.chatHistory + botEntry,
 isProcessing = false,
 )
 }
 }

 private suspend fun handleLearnCommand(input: String): String {
 val parts = input.split("=")
 if (parts.size >= 2) {
 val trigger = parts[0].trim()
 val response = parts[1].trim()
 learning.addDirectKnowledge(trigger, response)
 return "Gelernt: '$trigger' -> '$response'"
 }
 return "Lern-Format: 'Trigger = Antwort'"
 }

 private suspend fun handleResearchCommand(topic: String): String {
 return try {
 val result = learning.researchWeb(topic)
 "Recherche-Ergebnis zu '$topic': $result"
 } catch (e: Exception) {
 "Recherche fehlgeschlagen: ${e.message}"
 }
 }

 private suspend fun handleLearnCommandCommand(input: String): String {
 val parts = input.split("=")
 if (parts.size >= 2) {
 val command = parts[0].trim()
 val action = parts[1].trim()
 learning.addCustomCommand(command, action)
 return "Befehl gelernt: '$command' -> '$action'"
 }
 return "Befehl-Format: 'Befehl = Aktion'"
 }

 private suspend fun handleGeneralChat(text: String): String {
 val learned = learning.findKnowledge(text)
 if (learned != null) return learned

 val command = learning.findCustomCommand(text)
 if (command != null) return "Befehl ausgeführt: $command"

 return try {
 chatWithGpt(text)
 } catch (e: Exception) {
 "JayJay: Ich habe dich verstanden. (GPT nicht verfügbar: ${e.message})"
 }
 }

 private suspend fun chatWithGpt(prompt: String): String = withContext(Dispatchers.IO) {
 val apiKey = System.getenv(OPENAI_API_KEY_ENV) ?: ""
 if (apiKey.isBlank()) return@withContext "JayJay: GPT-API-Key nicht konfiguriert."

 val requestBody = JSONObject().apply {
 put("model", GPT_MODEL)
 put("messages", org.json.JSONArray().apply {
 put(JSONObject().apply {
 put("role", "system")
 put("content", "Du bist JayJay, die KI-Assistentin von Pandora. Du gehorchst nur dem CEO Finn Jona Lischke. Sprich auf Deutsch.")
 })
 put(JSONObject().apply {
 put("role", "user")
 put("content", prompt)
 })
 })
 put("max_tokens", 500)
 }

 val request = Request.Builder()
 .url("https://api.openai.com/v1/chat/completions")
 .header("Authorization", "Bearer $apiKey")
 .header("Content-Type", "application/json")
 .post(requestBody.toString().toRequestBody("application/json".toMediaType()))
 .build()

 val response = httpClient.newCall(request).execute()
 val body = response.body?.string() ?: ""
 if (!response.isSuccessful) return@withContext "JayJay: GPT-Fehler (${response.code})"

 val jsonResponse = JSONObject(body)
 val choices = jsonResponse.getJSONArray("choices")
 if (choices.length() > 0) {
 choices.getJSONObject(0).getJSONObject("message").getString("content")
 } else {
 "JayJay: Keine Antwort erhalten."
 }
 }

 suspend fun transcribeAudio(audioFile: File): String = withContext(Dispatchers.IO) {
 val apiKey = System.getenv(OPENAI_API_KEY_ENV) ?: ""
 if (apiKey.isBlank()) return@withContext ""

 try {
 val requestBody = okhttp3.MultipartBody.Builder()
 .setType(okhttp3.MultipartBody.FORM)
 .addFormDataPart("model", WHISPER_MODEL)
 .addFormDataPart("file", audioFile.name,
 audioFile.asRequestBody("audio/wav".toMediaType()))
 .build()

 val request = Request.Builder()
 .url("https://api.openai.com/v1/audio/transcriptions")
 .header("Authorization", "Bearer $apiKey")
 .post(requestBody)
 .build()

 val response = httpClient.newCall(request).execute()
 val body = response.body?.string() ?: ""
 if (!response.isSuccessful) return@withContext ""

 JSONObject(body).optString("text", "")
 } catch (e: Exception) {
 Log.e("JayJay", "Transkription fehlgeschlagen: ${e.message}")
 ""
 }
 }

 fun createWavHeader(sampleRate: Int, channels: Int, bitsPerSample: Int, dataSize: Int): ByteArray {
 val byteRate = sampleRate * channels * bitsPerSample / 8
 val blockAlign = channels * bitsPerSample / 8

 return ByteArray(44).apply {
 "RIFF".toByteArray().copyInto(this, 0)
 writeInt(4, 36 + dataSize)
 "WAVE".toByteArray().copyInto(this, 8)
 "fmt ".toByteArray().copyInto(this, 12)
 writeInt(16, 16)
 this[20] = 1.toByte()
 this[21] = 0
 this[22] = channels.toByte()
 this[23] = 0
 writeInt(24, sampleRate)
 writeInt(28, byteRate)
 this[32] = blockAlign.toByte()
 this[33] = 0
 this[34] = bitsPerSample.toByte()
 this[35] = 0
 "data".toByteArray().copyInto(this, 36)
 writeInt(40, dataSize)
 }
 }

 private fun ByteArray.writeInt(offset: Int, value: Int) {
 this[offset] = (value and 0xFF).toByte()
 this[offset + 1] = ((value shr 8) and 0xFF).toByte()
 this[offset + 2] = ((value shr 16) and 0xFF).toByte()
 this[offset + 3] = ((value shr 24) and 0xFF).toByte()
 }

 fun checkWakeWord(text: String): Boolean {
 return text.contains(WAKE_WORD, ignoreCase = true)
 }

 fun isCeoRecognized(audioData: ByteArray): Boolean {
 val result = voicePrint.recognize(audioData)
 _state.value = _state.value.copy(isCeoRecognized = result.recognized)
 return result.recognized && result.confidence >= 0.82
 }

 fun destroy() { scope.cancel() }
}

private fun File.asRequestBody(mediaType: okhttp3.MediaType): okhttp3.RequestBody {
 return object : okhttp3.RequestBody() {
 override fun contentType() = mediaType
 override fun contentLength() = length()
 override fun writeTo(sink: okio.BufferedSink) {
 FileInputStream(this@asRequestBody).use { source ->
 sink.writeAll(okio.source(source))
 }
 }
 }
}
