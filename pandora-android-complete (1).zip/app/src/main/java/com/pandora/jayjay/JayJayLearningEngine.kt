package com.pandora.jayjay

import android.util.Log
import com.pandora.database.SsdStorageManager
import kotlinx.coroutines.*
import kotlinx.serialization.Serializable
import kotlinx.serialization.encodeToString
import kotlinx.serialization.json.Json
import okhttp3.OkHttpClient
import okhttp3.Request
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.util.concurrent.TimeUnit

@Serializable
data class KnowledgeEntry(
 val id: String,
 val trigger: String,
 val response: String,
 val source: String = "direct",
 val timestamp: Long = System.currentTimeMillis(),
)

@Serializable
data class CustomCommand(
 val id: String,
 val command: String,
 val action: String,
 val timestamp: Long = System.currentTimeMillis(),
)

@Serializable
data class JayJayMemory(
 val knowledge: List<KnowledgeEntry> = emptyList(),
 val commands: List<CustomCommand> = emptyList(),
 val preferences: Map<String, String> = emptyMap(),
 val lastAutoLearn: Long = 0,
)

class JayJayLearningEngine(private val ssd: SsdStorageManager) {

 private val json = Json { ignoreUnknownKeys = true; prettyPrint = true }
 private val scope = CoroutineScope(Dispatchers.IO + SupervisorJob())
 private val httpClient = OkHttpClient.Builder()
 .connectTimeout(15, TimeUnit.SECONDS)
 .readTimeout(30, TimeUnit.SECONDS)
 .build()

 private var memory: JayJayMemory = loadMemory() ?: JayJayMemory()

 companion object {
 const val WIKIPEDIA_API = "https://de.wikipedia.org/api/rest_v1/page/summary/"
 const val AUTO_LEARN_INTERVAL_HOURS = 1
 }

 fun addDirectKnowledge(trigger: String, response: String) {
 val entry = KnowledgeEntry(
 id = generateId(),
 trigger = trigger.lowercase(),
 response = response,
 source = "direct",
 )
 memory = memory.copy(knowledge = memory.knowledge + entry)
 saveMemory()
 Log.i("JayJayLearning", "Direktes Wissen hinzugefügt: $trigger")
 }

 fun addCustomCommand(command: String, action: String) {
 val cmd = CustomCommand(
 id = generateId(),
 command = command.lowercase(),
 action = action,
 )
 memory = memory.copy(commands = memory.commands + cmd)
 saveMemory()
 Log.i("JayJayLearning", "Befehl gelernt: $command")
 }

 fun findKnowledge(input: String): String? {
 val query = input.lowercase()
 return memory.knowledge.find { query.contains(it.trigger) }?.response
 }

 fun findCustomCommand(input: String): String? {
 val query = input.lowercase()
 return memory.commands.find { query.contains(it.command) }?.action
 }

 suspend fun researchWeb(topic: String): String = withContext(Dispatchers.IO) {
 try {
 val request = Request.Builder()
 .url("$WIKIPEDIA_API${topic.replace(" ", "_")}")
 .build()
 val response = httpClient.newCall(request).execute()
 val body = response.body?.string() ?: ""
 if (!response.isSuccessful) return@withContext "Keine Wikipedia-Daten gefunden."

 val jsonObj = JSONObject(body)
 val extract = jsonObj.optString("extract", "")
 if (extract.isNotBlank()) {
 val summary = if (extract.length > 500) extract.substring(0, 500) + "..." else extract
 addDirectKnowledge(topic, summary)
 summary
 } else {
 "Keine Zusammenfassung gefunden."
 }
 } catch (e: Exception) {
 Log.e("JayJayLearning", "Web-Recherche fehlgeschlagen: ${e.message}")
 "Recherche fehlgeschlagen: ${e.message}"
 }
 }

 fun startAutoLearning() {
 scope.launch {
 while (isActive) {
 delay(AUTO_LEARN_INTERVAL_HOURS * 60 * 60 * 1000L)
 performAutoLearning()
 }
 }
 }

 private fun performAutoLearning() {
 Log.i("JayJayLearning", "Auto-Lernen gestartet")
 memory = memory.copy(lastAutoLearn = System.currentTimeMillis())
 saveMemory()
 }

 fun setPreference(key: String, value: String) {
 memory = memory.copy(preferences = memory.preferences + (key to value))
 saveMemory()
 }

 fun getPreference(key: String): String? = memory.preferences[key]

 private fun loadMemory(): JayJayMemory? {
 return try {
 val file = File(ssd.getMemoryDir(), "memory.json")
 if (!file.exists()) return null
 json.decodeFromString<JayJayMemory>(file.readText())
 } catch (e: Exception) {
 Log.e("JayJayLearning", "Speicher laden fehlgeschlagen: ${e.message}")
 null
 }
 }

 private fun saveMemory() {
 try {
 val file = File(ssd.getMemoryDir(), "memory.json")
 file.writeText(json.encodeToString(memory))
 } catch (e: Exception) {
 Log.e("JayJayLearning", "Speicher speichern fehlgeschlagen: ${e.message}")
 }
 }

 private fun generateId(): String = System.currentTimeMillis().toString() + "_" + (0..9999).random()

 fun destroy() { scope.cancel() }
}
