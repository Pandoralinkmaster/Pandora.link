package com.pandora.jayjay

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Intent
import android.media.AudioFormat
import android.media.AudioRecord
import android.media.MediaRecorder
import android.os.IBinder
import android.util.Log
import androidx.core.app.NotificationCompat
import kotlinx.coroutines.*
import kotlin.math.sqrt

class JayJayVoiceService : Service() {

 companion object {
 const val CHANNEL_ID = "jayjay_voice_channel"
 const val NOTIFICATION_ID = 1001
 const val SAMPLE_RATE = 16000
 const val BUFFER_SIZE = 1024
 const val VAD_THRESHOLD = 500.0
 const val CAPTURE_DURATION_MS = 3000L
 }

 private var audioRecord: AudioRecord? = null
 private var isRecording = false
 private val scope = CoroutineScope(Dispatchers.IO + SupervisorJob())
 private var engine: JayJayEngine? = null

 override fun onCreate() {
 super.onCreate()
 createNotificationChannel()
 Log.i("JayJayVoice", "Voice Service erstellt")
 }

 override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
 startForeground(NOTIFICATION_ID, buildNotification())
 startVoiceListening()
 return START_STICKY
 }

 override fun onBind(intent: Intent?): IBinder? = null

 private fun createNotificationChannel() {
 val channel = NotificationChannel(
 CHANNEL_ID,
 "JayJay Voice",
 NotificationManager.IMPORTANCE_LOW
 ).apply {
 description = "Dauerhafte Spracherkennung für JayJay"
 }
 val manager = getSystemService(NotificationManager::class.java)
 manager.createNotificationChannel(channel)
 }

 private fun buildNotification(): Notification {
 return NotificationCompat.Builder(this, CHANNEL_ID)
 .setContentTitle("JayJay Voice")
 .setContentText("Warte auf Wake-Word 'Pandemonium'...")
 .setSmallIcon(android.R.drawable.ic_btn_speak_now)
 .setOngoing(true)
 .build()
 }

 private fun startVoiceListening() {
 try {
 val minBufferSize = AudioRecord.getMinBufferSize(
 SAMPLE_RATE,
 AudioFormat.CHANNEL_IN_MONO,
 AudioFormat.ENCODING_PCM_16BIT
 )
 audioRecord = AudioRecord(
 MediaRecorder.AudioSource.MIC,
 SAMPLE_RATE,
 AudioFormat.CHANNEL_IN_MONO,
 AudioFormat.ENCODING_PCM_16BIT,
 maxOf(minBufferSize, BUFFER_SIZE)
 )
 audioRecord?.startRecording()
 isRecording = true
 Log.i("JayJayVoice", "AudioRecord gestartet")

 scope.launch {
 val buffer = ShortArray(BUFFER_SIZE)
 while (isRecording && isActive) {
 val read = audioRecord?.read(buffer, 0, BUFFER_SIZE) ?: 0
 if (read > 0) {
 val rms = calculateRms(buffer, read)
 if (rms > VAD_THRESHOLD) {
 Log.i("JayJayVoice", "Voice detected (RMS: $rms)")
 }
 }
 delay(50)
 }
 }
 } catch (e: Exception) {
 Log.e("JayJayVoice", "Start fehlgeschlagen: ${e.message}")
 }
 }

 private fun calculateRms(buffer: ShortArray, length: Int): Double {
 var sum = 0.0
 for (i in 0 until length) {
 sum += buffer[i] * buffer[i]
 }
 return sqrt(sum / length)
 }

 override fun onDestroy() {
 isRecording = false
 audioRecord?.stop()
 audioRecord?.release()
 audioRecord = null
 scope.cancel()
 super.onDestroy()
 Log.i("JayJayVoice", "Voice Service beendet")
 }
}
