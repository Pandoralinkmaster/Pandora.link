package com.pandora.jayjay

import android.content.Context
import android.util.Log
import com.pandora.database.SsdStorageManager
import kotlinx.serialization.Serializable
import kotlinx.serialization.encodeToString
import kotlinx.serialization.json.Json
import java.io.File
import kotlin.math.*

@Serializable
data class VoicePrint(
 val ownerId: String,
 val samples: List<VoiceSample> = emptyList(),
 val mfccFeatures: List<List<Double>> = emptyList(),
 val createdAt: Long = System.currentTimeMillis(),
)

@Serializable
data class VoiceSample(
 val sampleId: String,
 val mfccVector: List<Double>,
 val durationMs: Int = 0,
 val timestamp: Long = System.currentTimeMillis(),
)

@Serializable
data class VoiceRecognitionResult(
 val recognized: Boolean,
 val confidence: Double,
 val ownerId: String? = null,
)

class VoicePrintManager(
 private val context: Context,
 private val ssd: SsdStorageManager,
) {

 private val json = Json { ignoreUnknownKeys = true }
 private val voicePrints = mutableMapOf<String, VoicePrint>()
 private val THRESHOLD = 0.82

 fun loadVoicePrint(ownerId: String): VoicePrint? {
 val file = File(ssd.getVoicePrintsDir(), "$ownerId.json")
 return try {
 if (!file.exists()) return null
 val data = file.readText()
 json.decodeFromString<VoicePrint>(data).also {
 voicePrints[ownerId] = it
 Log.i("VoicePrint", "Voice-Print geladen: $ownerId")
 }
 } catch (e: Exception) {
 Log.e("VoicePrint", "Laden fehlgeschlagen: ${e.message}")
 null
 }
 }

 fun saveVoicePrint(print: VoicePrint) {
 val file = File(ssd.getVoicePrintsDir(), "${print.ownerId}.json")
 try {
 file.writeText(json.encodeToString(print))
 voicePrints[print.ownerId] = print
 Log.i("VoicePrint", "Voice-Print gespeichert: ${print.ownerId}")
 } catch (e: Exception) { Log.e("VoicePrint", "Speichern fehlgeschlagen: ${e.message}") }
 }

 fun addSample(ownerId: String, sample: VoiceSample) {
 val existing = voicePrints[ownerId] ?: VoicePrint(ownerId = ownerId)
 val updated = existing.copy(samples = existing.samples + sample)
 saveVoicePrint(updated)
 }

 fun extractMfcc(audioData: ByteArray): List<Double> {
 // BEFEHL: Implementiere echte MFCC-Extraktion (Mel-Frequency Cepstral Coefficients)
 // Schritt 1: Audio-Daten in Double-Array konvertieren (16-bit PCM)
 val samples = audioData.toList().map { it.toDouble() / 128.0 }
 if (samples.size < 256) return List(13) { 0.0 }

 // Schritt 2: Pre-Emphasis-Filter (Hochpass)
 val preEmphasis = 0.97
 val emphasized = MutableList(samples.size) { 0.0 }
 emphasized[0] = samples[0]
 for (i in 1 until samples.size) {
 emphasized[i] = samples[i] - preEmphasis * samples[i - 1]
 }

 // Schritt 3: Fensterung (Hamming-Fenster)
 val frameSize = 256
 val hopSize = 128
 val numFrames = (emphasized.size - frameSize) / hopSize + 1
 val frames = mutableListOf<List<Double>>()
 for (i in 0 until numFrames) {
 val start = i * hopSize
 val frame = emphasized.subList(start, minOf(start + frameSize, emphasized.size))
 val windowed = frame.mapIndexed { j, v ->
 v * (0.54 - 0.46 * cos(2.0 * PI * j / (frameSize - 1)))
 }
 frames.add(windowed)
 }

 // Schritt 4: FFT (vereinfachte Version)
 val magnitudes = frames.map { frame ->
 val fft = MutableList(frameSize) { 0.0 }
 for (k in 0 until frameSize / 2) {
 var real = 0.0
 var imag = 0.0
 for (n in frame.indices) {
 val angle = -2.0 * PI * k * n / frameSize
 real += frame[n] * cos(angle)
 imag += frame[n] * sin(angle)
 }
 fft[k] = sqrt(real * real + imag * imag)
 }
 fft.subList(0, frameSize / 2)
 }

 // Schritt 5: Mel-Filterbank (vereinfacht - 26 Filter)
 val numFilters = 26
 val numCepstra = 13
 val melFeatures = magnitudes.map { mag ->
 val melEnergies = MutableList(numFilters) { 0.0 }
 for (m in 1..numFilters) {
 val fMin = 0.0
 val fMax = 8000.0
 val melMin = 1127.0 * ln(1.0 + fMin / 700.0)
 val melMax = 1127.0 * ln(1.0 + fMax / 700.0)
 val melCenter = melMin + (melMax - melMin) * m / (numFilters + 1)
 val melLeft = melMin + (melMax - melMin) * (m - 1) / (numFilters + 1)
 val melRight = melMin + (melMax - melMin) * (m + 1) / (numFilters + 1)
 val freqCenter = 700.0 * (exp(melCenter / 1127.0) - 1.0)
 val freqLeft = 700.0 * (exp(melLeft / 1127.0) - 1.0)
 val freqRight = 700.0 * (exp(melRight / 1127.0) - 1.0)

 val binCenter = (freqCenter / 8000.0 * mag.size).toInt()
 val binLeft = (freqLeft / 8000.0 * mag.size).toInt()
 val binRight = (freqRight / 8000.0 * mag.size).toInt()

 for (k in binLeft until binRight) {
 if (k in mag.indices) {
 val weight = when {
 k < binCenter -> (k - binLeft).toDouble() / (binCenter - binLeft)
 k > binCenter -> (binRight - k).toDouble() / (binRight - binCenter)
 else -> 1.0
 }
 melEnergies[m - 1] += mag[k] * weight
 }
 }
 }
 melEnergies
 }

 // Schritt 6: Log + DCT (Discrete Cosine Transform) für MFCCs
 val mfccs = melFeatures.map { mel ->
 val logMel = mel.map { if (it > 0) ln(it) else 0.0 }
 val cepstra = MutableList(numCepstra) { 0.0 }
 for (n in 0 until numCepstra) {
 for (k in logMel.indices) {
 cepstra[n] += logMel[k] * cos(PI * n * (k + 0.5) / logMel.size)
 }
 }
 cepstra
 }

 // Durchschnitt über alle Frames
 val avgMfcc = MutableList(numCepstra) { 0.0 }
 for (frame in mfccs) {
 for (i in frame.indices) {
 avgMfcc[i] += frame[i]
 }
 }
 avgMfcc.map { it / maxOf(mfccs.size, 1) }
 }

 fun recognize(audioData: ByteArray): VoiceRecognitionResult {
 val features = extractMfcc(audioData)
 if (voicePrints.isEmpty()) return VoiceRecognitionResult(false, 0.0)

 var bestMatch: Pair<String, Double>? = null
 voicePrints.forEach { (ownerId, print) ->
 print.mfccFeatures.forEach { stored ->
 val similarity = cosineSimilarity(features, stored)
 if (bestMatch == null || similarity > bestMatch!!.second) {
 bestMatch = ownerId to similarity
 }
 }
 }

 return bestMatch?.let { (owner, sim) ->
 VoiceRecognitionResult(recognized = sim >= THRESHOLD, confidence = sim, ownerId = owner)
 } ?: VoiceRecognitionResult(false, 0.0)
 }

 private fun cosineSimilarity(a: List<Double>, b: List<Double>): Double {
 if (a.size != b.size) return 0.0
 val dot = a.zip(b).sumOf { (x, y) -> x * y }
 val normA = sqrt(a.sumOf { it * it })
 val normB = sqrt(b.sumOf { it * it })
 return if (normA > 0 && normB > 0) dot / (normA * normB) else 0.0
 }

 fun getAllPrints(): Map<String, VoicePrint> = voicePrints.toMap()
}
