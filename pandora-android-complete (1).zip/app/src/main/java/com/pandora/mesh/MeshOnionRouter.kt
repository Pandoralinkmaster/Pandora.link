package com.pandora.mesh

import android.util.Log
import com.pandora.security.SecurityModule
import kotlinx.serialization.Serializable
import java.security.SecureRandom
import javax.crypto.Cipher
import javax.crypto.spec.IvParameterSpec
import javax.crypto.spec.SecretKeySpec

@Serializable
data class OnionPacket(
 val packetId: String,
 val layers: List<RouteLayer>,
 val payload: String,
 val ttl: Int = 7,
 val timestamp: Long = System.currentTimeMillis(),
)

@Serializable
data class RouteLayer(
 val nodeId: String,
 val encryptedPayload: String,
 val iv: String,
)

class MeshOnionRouter(private val security: SecurityModule) {

 private val random = SecureRandom()
 private val routeCache = mutableMapOf<String, List<String>>()
 private val messageQueue = mutableListOf<OnionPacket>()

 fun createRoute(destinationId: String, intermediateNodes: List<String>): List<String> {
 val route = listOf("local") + intermediateNodes.shuffled(random).take(5) + destinationId
 routeCache[destinationId] = route
 Log.i("OnionRouter", "Route erstellt: ${route.joinToString(" -> ")}")
 return route
 }

 fun encryptPacket(payload: String, route: List<String>): OnionPacket {
 val packetId = security.randomHex(16)
 var currentPayload = payload
 val layers = mutableListOf<RouteLayer>()

 for (i in route.indices.reversed()) {
 val nodeId = route[i]
 val key = deriveKey(nodeId)
 val iv = ByteArray(16).also { random.nextBytes(it) }
 val cipher = Cipher.getInstance("AES/CBC/PKCS5Padding")
 cipher.init(Cipher.ENCRYPT_MODE, key, IvParameterSpec(iv))
 val encrypted = cipher.doFinal(currentPayload.toByteArray())
 currentPayload = android.util.Base64.encodeToString(encrypted, android.util.Base64.NO_WRAP)

 layers.add(0, RouteLayer(
 nodeId = nodeId,
 encryptedPayload = currentPayload,
 iv = android.util.Base64.encodeToString(iv, android.util.Base64.NO_WRAP),
 ))
 }

 return OnionPacket(packetId = packetId, layers = layers, payload = payload)
 }

 fun decryptLayer(packet: OnionPacket, nodeId: String): String? {
 val layer = packet.layers.find { it.nodeId == nodeId } ?: return null
 return try {
 val key = deriveKey(nodeId)
 val iv = android.util.Base64.decode(layer.iv, android.util.Base64.NO_WRAP)
 val encrypted = android.util.Base64.decode(layer.encryptedPayload, android.util.Base64.NO_WRAP)
 val cipher = Cipher.getInstance("AES/CBC/PKCS5Padding")
 cipher.init(Cipher.DECRYPT_MODE, key, IvParameterSpec(iv))
 String(cipher.doFinal(encrypted))
 } catch (e: Exception) {
 Log.e("OnionRouter", "Entschlüsselung fehlgeschlagen: ${e.message}")
 null
 }
 }

 fun queueMessage(packet: OnionPacket) {
 if (packet.ttl > 0) {
 messageQueue.add(packet)
 Log.i("OnionRouter", "Nachricht queued: ${packet.packetId}")
 }
 }

 fun processQueue() {
 val now = System.currentTimeMillis()
 messageQueue.removeAll { packet ->
 val expired = packet.ttl <= 0 || (now - packet.timestamp) > 300000
 if (expired) Log.i("OnionRouter", "Packet expired: ${packet.packetId}")
 expired
 }
 }

 private fun deriveKey(nodeId: String): SecretKeySpec {
 val hash = security.sha256(nodeId).substring(0, 32)
 return SecretKeySpec(hash.toByteArray(), "AES")
 }

 fun getQueueSize(): Int = messageQueue.size
 fun getRoutes(): Map<String, List<String>> = routeCache.toMap()
}
