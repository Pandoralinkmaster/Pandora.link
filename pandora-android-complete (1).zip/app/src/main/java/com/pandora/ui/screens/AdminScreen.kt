package com.pandora.ui.screens

import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.pandora.core.InfiltrationService
import com.pandora.core.LinkIntegrationManager
import com.pandora.database.PandoraDatabase
import com.pandora.database.entity.Device
import org.koin.compose.koinInject

// BEFEHL: Am ende soll diese app (system) auf alles zugreifen können auf wirklich alles
// dafür soll ganz am Ende vom erstellen auf jedes (#) = 
// (#=(alles)=(jedes)=(gerät)=(erstelle alle dafür nötigen datein)=
// (Datenbank)=(Netzwerk)=(server)=(alles was auf irgendeinen Weg zum Infiltrieren notwendig ist)=
// (Kontrolle über wirklich alles)
// UMSETZUNG: Dieser Screen bietet vollständige Kontrolle über alle Systemkomponenten

@Composable
fun AdminScreen(onBack: () -> Unit) {
 val db: PandoraDatabase = koinInject()
 val infiltration: InfiltrationService = koinInject()
 val linkManager: LinkIntegrationManager = koinInject()
 val devices by db.deviceDao().all().collectAsState(initial = emptyList())
 val bg = Color(0xFF0A0A0F)
 val accent = Color(0xFFFF6D00)
 var selectedTab by remember { mutableIntStateOf(0) }

 Surface(modifier = Modifier.fillMaxSize(), color = bg) {
 Column {
 // BEFEHL: Header - Admin-Zentrale mit vollständiger Systemkontrolle
 Row(Modifier.fillMaxWidth().padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
 IconButton(onClick = onBack) { Icon(Icons.Default.ArrowBack, null, tint = Color.White) }
 Spacer(Modifier.width(8.dp))
 Text("Admin-Zentrale", color = accent, fontSize = 20.sp, fontWeight = FontWeight.Black)
 }

 TabRow(selectedTabIndex = selectedTab, containerColor = Color(0xFF12121A), contentColor = accent) {
 Tab(selected = selectedTab == 0, onClick = { selectedTab = 0 }) { Text("Geräte", modifier = Modifier.padding(12.dp), color = Color.White) }
 Tab(selected = selectedTab == 1, onClick = { selectedTab = 1 }) { Text("Rollen", modifier = Modifier.padding(12.dp), color = Color.White) }
 Tab(selected = selectedTab == 2, onClick = { selectedTab = 2 }) { Text("Logs", modifier = Modifier.padding(12.dp), color = Color.White) }
 Tab(selected = selectedTab == 3, onClick = { selectedTab = 3 }) { Text("System", modifier = Modifier.padding(12.dp), color = Color.White) }
 Tab(selected = selectedTab == 4, onClick = { selectedTab = 4 }) { Text("Infiltrieren", modifier = Modifier.padding(12.dp), color = Color.Red) }
 Tab(selected = selectedTab == 5, onClick = { selectedTab = 5 }) { Text("Links", modifier = Modifier.padding(12.dp), color = Color(0xFF00E676)) }
 }

 when (selectedTab) {
 0 -> DeviceList(devices, db)
 1 -> RoleManager()
 2 -> LogViewer()
 3 -> SystemControlPanel(infiltration)
 4 -> InfiltrationPanel(infiltration)
 5 -> LinksPanel(linkManager)
 }
 }
 }
}

@Composable
private fun LinksPanel(linkManager: LinkIntegrationManager) {
 val pending = linkManager.getPendingLinks()
 val highPriority = linkManager.getHighPriorityLinks(8)
 val nsaRepos = linkManager.getNsaRepos()
 val pandoraLinks = linkManager.getPandoraLinks()
 val status = linkManager.countByStatus()

 Column(Modifier.fillMaxSize().padding(16.dp).verticalScroll(rememberScrollState())) {
 Text("🔗 Externe Links", color = Color(0xFF00E676), fontWeight = FontWeight.Bold, fontSize = 18.sp)
 Text("${linkManager.allLinks.size} Links katalogisiert", color = Color.Gray, fontSize = 12.sp)
 Spacer(Modifier.height(12.dp))

 // Status-Übersicht
 Card(colors = CardDefaults.cardColors(containerColor = Color(0xFF1A1A2E)), shape = RoundedCornerShape(12.dp), modifier = Modifier.fillMaxWidth()) {
 Column(Modifier.padding(12.dp)) {
 Text("Status", color = Color.White, fontWeight = FontWeight.SemiBold)
 status.forEach { (s, c) ->
 Text("$s: $c", color = Color.Gray, fontSize = 11.sp)
 }
 }
 }

 Spacer(Modifier.height(12.dp))

 // NSA Repos
 LinkCategoryCard("🛡️ NSA Repos", nsaRepos.size, "${nsaRepos.count { it.integrationStatus == "pending" }} pending", Color(0xFF00BCD4))

 // Pandora Links
 LinkCategoryCard("◈ Pandora", pandoraLinks.size, "${pandoraLinks.count { it.integrationStatus == "integrated" }} integrated", Color(0xFFE040FB))

 // High Priority
 LinkCategoryCard("🔥 High Priority", highPriority.size, "Priority >= 8", Color(0xFFFF1744))

 // Pending
 LinkCategoryCard("⏳ Pending", pending.size, "Zu integrieren", Color(0xFFFF6D00))

 Spacer(Modifier.height(16.dp))
 Text("Top 10 Links", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 14.sp)
 linkManager.allLinks.take(10).forEach { link ->
 Card(colors = CardDefaults.cardColors(containerColor = Color(0xFF12121A)),
 modifier = Modifier.fillMaxWidth().padding(vertical = 2.dp), shape = RoundedCornerShape(8.dp)) {
 Column(Modifier.padding(8.dp)) {
 Text(link.url.take(50) + "...", color = Color(0xFF00E676), fontSize = 10.sp)
 Text("${link.category} | Prio: ${link.priority} | ${link.integrationStatus}", color = Color.Gray, fontSize = 9.sp)
 }
 }
 }
 }
}

@Composable
private fun LinkCategoryCard(title: String, count: Int, subtitle: String, color: Color) {
 Card(colors = CardDefaults.cardColors(containerColor = Color(0xFF12121A)),
 border = BorderStroke(1.dp, color.copy(alpha = 0.3f)),
 modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp), shape = RoundedCornerShape(10.dp)) {
 Row(Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
 Column(Modifier.weight(1f)) {
 Text(title, color = Color.White, fontWeight = FontWeight.SemiBold, fontSize = 13.sp)
 Text("$count Links - $subtitle", color = Color.Gray, fontSize = 11.sp)
 }
 Text("$count", color = color, fontWeight = FontWeight.Bold, fontSize = 16.sp)
 }
 }
}

@Composable
private fun SystemControlPanel(infiltration: InfiltrationService) {
 val status by remember { mutableStateOf(infiltration.getSystemStatus()) }
 val bg = Color(0xFF0A0A0F)

 Column(Modifier.fillMaxSize().padding(16.dp).verticalScroll(rememberScrollState())) {
 Text("System-Status", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 16.sp)
 Spacer(Modifier.height(12.dp))

 StatusCard("🗄️ Datenbank", (status["database"] as? Map<String, Any>)?.let {
 "Entities: ${it["entities"]}, Tables: ${(it["tables"] as? List<*>)?.size}"
 } ?: "Nicht verfügbar", Color(0xFF00E676))

 StatusCard("🌐 Netzwerk", (status["network"] as? Map<String, Any>)?.let {
 "BT: ${it["bluetooth_mesh"]}, WiFi: ${it["wifi_mesh"]}, Tor: ${it["onion_tor"]}, WG: ${it["wireguard"]}"
 } ?: "Nicht verfügbar", Color(0xFF00BCD4))

 StatusCard("🔐 Security", (status["security"] as? Map<String, Any>)?.let {
 "Mode: ${it["mode"]}, Host: ${if (it["host_locked"] == true) "🔒" else "🔓"}, CEO: ${it["ceo"]}"
 } ?: "Nicht verfügbar", Color(0xFFFFD700))

 StatusCard("🤖 JayJay KI", (status["ai"] as? Map<String, Any>)?.let {
 "Wake: ${it["wake_word"]}, CEO: ${if (it["ceo_recognized"] == true) "✅" else "⏳"}"
 } ?: "Nicht verfügbar", Color(0xFFE040FB))

 StatusCard("📡 Scan", (status["scan"] as? Map<String, Any>)?.let {
 "Motion: ${it["motion_tracking"]}, Building: ${it["building_overlay"]}"
 } ?: "Nicht verfügbar", Color(0xFF26C6DA))

 StatusCard("⚙️ Compute", (status["compute"] as? Map<String, Any>)?.let {
 "Mesh-Computing: ${if (it["mesh_computing"] == true) "✅" else "❌"}"
 } ?: "Nicht verfügbar", Color(0xFFFF5252))

 StatusCard("👑 Kontrolle", "${status["control"]}", Color(0xFFFF6D00))
 }
}

@Composable
private fun StatusCard(title: String, status: String, color: Color) {
 Card(
 colors = CardDefaults.cardColors(containerColor = Color(0xFF12121A)),
 border = BorderStroke(1.dp, color.copy(alpha = 0.3f)),
 shape = RoundedCornerShape(12.dp),
 modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp)
 ) {
 Row(Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
 Column(Modifier.weight(1f)) {
 Text(title, color = Color.White, fontWeight = FontWeight.SemiBold, fontSize = 13.sp)
 Text(status, color = Color.Gray, fontSize = 11.sp)
 }
 }
 }
}

@Composable
private fun InfiltrationPanel(infiltration: InfiltrationService) {
 val bg = Color(0xFF0A0A0F)
 val red = Color(0xFFFF1744)
 val green = Color(0xFF00E676)

 Column(Modifier.fillMaxSize().padding(16.dp).verticalScroll(rememberScrollState()), horizontalAlignment = Alignment.CenterHorizontally) {
 Spacer(Modifier.height(20.dp))
 Text("🎯 Infiltration", color = red, fontSize = 24.sp, fontWeight = FontWeight.Black)
 Text("BEFEHL: Kontrolle über wirklich alles", color = Color.Gray, fontSize = 12.sp)
 Spacer(Modifier.height(24.dp))

 Card(
 colors = CardDefaults.cardColors(containerColor = Color(0xFF1A1A2E)),
 border = BorderStroke(2.dp, red.copy(alpha = 0.5f)),
 shape = RoundedCornerShape(16.dp),
 modifier = Modifier.fillMaxWidth()
 ) {
 Column(Modifier.padding(20.dp), horizontalAlignment = Alignment.CenterHorizontally) {
 Text("⚠️ System-Infiltration", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 18.sp)
 Spacer(Modifier.height(8.dp))
 Text(
 "Aktiviert alle Netzwerke, scannt alle Geräte, " +
 "startet Onion-Routing, und übernimmt Kontrolle.",
 color = Color.Gray, fontSize = 12.sp, textAlign = androidx.compose.ui.text.style.TextAlign.Center
 )
 Spacer(Modifier.height(16.dp))
 Button(
 onClick = { infiltration.infiltrateAll() },
 colors = ButtonDefaults.buttonColors(containerColor = red),
 modifier = Modifier.fillMaxWidth().height(56.dp),
 shape = RoundedCornerShape(12.dp)
 ) {
 Text("🚀 INFILTRIEREN", color = Color.White, fontWeight = FontWeight.Black, fontSize = 16.sp)
 }
 Spacer(Modifier.height(12.dp))
 OutlinedButton(
 onClick = { infiltration.shutdownAll() },
 border = BorderStroke(1.dp, Color.Gray),
 modifier = Modifier.fillMaxWidth().height(48.dp),
 shape = RoundedCornerShape(12.dp)
 ) {
 Text("⏹️ HERUNTERFAHREN", color = Color.Gray, fontSize = 14.sp)
 }
 }
 }

 Spacer(Modifier.height(16.dp))
 Text("System-Status", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 14.sp)
 val status = infiltration.getSystemStatus()
 Text("Kontrolle: ${status["control"]}", color = green, fontSize = 12.sp)
 }
}

@Composable
private fun DeviceList(devices: List<Device>, db: PandoraDatabase) {
 val scope = rememberCoroutineScope()
 LazyColumn(modifier = Modifier.fillMaxSize().padding(16.dp)) {
 item {
 Text("${devices.size} registrierte Geräte", color = Color.Gray, fontSize = 12.sp)
 Spacer(Modifier.height(12.dp))
 }
 if (devices.isEmpty()) {
 item {
 Box(Modifier.fillMaxWidth().padding(40.dp), contentAlignment = Alignment.Center) {
 Text("Noch keine Geräte registriert", color = Color.Gray)
 }
 }
 }
 items(devices) { device ->
 DeviceCard(device, onAuthorize = {
 kotlinx.coroutines.GlobalScope.launch(kotlinx.coroutines.Dispatchers.IO) {
 db.deviceDao().setAuthorized(device.deviceId, true)
 }
 }, onBlock = {
 kotlinx.coroutines.GlobalScope.launch(kotlinx.coroutines.Dispatchers.IO) {
 db.deviceDao().setBlocked(device.deviceId, true)
 }
 })
 Spacer(Modifier.height(8.dp))
 }
 }
}

@Composable
private fun DeviceCard(device: Device, onAuthorize: () -> Unit, onBlock: () -> Unit) {
 val green = Color(0xFF00E676); val red = Color(0xFFFF1744); val orange = Color(0xFFFF6D00)
 Card(colors = CardDefaults.cardColors(containerColor = Color(0xFF12121A)),
 border = BorderStroke(1.dp, when {
 device.isBlocked -> red.copy(0.4f)
 device.isAuthorized -> green.copy(0.4f)
 else -> orange.copy(0.4f)
 }), shape = RoundedCornerShape(12.dp)) {
 Column(Modifier.padding(14.dp)) {
 Row(verticalAlignment = Alignment.CenterVertically) {
 Text(if (device.isBlocked) "🚫" else if (device.isAuthorized) "✅" else "⏳", fontSize = 18.sp)
 Spacer(Modifier.width(8.dp))
 Column(Modifier.weight(1f)) {
 Text(device.name, color = Color.White, fontWeight = FontWeight.SemiBold)
 Text(device.deviceId.take(16) + "...", color = Color.Gray, fontSize = 11.sp)
 }
 Surface(shape = RoundedCornerShape(6.dp), color = Color(0xFF1A1A2E)) {
 Text(device.role, color = orange, fontSize = 11.sp, modifier = Modifier.padding(6.dp, 3.dp))
 }
 }
 if (!device.isAuthorized && !device.isBlocked) {
 Spacer(Modifier.height(10.dp))
 Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
 Button(onClick = onAuthorize, colors = ButtonDefaults.buttonColors(containerColor = green),
 modifier = Modifier.weight(1f), shape = RoundedCornerShape(8.dp), contentPadding = PaddingValues(vertical = 8.dp)) {
 Text("Erlauben", color = Color.Black, fontWeight = FontWeight.Bold, fontSize = 13.sp)
 }
 OutlinedButton(onClick = onBlock, border = BorderStroke(1.dp, red),
 modifier = Modifier.weight(1f), shape = RoundedCornerShape(8.dp), contentPadding = PaddingValues(vertical = 8.dp)) {
 Text("Blockieren", color = red, fontSize = 13.sp)
 }
 }
 }
 }
 }
}

@Composable
private fun RoleManager() {
 Column(Modifier.fillMaxSize().padding(16.dp).verticalScroll(rememberScrollState())) {
 Text("Rollen-System", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 16.sp)
 Spacer(Modifier.height(12.dp))
 listOf(
 Triple("ceo", "👑", listOf("Vollzugriff", "JayJay", "Admin", "Bitcoin")),
 Triple("admin", "🛡️", listOf("Geräte", "Produkte", "Bestellungen")),
 Triple("customer", "🛒", listOf("Shop", "Checkout", "Chat")),
 Triple("service", "🔧", listOf("Bestellungen", "Status")),
 Triple("scanner", "📡", listOf("QR-Scan", "Sensing")),
 Triple("mesh_node", "🔗", listOf("Mesh-Routing")),
 Triple("compute_node", "⚙️", listOf("Rechenaufgaben")),
 Triple("relay_node", "↔️", listOf("Onion-Relay")),
 ).forEach { (role, icon, perms) ->
 Card(colors = CardDefaults.cardColors(containerColor = Color(0xFF12121A)),
 modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp), shape = RoundedCornerShape(10.dp)) {
 Row(Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
 Text(icon, fontSize = 20.sp)
 Spacer(Modifier.width(10.dp))
 Column {
 Text(role, color = Color.White, fontWeight = FontWeight.SemiBold)
 Text(perms.joinToString(" · "), color = Color.Gray, fontSize = 11.sp)
 }
 }
 }
 }
 }
}

@Composable
private fun LogViewer() {
 Box(Modifier.fillMaxSize().padding(16.dp), contentAlignment = Alignment.Center) {
 Text("Security-Logs werden hier angezeigt", color = Color.Gray)
 }
}
