package com.pandora.ui.screens

import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.pandora.jayjay.JayJayEngine
import com.pandora.jayjay.JayJayLearningEngine
import org.koin.compose.koinInject

@Composable
fun JayJayScreen(onBack: () -> Unit) {
 val engine: JayJayEngine = koinInject()
 val learning: JayJayLearningEngine = koinInject()
 val state by engine.state.collectAsState()
 var selectedTab by remember { mutableIntStateOf(0) }
 val bg = Color(0xFF0A0A0F)
 val accent = Color(0xFFE040FB)

 Surface(modifier = Modifier.fillMaxSize(), color = bg) {
 Column {
 Row(Modifier.fillMaxWidth().padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
 IconButton(onClick = onBack) { Icon(Icons.Default.ArrowBack, null, tint = Color.White) }
 Spacer(Modifier.width(8.dp))
 Text("JayJay KI", color = accent, fontSize = 20.sp, fontWeight = FontWeight.Black)
 }
 TabRow(selectedTabIndex = selectedTab, containerColor = Color(0xFF12121A), contentColor = accent) {
 Tab(selected = selectedTab == 0, onClick = { selectedTab = 0 }) { Text("Chat", modifier = Modifier.padding(12.dp), color = Color.White) }
 Tab(selected = selectedTab == 1, onClick = { selectedTab = 1 }) { Text("Lernen", modifier = Modifier.padding(12.dp), color = Color.White) }
 Tab(selected = selectedTab == 2, onClick = { selectedTab = 2 }) { Text("Stimme", modifier = Modifier.padding(12.dp), color = Color.White) }
 }
 when (selectedTab) {
 0 -> JayJayChatTab(engine, state)
 1 -> JayJayLearningTab(learning)
 2 -> JayJayVoiceTab(engine)
 }
 }
 }
}

@Composable
private fun JayJayChatTab(engine: JayJayEngine, state: JayJayState) {
 var input by remember { mutableStateOf("") }
 Column(Modifier.fillMaxSize().padding(16.dp)) {
 LazyColumn(modifier = Modifier.weight(1f), reverseLayout = true) {
 items(state.chatHistory.reversed()) { entry ->
 ChatBubble(entry.isUser, entry.text, entry.timestamp)
 Spacer(Modifier.height(8.dp))
 }
 }
 Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
 OutlinedTextField(value = input, onValueChange = { input = it },
 modifier = Modifier.weight(1f), placeholder = { Text("Sag etwas...", color = Color.Gray) },
 colors = OutlinedTextFieldDefaults.colors(
 focusedBorderColor = Color(0xFFE040FB), unfocusedBorderColor = Color.Gray,
 focusedTextColor = Color.White, unfocusedTextColor = Color.White,
 ), shape = RoundedCornerShape(12.dp))
 Spacer(Modifier.width(8.dp))
 IconButton(onClick = {
 if (input.isNotBlank()) { engine.processText(input); input = "" }
 }) { Icon(Icons.Default.Send, null, tint = Color(0xFFE040FB)) }
 }
 }
}

@Composable
private fun ChatBubble(isUser: Boolean, text: String, timestamp: Long) {
 val bg = if (isUser) Color(0xFFE040FB) else Color(0xFF1A1A2E)
 val textColor = if (isUser) Color.White else Color.White
 Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = if (isUser) Arrangement.End else Arrangement.Start) {
 Card(colors = CardDefaults.cardColors(containerColor = bg), shape = RoundedCornerShape(16.dp)) {
 Text(text, color = textColor, modifier = Modifier.padding(12.dp), fontSize = 14.sp)
 }
 }
}

@Composable
private fun JayJayLearningTab(learning: JayJayLearningEngine) {
 Column(Modifier.fillMaxSize().padding(16.dp).verticalScroll(rememberScrollState())) {
 Text("Lern-Beispiele", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 16.sp)
 Spacer(Modifier.height(12.dp))
 listOf(
 "JayJay, lerne: 'Wetter' = 'Wie ist das Wetter?'",
 "JayJay, lerne: 'Licht an' = 'Schalte das Licht ein'",
 "JayJay, recherchiere: 'Bitcoin Mining 2024'",
 "JayJay, lerne Befehl: 'Scan' = Starte Scan",
 "JayJay, lerne Befehl: 'Sperren' = Sperre Host",
 ).forEach { example ->
 Card(colors = CardDefaults.cardColors(containerColor = Color(0xFF1A1A2E)),
 modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp), shape = RoundedCornerShape(10.dp)) {
 Text(example, color = Color.White.copy(alpha = 0.8f), modifier = Modifier.padding(12.dp), fontSize = 13.sp)
 }
 }
 Spacer(Modifier.height(16.dp))
 Text("Auto-Lernen: Aktiv (stündlich)", color = Color(0xFF00E676), fontSize = 12.sp)
 }
}

@Composable
private fun JayJayVoiceTab(engine: JayJayEngine) {
 Column(Modifier.fillMaxSize().padding(16.dp), horizontalAlignment = Alignment.CenterHorizontally) {
 Spacer(Modifier.height(40.dp))
 Surface(shape = RoundedCornerShape(100.dp), color = Color(0xFF1A1A2E), modifier = Modifier.size(120.dp)) {
 Box(contentAlignment = Alignment.Center) {
 Text("🎙️", fontSize = 48.sp)
 }
 }
 Spacer(Modifier.height(24.dp))
 Text("Wake-Wort: "Pandemonium"", color = Color(0xFFE040FB), fontWeight = FontWeight.Bold, fontSize = 18.sp)
 Text("Sage das Wort, um JayJay zu aktivieren", color = Color.Gray, fontSize = 12.sp)
 Spacer(Modifier.height(24.dp))
 Card(colors = CardDefaults.cardColors(containerColor = Color(0xFF1A1A2E)), shape = RoundedCornerShape(12.dp), modifier = Modifier.fillMaxWidth()) {
 Column(Modifier.padding(16.dp)) {
 Text("Stimm-Erkennung", color = Color.White, fontWeight = FontWeight.Bold)
 Spacer(Modifier.height(8.dp))
 Text("CEO: Finn Jona Lischke", color = Color(0xFF00E676))
 Text("Status: Bereit", color = Color.Gray, fontSize = 12.sp)
 Spacer(Modifier.height(8.dp))
 Text("3+ Samples aufnehmen für Voice-Print", color = Color.Gray, fontSize = 11.sp)
 }
 }
 }
}
