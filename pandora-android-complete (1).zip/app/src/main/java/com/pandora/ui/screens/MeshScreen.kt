package com.pandora.ui.screens

import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.pandora.mesh.BluetoothMeshManager
import com.pandora.mesh.MeshOnionRouter
import com.pandora.mesh.WifiMeshManager
import com.pandora.onion.OnionModule
import com.pandora.wireguard.WireGuardModule
import org.koin.compose.koinInject

@Composable
fun MeshScreen(onBack: () -> Unit) {
 val btMesh: BluetoothMeshManager = koinInject()
 val wifiMesh: WifiMeshManager = koinInject()
 val onion: OnionModule = koinInject()
 val wireguard: WireGuardModule = koinInject()
 val bg = Color(0xFF0A0A0F)
 val accent = Color(0xFF00BCD4)

 Surface(modifier = Modifier.fillMaxSize(), color = bg) {
 Column(modifier = Modifier.fillMaxSize().padding(16.dp).verticalScroll(rememberScrollState())) {
 Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
 IconButton(onClick = onBack) { Icon(Icons.Default.ArrowBack, null, tint = Color.White) }
 Spacer(Modifier.width(8.dp))
 Text("Netzwerk", color = accent, fontSize = 20.sp, fontWeight = FontWeight.Black)
 }
 Spacer(Modifier.height(16.dp))

 NetworkCard("🔗 Bluetooth Mesh", "BLE GATT Server · Advertising · Scanning", Color(0xFF00E676)) {
 btMesh.startAdvertising("pandora_ceo")
 btMesh.startScanning()
 }
 NetworkCard("📡 WiFi Mesh", "WiFi Direct · RSSI Scan · Local Hotspot", Color(0xFF00BCD4)) {
 wifiMesh.discoverPeers()
 wifiMesh.scanRssi()
 }
 NetworkCard("🧅 Onion / Tor", "Orbot · SOCKS5 Proxy · Anonymisierung", Color(0xFF69F0AE)) {
 onion.startOrbot()
 }
 NetworkCard("🔒 WireGuard VPN", "Curve25519 · Peer Management · QR-Export", Color(0xFF40C4FF)) {
 wireguard.openWireGuardApp()
 }

 Spacer(Modifier.height(20.dp))
 Text("Pandora Onion Mesh", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 16.sp)
 Spacer(Modifier.height(8.dp))
 Card(colors = CardDefaults.cardColors(containerColor = Color(0xFF1A1A2E)), shape = RoundedCornerShape(12.dp), modifier = Modifier.fillMaxWidth()) {
 Column(Modifier.padding(16.dp)) {
 Text("Pandora Onion Mesh = Bluetooth Mesh + WiFi Mesh + Onion Routing + WireGuard", color = Color.Gray, fontSize = 12.sp)
 Spacer(Modifier.height(8.dp))
 Text("Overlay: Bluetooth (nahe) + WiFi (weit) + Onion (anonym) + WireGuard (verschlüsselt)", color = Color.Gray, fontSize = 11.sp)
 }
 }
 }
 }
}

@Composable
private fun NetworkCard(title: String, subtitle: String, color: Color, onActivate: () -> Unit) {
 Card(colors = CardDefaults.cardColors(containerColor = Color(0xFF12121A)),
 border = BorderStroke(1.dp, color.copy(alpha = 0.3f)),
 shape = RoundedCornerShape(14.dp), modifier = Modifier.fillMaxWidth().padding(vertical = 6.dp)) {
 Row(Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
 Column(Modifier.weight(1f)) {
 Text(title, color = Color.White, fontWeight = FontWeight.SemiBold, fontSize = 14.sp)
 Text(subtitle, color = Color.Gray, fontSize = 11.sp)
 }
 Button(onClick = onActivate, colors = ButtonDefaults.buttonColors(containerColor = color),
 shape = RoundedCornerShape(8.dp)) {
 Text("Aktivieren", color = Color.Black, fontSize = 12.sp, fontWeight = FontWeight.Bold)
 }
 }
 }
}
