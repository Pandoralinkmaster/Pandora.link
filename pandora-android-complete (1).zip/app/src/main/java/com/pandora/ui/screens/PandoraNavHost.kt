package com.pandora.ui.screens

import androidx.compose.runtime.Composable
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import com.pandora.core.ConfigManager
import org.koin.compose.koinInject

@Composable
fun PandoraNavHost() {
 val navController = rememberNavController()
 val config: ConfigManager = koinInject()

 NavHost(navController = navController, startDestination = "dashboard") {
 composable("setup") {
 SetupScreen(
 config = config,
 onRequestSsdPicker = { /* handled in MainActivity */ },
 onSetupComplete = { navController.navigate("dashboard") { popUpTo("setup") { inclusive = true } } }
 )
 }
 composable("dashboard") {
 DashboardScreen(
 config = config,
 onNavigateAdmin = { navController.navigate("admin") },
 onNavigateJayJay = { navController.navigate("jayjay") },
 onNavigateMesh = { navController.navigate("mesh") },
 onNavigateWallet = { navController.navigate("wallet") },
 onNavigateShop = { navController.navigate("shop") },
 )
 }
 composable("admin") {
 AdminScreen(onBack = { navController.popBackStack() })
 }
 composable("jayjay") {
 JayJayScreen(onBack = { navController.popBackStack() })
 }
 composable("mesh") {
 MeshScreen(onBack = { navController.popBackStack() })
 }
 composable("wallet") {
 WalletScreen(onBack = { navController.popBackStack() })
 }
 composable("shop") {
 ShopScreen(onBack = { navController.popBackStack() })
 }
 }
}
