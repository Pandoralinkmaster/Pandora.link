package com.pandora.ui.screens

import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

@Composable
fun WalletScreen(onBack: () -> Unit) {
 val bg = Color(0xFF0A0A0F)
 val gold = Color(0xFFFFD700)

 Surface(modifier = Modifier.fillMaxSize(), color = bg) {
 Column(modifier = Modifier.fillMaxSize().padding(16.dp).verticalScroll(rememberScrollState())) {
 Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
 IconButton(onClick = onBack) { Icon(Icons.Default.ArrowBack, null, tint = Color.White) }
 Spacer(Modifier.width(8.dp))
 Text("₿ Bitcoin Wallet", color = gold, fontSize = 20.sp, fontWeight = FontWeight.Black)
 }
 Spacer(Modifier.height(16.dp))

 Card(colors = CardDefaults.cardColors(containerColor = Color(0xFF1A1A2E)), shape = RoundedCornerShape(16.dp), modifier = Modifier.fillMaxWidth()) {
 Column(Modifier.padding(20.dp), horizontalAlignment = Alignment.CenterHorizontally) {
 Text("🔒", fontSize = 48.sp)
 Spacer(Modifier.height(8.dp))
 Text("Ledger Hardware Wallet", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 18.sp)
 Text("Nano S / Nano X / Stax", color = Color.Gray, fontSize = 12.sp)
 Spacer(Modifier.height(16.dp))
 Text("BIP39 / BIP44 Adressableitung", color = gold, fontSize = 12.sp)
 Text("Android Keystore + Tor-Broadcast", color = Color.Gray, fontSize = 11.sp)
 Spacer(Modifier.height(16.dp))
 Button(onClick = {}, colors = ButtonDefaults.buttonColors(containerColor = gold), shape = RoundedCornerShape(10.dp)) {
 Text("Wallet verbinden", color = Color.Black, fontWeight = FontWeight.Bold)
 }
 }
 }
 Spacer(Modifier.height(16.dp))
 Text("Transaktionen", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 16.sp)
 Spacer(Modifier.height(8.dp))
 Card(colors = CardDefaults.cardColors(containerColor = Color(0xFF12121A)), shape = RoundedCornerShape(12.dp), modifier = Modifier.fillMaxWidth()) {
 Box(Modifier.padding(24.dp), contentAlignment = Alignment.Center) {
 Text("Noch keine Transaktionen", color = Color.Gray)
 }
 }
 }
 }
}

@Composable
fun ShopScreen(onBack: () -> Unit) {
 val bg = Color(0xFF0A0A0F)
 val accent = Color(0xFF4CAF50)

 Surface(modifier = Modifier.fillMaxSize(), color = bg) {
 Column(modifier = Modifier.fillMaxSize().padding(16.dp).verticalScroll(rememberScrollState())) {
 Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
 IconButton(onClick = onBack) { Icon(Icons.Default.ArrowBack, null, tint = Color.White) }
 Spacer(Modifier.width(8.dp))
 Text("🛒 Shop", color = accent, fontSize = 20.sp, fontWeight = FontWeight.Black)
 }
 Spacer(Modifier.height(16.dp))
 Card(colors = CardDefaults.cardColors(containerColor = Color(0xFF1A1A2E)), shape = RoundedCornerShape(12.dp), modifier = Modifier.fillMaxWidth()) {
 Box(Modifier.padding(24.dp), contentAlignment = Alignment.Center) {
 Text("Produkte werden geladen...", color = Color.Gray)
 }
 }
 }
 }
}
