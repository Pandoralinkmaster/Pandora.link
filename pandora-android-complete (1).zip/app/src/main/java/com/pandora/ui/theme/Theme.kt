package com.pandora.ui.theme

import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

val Purple = Color(0xFFE040FB)
val Cyan = Color(0xFF00BCD4)
val Gold = Color(0xFFFFD700)
val Green = Color(0xFF00E676)
val Red = Color(0xFFFF1744)
val Orange = Color(0xFFFF6D00)
val DarkBg = Color(0xFF0A0A0F)
val Surface = Color(0xFF12121A)
val White = Color(0xFFFFFFFF)
val Gray = Color(0xFF888888)

private val PandoraColorScheme = darkColorScheme(
 primary = Purple,
 onPrimary = White,
 primaryContainer = Purple.copy(alpha = 0.2f),
 secondary = Cyan,
 onSecondary = White,
 secondaryContainer = Cyan.copy(alpha = 0.2f),
 tertiary = Gold,
 onTertiary = White,
 background = DarkBg,
 onBackground = White,
 surface = Surface,
 onSurface = White,
 surfaceVariant = Color(0xFF1A1A2E),
 onSurfaceVariant = Gray,
 error = Red,
 onError = White,
)

@Composable
fun PandoraTheme(content: @Composable () -> Unit) {
 MaterialTheme(
 colorScheme = PandoraColorScheme,
 typography = androidx.compose.material3.Typography(),
 content = content
 )
}
