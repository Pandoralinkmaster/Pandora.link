package com.pandora.visibility

import android.util.Log
import com.pandora.core.ConfigManager
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.serialization.Serializable

@Serializable
enum class VisibilityState {
 OPEN,
 LOCKED,
}

@Serializable
data class HostVisibilityState(
 val isOpen: Boolean = false,
 val reason: String = "host_offline",
 val openedAt: Long = 0L,
 val lockedAt: Long = 0L,
 val timeoutMinutes: Int = 15,
 val unlockMethod: String = "",
)

class HostVisibilityGate(private val config: ConfigManager) {

 private val _state = MutableStateFlow(HostVisibilityState())
 val state: StateFlow<HostVisibilityState> = _state

 init { lock("host_offline") }

 fun unlock(method: String): Boolean {
 if (!config.isSetupComplete()) return false
 _state.value = _state.value.copy(
 isOpen = true,
 reason = "active",
 openedAt = System.currentTimeMillis(),
 unlockMethod = method,
 )
 config.isHostActive = true
 Log.i("VisibilityGate", "Host ENTSPERRT via $method")
 return true
 }

 fun lock(reason: String = "access_locked") {
 _state.value = _state.value.copy(
 isOpen = false,
 reason = reason,
 lockedAt = System.currentTimeMillis(),
 )
 config.isHostActive = false
 Log.i("VisibilityGate", "Host GESPERRT: $reason")
 }

 fun isOpen(): Boolean = checkTimeout() && _state.value.isOpen
 fun isLocked(): Boolean = !isOpen()

 fun validatePin(inputPin: String): Boolean {
 return config.hostPin == inputPin
 }

 fun recordActivity() {
 if (_state.value.isOpen) {
 _state.value = _state.value.copy(openedAt = System.currentTimeMillis())
 }
 }

 private fun checkTimeout(): Boolean {
 if (!_state.value.isOpen) return false
 val elapsed = System.currentTimeMillis() - _state.value.openedAt
 val timeout = _state.value.timeoutMinutes * 60_000L
 if (elapsed > timeout) {
 lock("inactivity_timeout")
 return false
 }
 return true
 }

 fun clientStatus(): Map<String, Any> = mapOf(
 "hostActive" to isOpen(),
 "reason" to _state.value.reason,
 "ceoName" to config.ceoName,
 "ceoEmail" to config.ceoEmail,
 "lastUpdate" to System.currentTimeMillis(),
 )

 fun onScreenLocked() { lock("screen_locked") }
 fun onScreenUnlocked() { unlock("screen_unlocked") }
}
