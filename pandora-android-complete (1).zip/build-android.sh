#!/bin/bash
set -e

# Prüfe Java 17+
java_version=$(java -version 2>&1 | awk -F '"' '/version/ {print $2}')
echo "Java-Version: $java_version"

# Build APK
chmod +x gradlew
./gradlew assembleDebug --no-daemon

# Kopiere APK
echo "APK erstellt:"
ls -la app/build/outputs/apk/debug/

mkdir -p ../dist
cp app/build/outputs/apk/debug/app-debug.apk ../dist/Pandora.apk
echo "APK kopiert nach ../dist/Pandora.apk"
