#!/bin/bash
cd "$(dirname "$0")"
zip -r ../pandora-android-export.zip . -x "*.git*" -x "*/build/*" -x "*.gradle/*"
echo "Projekt exportiert nach ../pandora-android-export.zip"
