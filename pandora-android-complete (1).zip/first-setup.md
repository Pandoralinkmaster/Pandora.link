# Erster Start

## Voraussetzungen
- Samsung Galaxy S24 Ultra (Root of Trust)
- M.2 SSD mit exFAT-Formatierung
- Android Studio oder GitHub Actions

## Schritt-für-Schritt

1. **APK bauen**
   - GitHub Actions Workflow ausführen
   - Oder lokal: `./build-android.sh`

2. **APK installieren**
   - `adb install app-debug.apk`

3. **App starten**
   - Setup-Assistent öffnet sich automatisch

4. **Modus wählen**
   - CEO Host Mode (für S24 Ultra)
   - Client Mode (für andere Geräte)

5. **CEO registrieren**
   - Name: Finn Jona Lischke
   - PIN vergeben (min. 6 Stellen)
   - Biometrie optional aktivieren

6. **SSD freigeben**
   - M.2 SSD via USB-C OTG anschließen
   - Im Datei-Browser SSD-Ordner auswählen
   - Berechtigung erteilen

7. **JayJay einlernen**
   - 3+ Stimm-Samples aufnehmen
   - Wake-Word: "Pandemonium"

8. **Host aktivieren**
   - API-Server startet auf Port 8765
   - Mesh-Netzwerke initialisieren
   - Automatisches DB-Backup alle 15 Minuten

## Weitere Geräte koppeln

1. Client-Modus wählen
2. Host-Netzwerk beitreten
3. QR-Code scannen oder manuell verbinden
4. CEO autorisiert das Gerät

## JayJay-Befehle

- "Pandemonium" → Wake-Word
- "JayJay, lerne: X = Y" → Direktes Wissen
- "JayJay, recherchiere: X" → Wikipedia-Recherche
- "JayJay, lerne Befehl: X = Y" → Befehl lernen

## Troubleshooting

| Problem | Lösung |
|---------|--------|
| SSD nicht erkannt | exFAT-Formatierung prüfen, OTG-Adapter testen |
| JayJay reagiert nicht | Mikrofon-Berechtigung prüfen, Wake-Word laut sprechen |
| Host nicht erreichbar | WLAN-Verbindung prüfen, Firewall-Regeln prüfen |
| Bluetooth Mesh fehlt | BLE-Berechtigungen prüfen, Geräte in Reichweite |
