# JayJay KI-Dokumentation

## Architektur

```
Mikrofon → VAD → CEO-Erkennung → Wake-Word → STT → Befehl → Aktion
```

## Stimm-Erkennung

- 3+ Samples aufnehmen
- MFCC-Features extrahieren
- 82% Threshold für Erkennung
- Funktioniert auch bei gesperrtem Bildschirm

## Lern-System

### Direktes Wissen
- Trigger → Antwort
- Gespeichert auf SSD

### Web-Recherche
- Wikipedia-API
- GPT-Zusammenfassung
- Stündliches Auto-Lernen

### Befehle
- Natürliche Sprache → Systemaktion
- Beispiel: "Scan" → Starte RSSI-Scan

## Daten auf SSD

- `voice_prints/finn.jona.lischke.json`
- `memory/memory.json`

## Sicherheitsregeln

- Keine Nutzung ohne CEO-Erkennung
- Verschlüsselte Aufgabenpakete
- Zero-Trust Architektur

## OpenAI Integration

- Modell: gpt-4o-mini
- Whisper: whisper-1
- API-Key via Umgebungsvariable: `OPENAI_API_KEY`
